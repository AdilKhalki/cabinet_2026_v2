<div>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <div class="card">
        <div class="card-header">
            <h5>
                <i class="feather icon-bell"></i> Notifications
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($unreadCount > 0): ?>
                    <span class="badge badge-pill label-danger" style="font-size: 12px; margin-left: 5px;"><?php echo e($unreadCount); ?></span>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </h5>
            <div class="card-header-right">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($unreadCount > 0): ?>
                    <button type="button" wire:click="markAllAsRead" class="btn btn-info btn-sm" wire:loading.attr="disabled" wire:loading.class="disabled" wire:target="markAllAsRead">
                        <span wire:loading.remove wire:target="markAllAsRead">
                            <i class="feather icon-check-circle"></i> Tout marquer comme lu
                        </span>
                        <span wire:loading wire:target="markAllAsRead">
                            <i class="feather icon-loader"></i> En cours...
                        </span>
                    </button>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <a href="<?php echo e(route('home')); ?>" class="btn btn-default btn-sm">
                    <i class="feather icon-home"></i> Tableau de bord
                </a>
            </div>
        </div>
        <div class="card-block">

            
            <div class="row m-b-20">
                <div class="col-md-4">
                    <select wire:model.live="filter" class="form-control">
                        <option value="all">-- Toutes les notifications --</option>
                        <option value="unread">Non lues</option>
                        <option value="read">Lues</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <select wire:model.live="typeFilter" class="form-control">
                        <option value="">-- Tous les types --</option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $availableTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                            <option value="<?php echo e($type); ?>"><?php echo e($label); ?></option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </select>
                </div>
                <div class="col-md-4 text-right">
                    <span class="text-muted"><?php echo e($notifications->total()); ?> notification(s)</span>
                </div>
            </div>

            
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th style="width: 140px;">Date</th>
                            <th style="width: 150px;">Type</th>
                            <th>Message</th>
                            <th style="width: 100px;">Statut</th>
                            <th style="width: 120px;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                            <?php
                                $isUnread = is_null($notification->read_at);
                                $typeColors = [
                                    'appointment'   => 'label-primary',
                                    'payment'       => 'label-success',
                                    'lab_result'    => 'label-info',
                                    'prescription'  => 'label-warning',
                                    'alert'         => 'label-danger',
                                    'reminder'      => 'label-default',
                                    'system'        => 'label-default',
                                ];
                                $notifType = $notification->data['type'] ?? $notification->type ?? 'system';
                                $notifType = class_basename($notifType);
                                $notifType = strtolower(preg_replace('/(?<!^)[A-Z]/', '_$0', $notifType));
                                $typeColor  = $typeColors[$notifType] ?? 'label-default';
                                $message    = $notification->data['message'] ?? $notification->data['body'] ?? 'Notification';
                                $typeLabel  = $notification->data['title'] ?? ucfirst(str_replace('_', ' ', $notifType));
                            ?>
                            <tr class="<?php echo e($isUnread ? 'active' : ''); ?>">
                                <td>
                                    <small><?php echo e($notification->created_at ? $notification->created_at->format('d/m/Y H:i') : '—'); ?></small>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isUnread): ?>
                                        <br><span style="display:inline-block; width:8px; height:8px; border-radius:50%; background:#4099ff; margin-top:2px;" title="Non lu"></span>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </td>
                                <td>
                                    <span class="label <?php echo e($typeColor); ?>"><?php echo e($typeLabel); ?></span>
                                </td>
                                <td>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isUnread): ?>
                                        <strong><?php echo e($message); ?></strong>
                                    <?php else: ?>
                                        <?php echo e($message); ?>

                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($notification->data['url']) && \Illuminate\Support\Str::startsWith($notification->data['url'], ['http://', 'https://', '/'])): ?>
                                        <br><a href="<?php echo e($notification->data['url']); ?>" class="text-primary" style="font-size:12px;">
                                            <i class="feather icon-external-link"></i> Voir les détails
                                        </a>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </td>
                                <td>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isUnread): ?>
                                        <span class="label label-warning"><i class="feather icon-circle"></i> Non lu</span>
                                    <?php else: ?>
                                        <span class="label label-default"><i class="feather icon-check"></i> Lu</span>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </td>
                                <td>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isUnread): ?>
                                        <button type="button"
                                            wire:click="markAsRead('<?php echo e($notification->id); ?>')"
                                            class="btn btn-info btn-xs" title="Marquer comme lu">
                                            <i class="feather icon-check"></i> Lu
                                        </button>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    <button type="button"
                                        wire:click="delete('<?php echo e($notification->id); ?>')"
                                        wire:confirm="Supprimer cette notification ?"
                                        class="btn btn-danger btn-xs" title="Supprimer">
                                        <i class="feather icon-trash-2"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            <tr>
                                <td colspan="5" class="text-center text-muted p-30">
                                    <i class="feather icon-bell-off" style="font-size: 3em;"></i>
                                    <p class="m-t-10">Aucune notification.</p>
                                </td>
                            </tr>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="m-t-20">
                <?php echo e($notifications->links('pagination::bootstrap-5')); ?>

            </div>

        </div>
    </div>
</div>
<?php /**PATH E:\______laravel Project 2026\wa_cabinet_2026_v2\resources\views/livewire/notification/notification-index.blade.php ENDPATH**/ ?>