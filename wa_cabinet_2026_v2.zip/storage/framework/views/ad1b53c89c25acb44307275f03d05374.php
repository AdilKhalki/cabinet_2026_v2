<div>
    <div class="card">
        <div class="card-header">
            <h5><i class="feather icon-activity"></i> Consultations</h5>
            <div class="card-header-right">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Models\Consultation::class)): ?>
                <a href="<?php echo e(route('consultations.create')); ?>" class="btn btn-primary btn-sm">
                    <i class="feather icon-plus"></i> Nouvelle consultation
                </a>
                <?php endif; ?>
            </div>
        </div>
        <div class="card-block">
            <div class="row m-b-20">
                <div class="col-md-6">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="feather icon-search"></i></span>
                        <input type="text" wire:model.live.debounce.300ms="search" class="form-control" placeholder="Rechercher...">
                    </div>
                </div>
                <div class="col-md-3">
                    <select wire:model.live="statusFilter" class="form-control">
                        <option value="">Tous les statuts</option>
                        <option value="in_progress">En cours</option>
                        <option value="completed">Terminées</option>
                        <option value="archived">Archivées</option>
                    </select>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr><th>Patient</th><th>Médecin</th><th>Date</th><th>Type</th><th>Motif</th><th>Statut</th><th>Actions</th></tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $this->consultations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consult): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                            <tr <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'consult-'.e($consult->id).''; ?>wire:key="consult-<?php echo e($consult->id); ?>">
                                <td>
                                    <a href="<?php echo e(route('patients.show', $consult->patient)); ?>"><strong><?php echo e($consult->patient->full_name); ?></strong></a>
                                    <small class="text-muted d-block"><?php echo e($consult->patient->dossier_number); ?></small>
                                </td>
                                <td><?php echo e($consult->doctor->name); ?></td>
                                <td><?php echo e($consult->consultation_date->format('d/m/Y H:i')); ?></td>
                                <td><span class="label label-info"><?php echo e($consult->type_label); ?></span></td>
                                <td><?php echo e($consult->reason ? Str::limit($consult->reason, 50) : '—'); ?></td>
                                <td>
                                    <span class="label label-<?php echo e($consult->status === 'completed' ? 'success' : 'warning'); ?>"><?php echo e($consult->status_label); ?></span>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('consultations.show', $consult)); ?>" class="btn btn-info btn-xs"><i class="feather icon-eye"></i></a>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $consult)): ?>
                                    <a href="<?php echo e(route('consultations.edit', $consult)); ?>" class="btn btn-warning btn-xs"><i class="feather icon-edit"></i></a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            <tr><td colspan="7" class="text-center text-muted p-20">Aucune consultation trouvée.</td></tr>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="m-t-15"><?php echo e($this->consultations->links('pagination::bootstrap-5')); ?></div>
        </div>
    </div>
</div>
<?php /**PATH E:\______laravel Project 2026\wa_cabinet_2026_v2\resources\views/livewire/consultation/consultation-index.blade.php ENDPATH**/ ?>