<div>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <div class="card">
        <div class="card-header">
            <h5><i class="feather icon-activity"></i> Résultat d'Analyse — <?php echo e($labTest->request_number ?? 'N/A'); ?></h5>
            <div class="card-header-right">
                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-default btn-sm">
                    <i class="feather icon-arrow-left"></i> Retour
                </a>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($labTest->pdf_path): ?>
                    <a href="#" wire:click.prevent="downloadLabPdf" class="btn btn-info btn-sm">
                        <i class="feather icon-file"></i> Voir PDF
                    </a>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <a href="<?php echo e(route('lab-tests.pdf', $labTest)); ?>" target="_blank" class="btn btn-primary btn-sm">
                    <i class="feather icon-printer"></i> Imprimer demande
                </a>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $labTest)): ?>
                <a href="<?php echo e(route('lab-tests.edit', $labTest)); ?>" class="btn btn-warning btn-sm">
                    <i class="feather icon-edit"></i> Modifier
                </a>
                <?php endif; ?>
            </div>
        </div>
        <div class="card-block">
            <div class="row">
                <div class="col-md-3">
                    <strong><i class="feather icon-user"></i> Patient :</strong><br>
                    <?php echo e($labTest->patient->full_name ?? '—'); ?>

                </div>
                <div class="col-md-3">
                    <strong><i class="feather icon-user-check"></i> Médecin prescripteur :</strong><br>
                    <?php echo e($labTest->doctor->full_name ?? '—'); ?>

                </div>
                <div class="col-md-3">
                    <strong><i class="feather icon-calendar"></i> Date de demande :</strong><br>
                    <?php echo e($labTest->requested_at ? \Carbon\Carbon::parse($labTest->requested_at)->format('d/m/Y') : '—'); ?>

                </div>
                <div class="col-md-3">
                    <strong><i class="feather icon-check-circle"></i> Date des résultats :</strong><br>
                    <?php echo e($labTest->resulted_at ? \Carbon\Carbon::parse($labTest->resulted_at)->format('d/m/Y') : '—'); ?>

                </div>
            </div>
            <div class="row m-t-10">
                <div class="col-md-3">
                    <strong>Laboratoire :</strong><br>
                    <?php echo e($labTest->laboratory_name ?? '—'); ?>

                </div>
                <div class="col-md-3">
                    <strong>Statut :</strong><br>
                    <?php
                        $statusColors = ['pending'=>'label-warning','in_progress'=>'label-info','completed'=>'label-success','cancelled'=>'label-danger'];
                        $statusLabels = ['pending'=>'En attente','in_progress'=>'En cours','completed'=>'Complété','cancelled'=>'Annulé'];
                        $sc = $statusColors[$labTest->status] ?? 'label-default';
                        $sl = $statusLabels[$labTest->status] ?? $labTest->status;
                    ?>
                    <span class="label <?php echo e($sc); ?>"><?php echo e($sl); ?></span>
                </div>
                <div class="col-md-6">
                    <strong>Informations cliniques :</strong><br>
                    <?php echo e($labTest->clinical_info ?? '—'); ?>

                </div>
            </div>
        </div>
    </div>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($labTest->results && $labTest->results->count()): ?>
        <?php
            $grouped = $labTest->results->groupBy('category');
        ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $grouped; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category => $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
            <div class="card m-t-15">
                <div class="card-header">
                    <h6><i class="feather icon-layers"></i> <?php echo e($category ?: 'Général'); ?></h6>
                </div>
                <div class="card-block">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr class="bg-c-blue">
                                    <th class="text-white">Paramètre</th>
                                    <th class="text-white">Valeur</th>
                                    <th class="text-white">Unité</th>
                                    <th class="text-white">Valeurs normales</th>
                                    <th class="text-white">Statut</th>
                                    <th class="text-white">Notes</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                    <?php
                                        $rowClass = '';
                                        $flagLabel = 'label-success';
                                        $flagText = 'Normal';
                                        if ($result->flag === 'critical') { $rowClass = 'danger'; $flagLabel = 'label-danger'; $flagText = 'Critique'; }
                                        elseif ($result->flag === 'high') { $rowClass = 'warning'; $flagLabel = 'label-warning'; $flagText = 'Élevé'; }
                                        elseif ($result->flag === 'low') { $rowClass = 'warning'; $flagLabel = 'label-info'; $flagText = 'Bas'; }
                                    ?>
                                    <tr class="<?php echo e($rowClass); ?>">
                                        <td><strong><?php echo e($result->parameter_name); ?></strong></td>
                                        <td><?php echo e($result->value); ?></td>
                                        <td><?php echo e($result->unit ?? '—'); ?></td>
                                        <td>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($result->normal_min !== null && $result->normal_max !== null): ?>
                                                <?php echo e($result->normal_min); ?> – <?php echo e($result->normal_max); ?>

                                            <?php else: ?>
                                                —
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        </td>
                                        <td><span class="label <?php echo e($flagLabel); ?>"><?php echo e($flagText); ?></span></td>
                                        <td><?php echo e($result->notes ?? '—'); ?></td>
                                    </tr>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
    <?php else: ?>
        <div class="card m-t-15">
            <div class="card-block">
                <p class="text-muted text-center p-20">Aucun résultat disponible.</p>
            </div>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <div class="card m-t-15">
        <div class="card-header">
            <h5><i class="feather icon-file-text"></i> Interprétation médicale</h5>
        </div>
        <div class="card-block">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($labTest->doctor_interpretation): ?>
                <div style="white-space: pre-wrap; font-family: inherit; background: #f8f9fa; padding: 15px; border-radius: 4px; border-left: 4px solid #4099ff;"><?php echo e($labTest->doctor_interpretation); ?></div>
            <?php else: ?>
                <p class="text-muted">Aucune interprétation renseignée.</p>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($this->evolutionData)): ?>
        <div class="card m-t-15">
            <div class="card-header">
                <h5><i class="feather icon-trending-up"></i> Évolution des paramètres</h5>
            </div>
            <div class="card-block">
                <div class="row">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $this->evolutionData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paramName => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                        <div class="col-md-6 m-b-20">
                            <h6><?php echo e($paramName); ?> <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($data['unit'])): ?><small class="text-muted">(<?php echo e($data['unit']); ?>)</small><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?></h6>
                            <canvas id="chart-<?php echo e(Str::slug($paramName)); ?>" height="120"></canvas>
                        </div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </div>
            </div>
        </div>

        <?php $__env->startPush('scripts'); ?>
        <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
        <script>
        (function () {
            var evolutionData = <?php echo json_encode($this->evolutionData, 15, 512) ?>;
            Object.keys(evolutionData).forEach(function (paramName) {
                var data = evolutionData[paramName];
                var slug = paramName.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
                var canvas = document.getElementById('chart-' + slug);
                if (!canvas) return;
                var datasets = [{
                    label: paramName,
                    data: data.values,
                    borderColor: '#4099ff',
                    backgroundColor: 'rgba(64,153,255,0.1)',
                    tension: 0.3,
                    fill: true,
                    pointBackgroundColor: '#4099ff',
                    pointRadius: 4,
                }];
                if (data.normal_min !== undefined && data.normal_max !== undefined) {
                    datasets.push({
                        label: 'Limite basse',
                        data: data.labels.map(function () { return data.normal_min; }),
                        borderColor: '#2ed8b6',
                        borderDash: [5, 5],
                        borderWidth: 1,
                        pointRadius: 0,
                        fill: false,
                    });
                    datasets.push({
                        label: 'Limite haute',
                        data: data.labels.map(function () { return data.normal_max; }),
                        borderColor: '#ff5370',
                        borderDash: [5, 5],
                        borderWidth: 1,
                        pointRadius: 0,
                        fill: false,
                    });
                }
                new Chart(canvas, {
                    type: 'line',
                    data: { labels: data.labels, datasets: datasets },
                    options: {
                        responsive: true,
                        plugins: { legend: { position: 'top' } },
                        scales: { y: { beginAtZero: false } }
                    }
                });
            });
        })();
        </script>
        <?php $__env->stopPush(); ?>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>
<?php /**PATH E:\______laravel Project 2026\wa_cabinet_2026_v2\resources\views/livewire/lab-test/lab-test-show.blade.php ENDPATH**/ ?>