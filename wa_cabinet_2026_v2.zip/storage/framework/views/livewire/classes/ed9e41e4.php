<?php

use App\Concerns\PasswordValidationRules;
use App\Livewire\Actions\Logout;
use Illuminate\Support\Facades\Auth;
use Livewire\Component;

return new class extends Component {
    use PasswordValidationRules;

    public string $password = '';

    /**
     * Delete the currently authenticated user.
     */
    public function deleteUser(Logout $logout): void
    {
        // Cabinet médical : la suppression de compte est réservée à l'administrateur
        // (Administration > Utilisateurs). Supprimer un médecin effacerait en cascade
        // ses consultations, ordonnances, paiements…
        abort(403, 'La suppression de compte doit être effectuée par un administrateur.');

        $this->validate([
            'password' => $this->currentPasswordRules(),
        ]);

        tap(Auth::user(), $logout(...))->delete();

        $this->redirect('/', navigate: true);
    }

    protected function view($data = [])
    {
        return app('view')->file('E:\______laravel Project 2026\wa_cabinet_2026_v2\storage\framework/views/livewire/views/ed9e41e4.blade.php', $data);
    }
}; 