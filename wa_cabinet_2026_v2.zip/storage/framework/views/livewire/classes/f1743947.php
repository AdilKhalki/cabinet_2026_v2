<?php

use Livewire\Component;
use Livewire\Attributes\Title;

return new #[Title('Appearance settings')] class extends Component {
    //

    protected function view($data = [])
    {
        return app('view')->file('E:\______laravel Project 2026\wa_cabinet_2026_v2\storage\framework/views/livewire/views/f1743947.blade.php', $data);
    }
}; 