<div>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <div class="card">
        <div class="card-header">
            <h5><i class="feather icon-bar-chart-2"></i> Rapport Financier <small class="text-muted">(<?php echo e($periodLabel); ?>)</small></h5>
            <div class="card-header-right">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($canExport): ?>
                    <button type="button" class="btn btn-success btn-sm" wire:click="export" wire:loading.attr="disabled" wire:target="export">
                        <i class="feather icon-download"></i> Exporter Excel
                    </button>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <a href="<?php echo e(route('home')); ?>" class="btn btn-primary btn-sm">
                    <i class="feather icon-home"></i> Tableau de bord
                </a>
            </div>
        </div>
        <div class="card-block">
            <div class="row">
                <div class="col-md-2">
                    <div class="form-group">
                        <label>Période</label>
                        <select wire:model.live="periodType" class="form-control">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = \App\Livewire\Reports\FinancialReport::PERIOD_LABELS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                <option value="<?php echo e($value); ?>"><?php echo e($label); ?></option>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label>Date début</label>
                        <input type="date" wire:model.live="dateFrom" class="form-control">
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label>Date fin</label>
                        <input type="date" wire:model.live="dateTo" class="form-control">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label>Médecin</label>
                        <select wire:model.live="doctorFilter" class="form-control" <?php if(\App\Models\Payment::restrictedToOwn(auth()->user())): ?> disabled <?php endif; ?>>
                            <option value="">-- Tous les médecins --</option>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                <option value="<?php echo e($doctor->id); ?>">Dr. <?php echo e($doctor->name); ?></option>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-3 d-flex align-items-end">
                    <button type="button" wire:click="resetFilters" class="btn btn-default">
                        <i class="feather icon-refresh-cw"></i> Réinitialiser
                    </button>
                </div>
            </div>
        </div>
    </div>

    
    <div class="row">
        <div class="col-xl-3 col-md-6">
            <div class="card bg-c-blue order-card">
                <div class="card-block">
                    <h6 class="m-b-20 text-white">CA encaissé (période)</h6>
                    <h2 class="text-right text-white"><i class="feather icon-trending-up f-left"></i>
                        <span><?php echo e(number_format($stats['total_revenue'], 2, ',', ' ')); ?> MAD</span>
                    </h2>
                    <p class="m-b-0 text-white">
                        <span class="f-right"><?php echo e($stats['total_invoices']); ?> factures — moy. <?php echo e(number_format($stats['avg_invoice'], 2, ',', ' ')); ?> MAD</span>
                    </p>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card bg-c-green order-card">
                <div class="card-block">
                    <h6 class="m-b-20 text-white">CA de l'année</h6>
                    <h2 class="text-right text-white"><i class="feather icon-calendar f-left"></i>
                        <span><?php echo e(number_format($caYear, 2, ',', ' ')); ?> MAD</span>
                    </h2>
                    <p class="m-b-0 text-white">
                        <span class="f-right">Année <?php echo e(date('Y')); ?></span>
                    </p>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card bg-c-yellow order-card">
                <div class="card-block">
                    <h6 class="m-b-20 text-white">Reste à encaisser (période)</h6>
                    <h2 class="text-right text-white"><i class="feather icon-alert-circle f-left"></i>
                        <span><?php echo e(number_format($stats['total_pending'], 2, ',', ' ')); ?> MAD</span>
                    </h2>
                    <p class="m-b-0 text-white">
                        <span class="f-right"><?php echo e($stats['pending_count']); ?> impayées · <?php echo e($stats['partial_count']); ?> partielles</span>
                    </p>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card bg-c-pink order-card">
                <div class="card-block">
                    <h6 class="m-b-20 text-white">Nombre de factures</h6>
                    <h2 class="text-right text-white"><i class="feather icon-file-text f-left"></i>
                        <span><?php echo e($totalInvoices); ?></span>
                    </h2>
                    <p class="m-b-0 text-white">
                        <span class="f-right">Toutes périodes (hors annulées)</span>
                    </p>
                </div>
            </div>
        </div>
    </div>

    <div class="row m-t-10">
        
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h5><i class="feather icon-bar-chart"></i> Évolution du CA encaissé (par <?php echo e($revenueSeries['unit']); ?>)</h5>
                </div>
                <div class="card-block" wire:ignore>
                    <canvas id="monthlyRevenueChart" height="110"></canvas>
                </div>
            </div>
        </div>

        
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <h5><i class="feather icon-pie-chart"></i> Par mode de paiement</h5>
                </div>
                <div class="card-block">
                    <table class="table table-condensed">
                        <thead><tr><th>Mode</th><th class="text-right">Factures</th><th class="text-right">Encaissé</th></tr></thead>
                        <tbody>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $paymentsByMethod; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                <tr>
                                    <td><?php echo e($row['label']); ?></td>
                                    <td class="text-right"><?php echo e($row['count']); ?></td>
                                    <td class="text-right"><?php echo e(number_format($row['total'], 2, ',', ' ')); ?> MAD</td>
                                </tr>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                <tr><td colspan="3" class="text-center text-muted">Aucune donnée.</td></tr>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </tbody>
                    </table>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($stats['total_insurance'] > 0): ?>
                        <p class="text-muted small m-b-0">Part assurance facturée (non incluse dans l'encaissé) : <?php echo e(number_format($stats['total_insurance'], 2, ',', ' ')); ?> MAD</p>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    
    <div class="card m-t-10">
        <div class="card-header">
            <h5><i class="feather icon-credit-card"></i> Derniers paiements de la période</h5>
        </div>
        <div class="card-block">
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>N° Facture</th>
                            <th>Patient</th>
                            <th>Médecin</th>
                            <th>Total</th>
                            <th>Payé</th>
                            <th>Statut</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $recentPayments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                            <tr <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'recent-'.e($payment->id).''; ?>wire:key="recent-<?php echo e($payment->id); ?>">
                                <td><strong><?php echo e($payment->invoice_number); ?></strong></td>
                                <td><?php echo e($payment->patient?->full_name ?? '—'); ?></td>
                                <td><?php echo e($payment->doctor ? 'Dr. '.$payment->doctor->name : '—'); ?></td>
                                <td><strong><?php echo e(number_format($payment->total_amount, 2, ',', ' ')); ?> MAD</strong></td>
                                <td><?php echo e(number_format($payment->amount_paid, 2, ',', ' ')); ?> MAD</td>
                                <td><span class="label <?php echo e($statusColors[$payment->status] ?? 'label-default'); ?>"><?php echo e($statusLabels[$payment->status] ?? $payment->status); ?></span></td>
                                <td><?php echo e($payment->payment_date?->format('d/m/Y') ?? '—'); ?></td>
                            </tr>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            <tr>
                                <td colspan="7" class="text-center text-muted p-20">Aucun paiement sur la période.</td>
                            </tr>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <script>
    document.addEventListener('livewire:initialized', function () {
        var series = <?php echo json_encode($revenueSeries, 15, 512) ?>;
        var ctx = document.getElementById('monthlyRevenueChart');
        if (!ctx) return;

        var chart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: series.labels || [],
                datasets: [{
                    label: 'CA encaissé (MAD)',
                    data: series.data || [],
                    backgroundColor: 'rgba(64,153,255,0.7)',
                    borderColor: '#4099ff',
                    borderWidth: 1,
                    borderRadius: 4,
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { position: 'top' },
                    tooltip: {
                        callbacks: {
                            label: function (context) {
                                return ' ' + Number(context.parsed.y).toLocaleString('fr-FR', { minimumFractionDigits: 2 }) + ' MAD';
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function (value) {
                                return Number(value).toLocaleString('fr-FR') + ' MAD';
                            }
                        }
                    }
                }
            }
        });

        // Mise à jour du graphique quand les filtres changent
        Livewire.on('financial-chart-updated', function (event) {
            var s = (event && event.series) || (Array.isArray(event) && event[0] && event[0].series) || { labels: [], data: [] };
            chart.data.labels = s.labels;
            chart.data.datasets[0].data = s.data;
            chart.update();
        });
    });
    </script>
    <?php $__env->stopPush(); ?>
</div>
<?php /**PATH E:\______laravel Project 2026\wa_cabinet_2026_v2\resources\views/livewire/reports/financial-report.blade.php ENDPATH**/ ?>