<div>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <div class="card">
        <div class="card-header">
            <h5>Ordonnances</h5>
            <div class="card-header-right">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Models\Prescription::class)): ?>
                <a href="<?php echo e(route('prescriptions.create')); ?>" class="btn btn-primary btn-sm">
                    <i class="feather icon-plus"></i> Nouvelle Ordonnance
                </a>
                <?php endif; ?>
            </div>
        </div>
        <div class="card-block">
            
            <div class="row m-b-20">
                <div class="col-md-6">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="feather icon-search"></i></span>
                        <input type="text" class="form-control" placeholder="Rechercher par patient..."
                               wire:model.live.debounce.300ms="search">
                    </div>
                </div>
            </div>

            
            <div class="table-responsive">
                <table class="table table-hover table-bordered">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>N° Ordonnance</th>
                            <th>Patient</th>
                            <th>Médecin</th>
                            <th>Date</th>
                            <th>Médicaments</th>
                            <th>Imprimée</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $this->prescriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                            <tr>
                                <td><?php echo e($loop->iteration + ($this->prescriptions->currentPage() - 1) * $this->prescriptions->perPage()); ?></td>
                                <td>
                                    <a href="<?php echo e(route('prescriptions.show', $p->id)); ?>">
                                        <strong><?php echo e($p->prescription_number); ?></strong>
                                    </a>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('patients.show', $p->patient_id)); ?>">
                                        <?php echo e($p->patient->full_name); ?>

                                    </a>
                                    <br><small class="text-muted"><?php echo e($p->patient->dossier_number); ?></small>
                                </td>
                                <td>Dr. <?php echo e($p->doctor->name ?? '-'); ?></td>
                                <td><?php echo e($p->prescribed_at ? \Carbon\Carbon::parse($p->prescribed_at)->format('d/m/Y') : $p->created_at->format('d/m/Y')); ?></td>
                                <td class="text-center">
                                    <span class="badge bg-info"><?php echo e($p->lines->count()); ?> méd.</span>
                                </td>
                                <td class="text-center">
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($p->is_printed): ?>
                                        <span class="badge bg-success"><i class="feather icon-check"></i> Oui</span>
                                    <?php else: ?>
                                        <span class="badge bg-warning">Non</span>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('prescriptions.show', $p->id)); ?>"
                                       class="btn btn-info btn-sm" title="Voir">
                                        <i class="feather icon-eye"></i>
                                    </a>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $p)): ?>
                                    <a href="<?php echo e(route('prescriptions.edit', $p->id)); ?>"
                                       class="btn btn-warning btn-sm" title="Modifier">
                                        <i class="feather icon-edit"></i>
                                    </a>
                                    <?php endif; ?>
                                    <a href="<?php echo e(route('prescriptions.pdf', $p->id)); ?>"
                                       target="_blank"
                                       class="btn btn-primary btn-sm" title="PDF">
                                        <i class="feather icon-printer"></i>
                                    </a>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $p)): ?>
                                    <button wire:click="confirmDelete(<?php echo e($p->id); ?>)"
                                            class="btn btn-danger btn-sm" title="Supprimer">
                                        <i class="feather icon-trash-2"></i>
                                    </button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            <tr>
                                <td colspan="8" class="text-center text-muted p-20">
                                    <i class="feather icon-file-text" style="font-size:2em;"></i><br>
                                    Aucune ordonnance trouvée.
                                </td>
                            </tr>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                </table>
            </div>

            
            <div class="m-t-10">
                <?php echo e($this->prescriptions->links('pagination::bootstrap-5')); ?>

            </div>
        </div>
    </div>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($confirmingDeleteId): ?>
    <div class="modal fade in" style="display:block;background:rgba(0,0,0,0.5);" wire:ignore.self>
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Confirmer la suppression</h4>
                </div>
                <div class="modal-body">
                    <p>Êtes-vous sûr de vouloir supprimer cette ordonnance ?</p>
                </div>
                <div class="modal-footer">
                    <button wire:click="cancelDelete" class="btn btn-default">Annuler</button>
                    <button wire:click="delete" class="btn btn-danger">
                        <i class="feather icon-trash-2"></i> Supprimer
                    </button>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>
<?php /**PATH E:\______laravel Project 2026\wa_cabinet_2026_v2\resources\views/livewire/prescription/prescription-index.blade.php ENDPATH**/ ?>