<?php
if (!function_exists('_f9b3759a250d989935a2e0ae96f9c231')):
function _f9b3759a250d989935a2e0ae96f9c231($__blaze, $__data = [], $__slots = [], $__bound = [], $__this = null) {
$__env = $__blaze->env;
$__slots['slot'] ??= new \Illuminate\View\ComponentSlot('');
if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::sanitized($__data, $__bound);
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP); unset($__data, $__bound);
ob_start();
?>


<?php
extract(Flux::forwardedAttributes($attributes, [
    'tooltipPosition',
    'tooltipKbd',
    'tooltip',
]));
?>

<?php $tooltipPosition = $tooltipPosition ??= $attributes->pluck('tooltip:position'); ?>
<?php $tooltipKbd = $tooltipKbd ??= $attributes->pluck('tooltip:kbd'); ?>
<?php $tooltip = $tooltip ??= $attributes->pluck('tooltip'); ?>

<?php
$__defaults = [
    'tooltipPosition' => 'top',
    'tooltipKbd' => null,
    'tooltip' => null,
];
$tooltipPosition ??= $attributes['tooltip-position'] ?? $attributes['tooltipPosition'] ?? $__defaults['tooltipPosition']; unset($attributes['tooltipPosition'], $attributes['tooltip-position']);
$tooltipKbd ??= $attributes['tooltip-kbd'] ?? $attributes['tooltipKbd'] ?? $__defaults['tooltipKbd']; unset($attributes['tooltipKbd'], $attributes['tooltip-kbd']);
$tooltip ??= $attributes['tooltip'] ?? $__defaults['tooltip']; unset($attributes['tooltip']);
unset($__defaults);
?>

<?php if ($tooltip): ?>
    <?php $__blaze->ensureRequired('E:\______laravel Project 2026\wa_cabinet_2026_v2\vendor\livewire\flux\src/../stubs/resources/views/flux/tooltip/index.blade.php', $__blaze->compiledPath.'/2e45799bd25da90c589b131254b29adb.php'); ?>
<?php if (isset($__slots2e45799bd25da90c589b131254b29adb)) $__slotsOriginal = $__slots2e45799bd25da90c589b131254b29adb; ?>
<?php if (isset($__attrs2e45799bd25da90c589b131254b29adb)) $__attrsOriginal = $__attrs2e45799bd25da90c589b131254b29adb; ?>
<?php $__attrs2e45799bd25da90c589b131254b29adb = ['content' => $tooltip,'position' => $tooltipPosition,'kbd' => $tooltipKbd]; ?>
<?php $__slots2e45799bd25da90c589b131254b29adb = []; ?>
<?php ob_start(); ?>
        <?php echo e($slot); ?>

    <?php $__slots2e45799bd25da90c589b131254b29adb['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushData($__attrs2e45799bd25da90c589b131254b29adb); ?>
<?php $__blaze->pushSlots($__slots2e45799bd25da90c589b131254b29adb); ?>
<?php _2e45799bd25da90c589b131254b29adb($__blaze, $__attrs2e45799bd25da90c589b131254b29adb, $__slots2e45799bd25da90c589b131254b29adb, ['content', 'position', 'kbd'], isset($this) ? $this : null); ?>
<?php if (isset($__slotsOriginal)) { $__slots2e45799bd25da90c589b131254b29adb = $__slotsOriginal; unset($__slotsOriginal); } ?>
<?php if (isset($__attrsOriginal)) { $__attrs2e45799bd25da90c589b131254b29adb = $__attrsOriginal; unset($__attrsOriginal); } ?>
<?php $__blaze->popData(); ?>
<?php else: ?>
    <?php echo e($slot); ?>

<?php endif; ?>
<?php
echo ltrim(ob_get_clean());
} endif; ?><?php /**PATH E:\______laravel Project 2026\wa_cabinet_2026_v2\vendor\livewire\flux\src/../stubs/resources/views/flux/with-tooltip.blade.php ENDPATH**/ ?>