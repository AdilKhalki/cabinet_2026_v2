<footer class="site-footer"
    style="background:#3d4a66; color:#a9b7d0; padding:15px 30px; font-size:13px; text-align:center; margin-top:auto;">
    <div class="row">
        <div class="col-sm-6 text-left">
            &copy; <?php echo e(date('Y')); ?> Cabinet Médical — Tous droits réservés
        </div>
        <div class="col-sm-6 text-right">
            Version 1.0 — Adil KHALKI <?php echo e(app()->version()); ?>

        </div>
    </div>
</footer>
<?php /**PATH E:\______laravel Project 2026\wa_cabinet_2026_v2\resources\views/partials/footer.blade.php ENDPATH**/ ?>