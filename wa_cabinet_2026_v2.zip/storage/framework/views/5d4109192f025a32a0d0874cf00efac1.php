<div>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <div class="card">
        <div class="card-block">
            <div class="row align-items-center">
                <div class="col-md-1 text-center">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($consultation->patient->photo_path): ?>
                        <img src="<?php echo e(Storage::url($consultation->patient->photo_path)); ?>"
                             class="img-radius" style="width:60px;height:60px;object-fit:cover;">
                    <?php else: ?>
                        <div style="width:60px;height:60px;background:#01a9ac;border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff;font-size:22px;font-weight:700;margin:0 auto;">
                            <?php echo e(substr($consultation->patient->first_name,0,1)); ?><?php echo e(substr($consultation->patient->last_name,0,1)); ?>

                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
                <div class="col-md-5">
                    <h4 class="m-b-5"><?php echo e($consultation->patient->full_name); ?></h4>
                    <p class="text-muted m-b-0">
                        <i class="feather icon-folder"></i> <?php echo e($consultation->patient->dossier_number); ?>

                        &nbsp;&bull;&nbsp;
                        <i class="feather icon-calendar"></i> <?php echo e(($consultation->consultation_date ?? $consultation->created_at)->format('d/m/Y H:i')); ?>

                    </p>
                    <p class="text-muted m-b-0">
                        <i class="feather icon-user"></i> Dr. <?php echo e($consultation->doctor->name); ?>

                        &nbsp;&bull;&nbsp;
                        <span class="label label-info"><?php echo e($consultation->type_label); ?></span>
                        <span class="label label-<?php echo e($consultation->status === 'completed' ? 'success' : 'warning'); ?> m-l-5"><?php echo e($consultation->status_label); ?></span>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($consultation->followup_required): ?>
                            <span class="label label-warning m-l-5">Suivi requis</span>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </p>
                </div>
                <div class="col-md-6 text-right">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $consultation)): ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($consultation->status === 'in_progress'): ?>
                    <button type="button" wire:click="complete" wire:confirm="Terminer cette consultation ?"
                            class="btn btn-primary btn-sm m-r-5">
                        <i class="feather icon-check-circle"></i> Terminer
                    </button>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create prescriptions')): ?>
                    <a href="<?php echo e(route('prescriptions.create', ['patient' => $consultation->patient_id, 'doctor' => $consultation->doctor_id, 'consultation' => $consultation->id])); ?>"
                       class="btn btn-success btn-sm m-r-5">
                        <i class="feather icon-file-text"></i> Nouvelle Ordonnance
                    </a>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $consultation)): ?>
                    <a href="<?php echo e(route('consultations.edit', $consultation->id)); ?>"
                       class="btn btn-warning btn-sm m-r-5">
                        <i class="feather icon-edit"></i> Modifier
                    </a>
                    <?php endif; ?>
                    <a href="<?php echo e(route('consultations.index')); ?>" class="btn btn-default btn-sm">
                        <i class="feather icon-arrow-left"></i> Retour
                    </a>
                </div>
            </div>
        </div>
    </div>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($consultation->weight_kg || $consultation->blood_pressure || $consultation->heart_rate || $consultation->temperature): ?>
    <div class="row">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($consultation->weight_kg): ?>
        <div class="col-md-2">
            <div class="card text-center">
                <div class="card-block p-b-10 p-t-10">
                    <i class="feather icon-activity text-primary" style="font-size:1.4em;"></i>
                    <h5 class="m-t-5"><?php echo e($consultation->weight_kg); ?> kg</h5>
                    <p class="text-muted m-b-0" style="font-size:11px;">Poids</p>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($consultation->height_cm): ?>
                        <small class="text-muted"><?php echo e($consultation->height_cm); ?> cm</small>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
        </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($consultation->blood_pressure): ?>
        <div class="col-md-2">
            <div class="card text-center">
                <div class="card-block p-b-10 p-t-10">
                    <i class="feather icon-heart text-danger" style="font-size:1.4em;"></i>
                    <h5 class="m-t-5"><?php echo e($consultation->blood_pressure); ?></h5>
                    <p class="text-muted m-b-0" style="font-size:11px;">Tension Art.</p>
                </div>
            </div>
        </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($consultation->heart_rate): ?>
        <div class="col-md-2">
            <div class="card text-center">
                <div class="card-block p-b-10 p-t-10">
                    <i class="feather icon-radio text-warning" style="font-size:1.4em;"></i>
                    <h5 class="m-t-5"><?php echo e($consultation->heart_rate); ?> bpm</h5>
                    <p class="text-muted m-b-0" style="font-size:11px;">Fréq. Cardiaque</p>
                </div>
            </div>
        </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($consultation->temperature): ?>
        <div class="col-md-2">
            <div class="card text-center">
                <div class="card-block p-b-10 p-t-10">
                    <i class="feather icon-thermometer text-info" style="font-size:1.4em;"></i>
                    <h5 class="m-t-5"><?php echo e($consultation->temperature); ?>°C</h5>
                    <p class="text-muted m-b-0" style="font-size:11px;">Température</p>
                </div>
            </div>
        </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($consultation->spo2): ?>
        <div class="col-md-2">
            <div class="card text-center">
                <div class="card-block p-b-10 p-t-10">
                    <i class="feather icon-droplet text-c-blue" style="font-size:1.4em;"></i>
                    <h5 class="m-t-5"><?php echo e($consultation->spo2); ?>%</h5>
                    <p class="text-muted m-b-0" style="font-size:11px;">SpO2</p>
                </div>
            </div>
        </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header"><h5>Motif et Clinique</h5></div>
                <div class="card-block">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($consultation->reason): ?>
                        <h6 class="text-muted">Motif de consultation</h6>
                        <p><?php echo e($consultation->reason); ?></p>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($consultation->symptoms): ?>
                        <h6 class="text-muted">Symptômes</h6>
                        <p><?php echo e($consultation->symptoms); ?></p>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($consultation->clinical_exam): ?>
                        <h6 class="text-muted">Examen clinique</h6>
                        <p><?php echo e($consultation->clinical_exam); ?></p>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!$consultation->reason && !$consultation->symptoms && !$consultation->clinical_exam): ?>
                        <p class="text-muted">Aucune information clinique.</p>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-header"><h5>Diagnostic et Traitement</h5></div>
                <div class="card-block">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($consultation->diagnosis): ?>
                        <h6 class="text-muted">Diagnostic</h6>
                        <p><?php echo e($consultation->diagnosis); ?>

                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($consultation->icd10_code): ?>
                                <span class="label label-default m-l-5"><?php echo e($consultation->icd10_code); ?></span>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </p>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($consultation->treatment_plan): ?>
                        <h6 class="text-muted">Plan de traitement</h6>
                        <p><?php echo e($consultation->treatment_plan); ?></p>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($consultation->followup_required && $consultation->followup_date): ?>
                        <div class="alert alert-warning p-10 m-t-10">
                            <i class="feather icon-calendar"></i>
                            Suivi prévu le <strong><?php echo e(\Carbon\Carbon::parse($consultation->followup_date)->format('d/m/Y')); ?></strong>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    
    <div class="card">
        <div class="card-block">
            <ul class="nav nav-tabs" id="consultTabs">
                <li class="active">
                    <a data-toggle="tab" href="#tab-prescriptions">
                        <i class="feather icon-file-text"></i> Ordonnances (<?php echo e($consultation->prescriptions->count()); ?>)
                    </a>
                </li>
                <li>
                    <a data-toggle="tab" href="#tab-labtests">
                        <i class="feather icon-activity"></i> Analyses (<?php echo e($consultation->labTests->count()); ?>)
                    </a>
                </li>
                <li>
                    <a data-toggle="tab" href="#tab-images">
                        <i class="feather icon-image"></i> Images (<?php echo e($consultation->medicalImages->count()); ?>)
                    </a>
                </li>
                <li>
                    <a data-toggle="tab" href="#tab-documents">
                        <i class="feather icon-paperclip"></i> Documents (<?php echo e($consultation->documents->count()); ?>)
                    </a>
                </li>
                <li>
                    <a data-toggle="tab" href="#tab-notes">
                        <i class="feather icon-edit-3"></i> Notes
                    </a>
                </li>
            </ul>
            <div class="tab-content m-t-20">

                <div id="tab-prescriptions" class="tab-pane fade in active">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($consultation->prescriptions->isEmpty()): ?>
                        <p class="text-center text-muted p-20">Aucune ordonnance pour cette consultation.</p>
                    <?php else: ?>
                        <table class="table table-hover table-bordered">
                            <thead>
                                <tr>
                                    <th>N° Ordonnance</th>
                                    <th>Date</th>
                                    <th>Médicaments</th>
                                    <th>Imprimée</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $consultation->prescriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                <tr>
                                    <td><strong><?php echo e($rx->prescription_number); ?></strong></td>
                                    <td><?php echo e($rx->prescribed_at ? \Carbon\Carbon::parse($rx->prescribed_at)->format('d/m/Y') : '-'); ?></td>
                                    <td><?php echo e($rx->lines->count()); ?> médicament(s)</td>
                                    <td>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($rx->is_printed): ?>
                                            <span class="label label-success">Oui</span>
                                        <?php else: ?>
                                            <span class="label label-default">Non</span>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('prescriptions.show', $rx->id)); ?>" class="btn btn-info btn-xs">
                                            <i class="feather icon-eye"></i>
                                        </a>
                                        <a href="<?php echo e(route('prescriptions.pdf', $rx->id)); ?>" target="_blank" class="btn btn-primary btn-xs">
                                            <i class="feather icon-printer"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            </tbody>
                        </table>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                <div id="tab-labtests" class="tab-pane fade">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($consultation->labTests->isEmpty()): ?>
                        <p class="text-center text-muted p-20">Aucune analyse prescrite.</p>
                    <?php else: ?>
                        <table class="table table-hover table-bordered">
                            <thead>
                                <tr>
                                    <th>N° Analyse</th>
                                    <th>Examen</th>
                                    <th>Statut</th>
                                    <th>Date résultat</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $consultation->labTests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                <tr>
                                    <td><?php echo e($lt->test_number); ?></td>
                                    <td><?php echo e($lt->test_name); ?></td>
                                    <td>
                                        <span class="label label-<?php echo e($lt->status === 'completed' ? 'success' : ($lt->status === 'pending' ? 'warning' : 'default')); ?>">
                                            <?php echo e(ucfirst($lt->status)); ?>

                                        </span>
                                    </td>
                                    <td><?php echo e($lt->result_date ? \Carbon\Carbon::parse($lt->result_date)->format('d/m/Y') : '-'); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('lab-tests.show', $lt->id)); ?>" class="btn btn-info btn-xs">
                                            <i class="feather icon-eye"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            </tbody>
                        </table>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                <div id="tab-images" class="tab-pane fade">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($consultation->medicalImages->isEmpty()): ?>
                        <p class="text-center text-muted p-20">Aucune image médicale.</p>
                    <?php else: ?>
                        <div class="row">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $consultation->medicalImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                            <div class="col-md-3 m-b-15">
                                <div class="card">
                                    <?php $ext = strtolower(pathinfo($img->file_path, PATHINFO_EXTENSION)); ?>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(in_array($ext, ['jpg','jpeg','png','gif'])): ?>
                                        <img src="<?php echo e($img->file_url); ?>" class="img-fluid"
                                             style="height:150px;object-fit:cover;">
                                    <?php else: ?>
                                        <div class="text-center p-20" style="background:#f4f7fa;">
                                            <i class="feather icon-file" style="font-size:3em;color:#aaa;"></i>
                                        </div>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    <div class="card-block p-10">
                                        <small class="text-muted"><?php echo e($img->category ?? 'Imagerie'); ?></small>
                                        <p class="m-b-0"><?php echo e($img->title ?? basename($img->file_path)); ?></p>
                                    </div>
                                </div>
                            </div>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                <div id="tab-documents" class="tab-pane fade">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($consultation->documents->isEmpty()): ?>
                        <p class="text-center text-muted p-20">Aucun document joint.</p>
                    <?php else: ?>
                        <table class="table table-hover">
                            <thead>
                                <tr><th>Nom</th><th>Catégorie</th><th>Date</th><th>Actions</th></tr>
                            </thead>
                            <tbody>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $consultation->documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                <tr>
                                    <td><i class="feather icon-paperclip"></i> <?php echo e($doc->title ?? basename($doc->file_path)); ?></td>
                                    <td><?php echo e($doc->category ?? '-'); ?></td>
                                    <td><?php echo e($doc->created_at->format('d/m/Y')); ?></td>
                                    <td>
                                        <a href="<?php echo e($doc->file_url); ?>" target="_blank" class="btn btn-primary btn-xs">
                                            <i class="feather icon-download"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            </tbody>
                        </table>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                <div id="tab-notes" class="tab-pane fade">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($consultation->doctor_notes): ?>
                        <h6 class="text-muted">Notes du médecin</h6>
                        <div class="well well-sm" style="white-space:pre-wrap;"><?php echo e($consultation->doctor_notes); ?></div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($consultation->summary): ?>
                        <h6 class="text-muted m-t-20">Résumé de consultation</h6>
                        <div class="well well-sm" style="white-space:pre-wrap;"><?php echo e($consultation->summary); ?></div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!$consultation->doctor_notes && !$consultation->summary): ?>
                        <p class="text-center text-muted p-20">Aucune note enregistrée.</p>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\______laravel Project 2026\wa_cabinet_2026_v2\resources\views/livewire/consultation/consultation-show.blade.php ENDPATH**/ ?>