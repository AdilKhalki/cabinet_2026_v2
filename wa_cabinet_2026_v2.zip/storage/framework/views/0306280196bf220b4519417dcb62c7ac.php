<div>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->any()): ?>
        <div class="alert alert-danger alert-dismissible">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <ul class="m-b-0">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?><li><?php echo e($error); ?></li><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </ul>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <form wire:submit="save">
        <div class="row">

            
            <div class="col-md-8">

                
                <div class="card">
                    <div class="card-header">
                        <h5><i class="feather icon-file-text"></i> Informations générales</h5>
                    </div>
                    <div class="card-block">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Patient <span class="text-danger">*</span></label>
                                    <?php if (isset($component)) { $__componentOriginaldf91e01cb43a2e4f863b01ea3afdf26c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldf91e01cb43a2e4f863b01ea3afdf26c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.patient-search-select','data' => ['patients' => $patients]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('patient-search-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['patients' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($patients)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldf91e01cb43a2e4f863b01ea3afdf26c)): ?>
<?php $attributes = $__attributesOriginaldf91e01cb43a2e4f863b01ea3afdf26c; ?>
<?php unset($__attributesOriginaldf91e01cb43a2e4f863b01ea3afdf26c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldf91e01cb43a2e4f863b01ea3afdf26c)): ?>
<?php $component = $__componentOriginaldf91e01cb43a2e4f863b01ea3afdf26c; ?>
<?php unset($__componentOriginaldf91e01cb43a2e4f863b01ea3afdf26c); ?>
<?php endif; ?>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['patient_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger small"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Médecin <span class="text-danger">*</span></label>
                                    <select class="form-control" wire:model="doctor_id">
                                        <option value="">-- Sélectionner --</option>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                            <option value="<?php echo e($doctor->id); ?>">Dr. <?php echo e($doctor->name); ?></option>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                    </select>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['doctor_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger small"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Date de prescription <span class="text-danger">*</span></label>
                                    <input type="date" class="form-control" wire:model="prescribed_at">
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['prescribed_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger small"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Valable jusqu'au</label>
                                    <input type="date" class="form-control" wire:model="valid_until">
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['valid_until'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger small"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($patientAllergies)): ?>
                    <div class="alert alert-danger">
                        <i class="feather icon-alert-triangle"></i>
                        <strong>Allergies connues :</strong> <?php echo e($patientAllergies); ?>

                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                
                <div class="card">
                    <div class="card-header">
                        <h5><i class="feather icon-list"></i> Médicaments prescrits</h5>
                        <div class="card-header-right">
                            <button type="button" class="btn btn-success btn-sm" wire:click="addLine">
                                <i class="feather icon-plus"></i> Ajouter un médicament
                            </button>
                        </div>
                    </div>
                    <div class="card-block p-0">

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(count($lines) === 0): ?>
                            <p class="text-muted text-center p-20">Aucun médicament. Cliquez sur "Ajouter".</p>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                        <div class="p-15" style="border-bottom: 1px solid #eee; <?php echo e($i % 2 === 0 ? 'background:#fafafa;' : ''); ?>">
                            <div class="row align-items-center m-b-5">
                                <div class="col-md-11">
                                    <strong style="color:#666;">
                                        <i class="feather icon-package text-primary"></i>
                                        Médicament <?php echo e($i + 1); ?>

                                    </strong>
                                </div>
                                <div class="col-md-1 text-right">
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(count($lines) > 1): ?>
                                    <button type="button" class="btn btn-danger btn-xs"
                                            wire:click="removeLine(<?php echo e($i); ?>)" title="Supprimer">
                                        <i class="feather icon-x"></i>
                                    </button>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>
                            </div>

                            
                            <div class="row">
                                <div class="col-md-5">
                                    <div class="form-group m-b-10">
                                        <label class="small text-muted">Depuis la liste</label>
                                        <select class="form-control form-control-sm"
                                                wire:model="lines.<?php echo e($i); ?>.medication_id"
                                                wire:change="selectMedication(<?php echo e($i); ?>, $event.target.value)">
                                            <option value="">-- Choisir un médicament --</option>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $medications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $med): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                                <option value="<?php echo e($med->id); ?>">
                                                    <?php echo e($med->name); ?><?php echo e($med->strength ? ' — '.$med->strength : ''); ?><?php echo e($med->dosage_form ? ' ('.$med->dosage_form.')' : ''); ?>

                                                </option>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-7">
                                    <div class="form-group m-b-10">
                                        <label class="small text-muted">Nom du médicament <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control form-control-sm"
                                               wire:model="lines.<?php echo e($i); ?>.medication_name"
                                               placeholder="Nom (ou saisie libre)">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ["lines.$i.medication_name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger small"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group m-b-10">
                                        <label class="small text-muted">Dosage</label>
                                        <input type="text" class="form-control form-control-sm"
                                               wire:model="lines.<?php echo e($i); ?>.dosage"
                                               placeholder="Ex: 500mg, 1 cp">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group m-b-10">
                                        <label class="small text-muted">Fréquence</label>
                                        <select class="form-control form-control-sm"
                                                wire:model="lines.<?php echo e($i); ?>.frequency">
                                            <option value="">-- Choisir --</option>
                                            <option value="1 fois/jour">1 fois/jour</option>
                                            <option value="2 fois/jour">2 fois/jour</option>
                                            <option value="3 fois/jour">3 fois/jour</option>
                                            <option value="4 fois/jour">4 fois/jour</option>
                                            <option value="Matin et soir">Matin et soir</option>
                                            <option value="Matin, midi et soir">Matin, midi et soir</option>
                                            <option value="Toutes les 8h">Toutes les 8h</option>
                                            <option value="Toutes les 12h">Toutes les 12h</option>
                                            <option value="1 fois/semaine">1 fois/semaine</option>
                                            <option value="Au besoin">Au besoin</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group m-b-10">
                                        <label class="small text-muted">Durée (jours)</label>
                                        <input type="number" class="form-control form-control-sm"
                                               wire:model="lines.<?php echo e($i); ?>.duration_days"
                                               min="1" placeholder="7">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ["lines.$i.duration_days"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger small"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group m-b-10">
                                        <label class="small text-muted">Quantité (boîtes)</label>
                                        <input type="number" class="form-control form-control-sm"
                                               wire:model="lines.<?php echo e($i); ?>.quantity"
                                               min="1" placeholder="Ex: 1">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ["lines.$i.quantity"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger small"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group m-b-10">
                                        <label class="small text-muted">Voie</label>
                                        <select class="form-control form-control-sm"
                                                wire:model="lines.<?php echo e($i); ?>.route">
                                            <option value="Oral">Oral</option>
                                            <option value="Injectable">Injectable</option>
                                            <option value="Topique">Topique</option>
                                            <option value="Inhalé">Inhalé</option>
                                            <option value="Sublingual">Sublingual</option>
                                            <option value="Rectal">Rectal</option>
                                            <option value="Ophtalmique">Ophtalmique</option>
                                            <option value="Nasal">Nasal</option>
                                            <option value="Auriculaire">Auriculaire</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            
                            <div class="form-group m-b-0">
                                <label class="small text-muted">Instructions spécifiques</label>
                                <input type="text" class="form-control form-control-sm"
                                       wire:model="lines.<?php echo e($i); ?>.instructions"
                                       placeholder="Ex: À prendre pendant les repas, ne pas mâcher...">
                            </div>
                        </div>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(count($lines) > 0): ?>
                        <div class="p-15">
                            <button type="button" class="btn btn-success btn-sm" wire:click="addLine">
                                <i class="feather icon-plus"></i> Ajouter un autre médicament
                            </button>
                        </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </div>

                
                <div class="card">
                    <div class="card-header"><h5><i class="feather icon-message-square"></i> Notes / Recommandations</h5></div>
                    <div class="card-block">
                        <div class="form-group m-b-0">
                            <textarea class="form-control" wire:model="notes" rows="3"
                                      placeholder="Conseils généraux, régime alimentaire, activité physique, contre-indications à rappeler..."></textarea>
                        </div>
                    </div>
                </div>

            </div>

            
            <div class="col-md-4">

                
                <div class="card">
                    <div class="card-header"><h5><i class="feather icon-eye"></i> Récapitulatif</h5></div>
                    <div class="card-block">
                        <table class="table table-condensed m-b-0">
                            <tbody>
                                <tr>
                                    <td class="text-muted" style="width:50%">Médicaments</td>
                                    <td>
                                        <span class="label label-primary"><?php echo e(count($lines)); ?></span>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="text-muted">Date</td>
                                    <td><?php echo e($prescribed_at ? \Carbon\Carbon::parse($prescribed_at)->format('d/m/Y') : '—'); ?></td>
                                </tr>
                                <tr>
                                    <td class="text-muted">Valable jusqu'au</td>
                                    <td><?php echo e($valid_until ? \Carbon\Carbon::parse($valid_until)->format('d/m/Y') : '—'); ?></td>
                                </tr>
                            </tbody>
                        </table>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(count($lines) > 0): ?>
                        <hr class="m-t-10 m-b-10">
                        <p class="small text-muted m-b-5"><strong>Médicaments :</strong></p>
                        <ul class="list-unstyled m-b-0">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($line['medication_name']): ?>
                                <li class="m-b-5">
                                    <i class="feather icon-package text-primary" style="font-size:11px;"></i>
                                    <span style="font-size:13px;"><?php echo e($line['medication_name']); ?></span>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($line['dosage']): ?>
                                        <br>
                                        <small class="text-muted" style="margin-left:16px;">
                                            <?php echo e($line['dosage']); ?>

                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($line['frequency']): ?>
                                                &mdash; <?php echo e($line['frequency']); ?>

                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($line['duration_days']): ?>
                                                &mdash; <?php echo e($line['duration_days']); ?>j
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        </small>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </li>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </ul>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </div>

                
                <div class="card">
                    <div class="card-header"><h5><i class="feather icon-link"></i> Consultation liée</h5></div>
                    <div class="card-block">
                        <div class="form-group m-b-0">
                            <label class="small text-muted">ID Consultation (optionnel)</label>
                            <input type="number" class="form-control" wire:model="consultation_id"
                                   placeholder="Laisser vide si aucune">
                            <small class="text-muted">Associer à une consultation existante</small>
                        </div>
                    </div>
                </div>

                
                <div class="card">
                    <div class="card-block">
                        <button type="submit" class="btn btn-primary btn-block m-b-10">
                            <div wire:loading wire:target="save">
                                <span class="fa fa-spinner fa-spin"></span>
                            </div>
                            <i class="feather icon-save"></i>
                            <?php echo e($isEdit ? 'Mettre à jour l\'ordonnance' : 'Enregistrer l\'ordonnance'); ?>

                        </button>
                        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-default btn-block">
                            <i class="feather icon-x"></i> Annuler
                        </a>
                    </div>
                </div>

                
                <div class="card" style="border-left: 3px solid #4099ff;">
                    <div class="card-block p-15">
                        <p class="m-b-5"><strong><i class="feather icon-info text-primary"></i> Aide</strong></p>
                        <ul class="list-unstyled small text-muted m-b-0">
                            <li class="m-b-5">Sélectionnez un médicament dans la liste ou saisissez son nom librement.</li>
                            <li class="m-b-5">Ajoutez autant de lignes que nécessaire.</li>
                            <li>L'ordonnance sera numérotée automatiquement (ORD-AAAA-XXXXX).</li>
                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </form>
</div>
<?php /**PATH E:\______laravel Project 2026\wa_cabinet_2026_v2\resources\views/livewire/prescription/prescription-form.blade.php ENDPATH**/ ?>