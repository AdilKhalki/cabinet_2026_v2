<?php
if (!function_exists('_a514d54e00d5ea618a8afa09a186ad66')):
function _a514d54e00d5ea618a8afa09a186ad66($__blaze, $__data = [], $__slots = [], $__bound = [], $__this = null) {
$__env = $__blaze->env;
$__slots['slot'] ??= new \Illuminate\View\ComponentSlot('');
if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::sanitized($__data, $__bound);
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP); unset($__data, $__bound);
ob_start();
?>


<?php $tooltipPosition = $tooltipPosition ??= $attributes->pluck('tooltip:position'); ?>
<?php $tooltipKbd = $tooltipKbd ??= $attributes->pluck('tooltip:kbd'); ?>
<?php $tooltip = $tooltip ??= $attributes->pluck('tooltip'); ?>
<?php $iconTrailing ??= $attributes->pluck('icon:trailing'); ?>
<?php $iconVariant ??= $attributes->pluck('icon:variant'); ?>

<?php
$__defaults = [
    'tooltipPosition' => 'right',
    'tooltipKbd' => null,
    'tooltip' => null,
    'iconVariant' => 'outline',
    'iconTrailing' => null,
    'badgeColor' => null,
    'iconDot' => null,
    'accent' => true,
    'badge' => null,
    'icon' => null,
];
$tooltipPosition ??= $attributes['tooltip-position'] ?? $attributes['tooltipPosition'] ?? $__defaults['tooltipPosition']; unset($attributes['tooltipPosition'], $attributes['tooltip-position']);
$tooltipKbd ??= $attributes['tooltip-kbd'] ?? $attributes['tooltipKbd'] ?? $__defaults['tooltipKbd']; unset($attributes['tooltipKbd'], $attributes['tooltip-kbd']);
$tooltip ??= $attributes['tooltip'] ?? $__defaults['tooltip']; unset($attributes['tooltip']);
$iconVariant ??= $attributes['icon-variant'] ?? $attributes['iconVariant'] ?? $__defaults['iconVariant']; unset($attributes['iconVariant'], $attributes['icon-variant']);
$iconTrailing ??= $attributes['icon-trailing'] ?? $attributes['iconTrailing'] ?? $__defaults['iconTrailing']; unset($attributes['iconTrailing'], $attributes['icon-trailing']);
$badgeColor ??= $attributes['badge-color'] ?? $attributes['badgeColor'] ?? $__defaults['badgeColor']; unset($attributes['badgeColor'], $attributes['badge-color']);
$iconDot ??= $attributes['icon-dot'] ?? $attributes['iconDot'] ?? $__defaults['iconDot']; unset($attributes['iconDot'], $attributes['icon-dot']);
$accent ??= $attributes['accent'] ?? $__defaults['accent']; unset($attributes['accent']);
$badge ??= $attributes['badge'] ?? $__defaults['badge']; unset($attributes['badge']);
$icon ??= $attributes['icon'] ?? $__defaults['icon']; unset($attributes['icon']);
unset($__defaults);
?>

<?php
$tooltip ??= $slot->isNotEmpty() ? (string) $slot : null;

// Size-up icons in square/icon-only buttons...
$iconClasses = Flux::classes('size-4')
    ->add('in-data-flux-sidebar-group-dropdown:text-zinc-400! dark:in-data-flux-sidebar-group-dropdown:text-white/80!')
    ->add('[[data-flux-sidebar-item]:hover_&]:text-current!');

$classes = Flux::classes()
    ->add('h-8 in-data-flux-sidebar-on-mobile:h-10 relative flex items-center gap-3 rounded-lg')
    ->add('in-data-flux-sidebar-collapsed-desktop:w-10 in-data-flux-sidebar-collapsed-desktop:justify-center')
    ->add('py-0 text-start w-full px-3 has-data-flux-navlist-badge:not-in-data-flux-sidebar-collapsed-desktop:pe-1.5 my-px')
    ->add('text-zinc-500 dark:text-white/80')
    ->add(match ($accent) {
        true => [
            'data-current:text-(--color-accent-content) hover:data-current:text-(--color-accent-content)',
            'data-current:bg-white dark:data-current:bg-white/[7%] data-current:border data-current:border-zinc-200 dark:data-current:border-transparent',
            'hover:text-zinc-800 dark:hover:text-white dark:hover:bg-white/[7%] hover:bg-zinc-800/5 ',
            'border border-transparent',
        ],
        false => [
            'data-current:text-zinc-800 dark:data-current:text-zinc-100 data-current:border-zinc-200',
            'data-current:bg-white dark:data-current:bg-white/10 data-current:border data-current:border-zinc-200 dark:data-current:border-white/10 data-current:shadow-xs',
            'hover:text-zinc-800 dark:hover:text-white',
        ],
    })
    // Override the default styles to match dropdowns for when the item is inside a collapsed group dropdown...
    ->add('in-data-flux-sidebar-group-dropdown:w-auto! in-data-flux-sidebar-group-dropdown:px-2!')
    ->add('in-data-flux-sidebar-group-dropdown:text-zinc-800! in-data-flux-sidebar-group-dropdown:bg-white! in-data-flux-sidebar-group-dropdown:hover:bg-zinc-50!')
    ->add('dark:in-data-flux-sidebar-group-dropdown:text-white! dark:in-data-flux-sidebar-group-dropdown:bg-transparent! dark:in-data-flux-sidebar-group-dropdown:hover:bg-zinc-600!')
    ;
?>

<?php $__blaze->ensureRequired('E:\______laravel Project 2026\wa_cabinet_2026_v2\vendor\livewire\flux\src/../stubs/resources/views/flux/tooltip/index.blade.php', $__blaze->compiledPath.'/2e45799bd25da90c589b131254b29adb.php'); ?>
<?php if (isset($__slots2e45799bd25da90c589b131254b29adb)) $__slotsOriginal = $__slots2e45799bd25da90c589b131254b29adb; ?>
<?php if (isset($__attrs2e45799bd25da90c589b131254b29adb)) $__attrsOriginal = $__attrs2e45799bd25da90c589b131254b29adb; ?>
<?php $__attrs2e45799bd25da90c589b131254b29adb = ['position' => $tooltipPosition]; ?>
<?php $__slots2e45799bd25da90c589b131254b29adb = []; ?>
<?php ob_start(); ?>
    <?php $__blaze->ensureRequired('E:\______laravel Project 2026\wa_cabinet_2026_v2\vendor\livewire\flux\src/../stubs/resources/views/flux/button-or-link.blade.php', $__blaze->compiledPath.'/4abc83593bd19e7d2c6299e37a018a30.php'); ?>
<?php if (isset($__slots4abc83593bd19e7d2c6299e37a018a30)) $__slotsOriginal = $__slots4abc83593bd19e7d2c6299e37a018a30; ?>
<?php if (isset($__attrs4abc83593bd19e7d2c6299e37a018a30)) $__attrsOriginal = $__attrs4abc83593bd19e7d2c6299e37a018a30; ?>
<?php $__attrs4abc83593bd19e7d2c6299e37a018a30 = ['attributes' => $attributes->class($classes),'data-flux-sidebar-item' => true]; ?>
<?php $__slots4abc83593bd19e7d2c6299e37a018a30 = []; ?>
<?php ob_start(); ?>
        <?php if ($icon): ?>
            <div class="relative">
                <?php if (is_string($icon) && $icon !== ''): ?>
                    <?php $blaze_memoized_key = \Livewire\Blaze\Memoizer\Memo::key("flux::icon", ['icon' => $icon, 'variant' => $iconVariant, 'class' => $iconClasses]); ?><?php if ($blaze_memoized_key !== null && \Livewire\Blaze\Memoizer\Memo::has($blaze_memoized_key)) : ?><?php echo \Livewire\Blaze\Memoizer\Memo::get($blaze_memoized_key); ?><?php else : ?><?php ob_start(); ?><?php $__blaze->ensureRequired('E:\______laravel Project 2026\wa_cabinet_2026_v2\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/index.blade.php', $__blaze->compiledPath.'/ed3b5202a273b3982536155f3f3551e6.php'); ?>
<?php $__blaze->pushData(['icon' => $icon,'variant' => $iconVariant,'class' => ''.$iconClasses.'']); ?>
<?php _ed3b5202a273b3982536155f3f3551e6($__blaze, ['icon' => $icon,'variant' => $iconVariant,'class' => ''.$iconClasses.''], [], ['icon', 'variant'], isset($this) ? $this : null); ?>
<?php $__blaze->popData(); ?><?php $blaze_memoized_html = ob_get_clean(); ?><?php if ($blaze_memoized_key !== null) { \Livewire\Blaze\Memoizer\Memo::put($blaze_memoized_key, $blaze_memoized_html); } ?><?php echo $blaze_memoized_html; ?><?php endif; ?>
                <?php else: ?>
                    <?php echo e($icon); ?>

                <?php endif; ?>

                <?php if ($iconDot): ?>
                    <div class="absolute top-[-2px] end-[-2px]">
                        <div class="size-[6px] rounded-full bg-zinc-500 dark:bg-zinc-400"></div>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <?php if ($slot->isNotEmpty()): ?>
            <div class="
                in-data-flux-sidebar-collapsed-desktop:not-in-data-flux-sidebar-group-dropdown:hidden
                flex-1 text-sm font-medium truncate [[data-nav-footer]_&]:hidden [[data-nav-sidebar]_[data-nav-footer]_&]:block" data-content><?php echo e($slot); ?></div>
        <?php endif; ?>

        <?php if (is_string($iconTrailing) && $iconTrailing !== ''): ?>
            <?php $blaze_memoized_key = \Livewire\Blaze\Memoizer\Memo::key("flux::icon", ['icon' => $iconTrailing, 'variant' => $iconVariant, 'class' => 'in-data-flux-sidebar-collapsed-desktop:not-in-data-flux-sidebar-group-dropdown:hidden size-4!']); ?><?php if ($blaze_memoized_key !== null && \Livewire\Blaze\Memoizer\Memo::has($blaze_memoized_key)) : ?><?php echo \Livewire\Blaze\Memoizer\Memo::get($blaze_memoized_key); ?><?php else : ?><?php ob_start(); ?><?php $__blaze->ensureRequired('E:\______laravel Project 2026\wa_cabinet_2026_v2\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/index.blade.php', $__blaze->compiledPath.'/ed3b5202a273b3982536155f3f3551e6.php'); ?>
<?php $__blaze->pushData(['icon' => $iconTrailing,'variant' => $iconVariant,'class' => 'in-data-flux-sidebar-collapsed-desktop:not-in-data-flux-sidebar-group-dropdown:hidden size-4!']); ?>
<?php _ed3b5202a273b3982536155f3f3551e6($__blaze, ['icon' => $iconTrailing,'variant' => $iconVariant,'class' => 'in-data-flux-sidebar-collapsed-desktop:not-in-data-flux-sidebar-group-dropdown:hidden size-4!'], [], ['icon', 'variant'], isset($this) ? $this : null); ?>
<?php $__blaze->popData(); ?><?php $blaze_memoized_html = ob_get_clean(); ?><?php if ($blaze_memoized_key !== null) { \Livewire\Blaze\Memoizer\Memo::put($blaze_memoized_key, $blaze_memoized_html); } ?><?php echo $blaze_memoized_html; ?><?php endif; ?>
        <?php elseif ($iconTrailing): ?>
            <?php echo e($iconTrailing); ?>

        <?php endif; ?>

        <?php if (isset($badge) && $badge !== ''): ?>
            <?php $badgeAttributes = Flux::attributesAfter('badge:', $attributes, ['color' => $badgeColor]); ?>
            <?php $__blaze->ensureRequired('E:\______laravel Project 2026\wa_cabinet_2026_v2\vendor\livewire\flux\src/../stubs/resources/views/flux/navlist/badge.blade.php', $__blaze->compiledPath.'/88171500e5a96179def5c84bac5725d8.php'); ?>
<?php if (isset($__slots88171500e5a96179def5c84bac5725d8)) $__slotsOriginal = $__slots88171500e5a96179def5c84bac5725d8; ?>
<?php if (isset($__attrs88171500e5a96179def5c84bac5725d8)) $__attrsOriginal = $__attrs88171500e5a96179def5c84bac5725d8; ?>
<?php $__attrs88171500e5a96179def5c84bac5725d8 = ['attributes' => $badgeAttributes,'class' => 'in-data-flux-sidebar-collapsed-desktop:not-in-data-flux-sidebar-group-dropdown:hidden']; ?>
<?php $__slots88171500e5a96179def5c84bac5725d8 = []; ?>
<?php ob_start(); ?><?php echo e($badge); ?><?php $__slots88171500e5a96179def5c84bac5725d8['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushData($__attrs88171500e5a96179def5c84bac5725d8); ?>
<?php $__blaze->pushSlots($__slots88171500e5a96179def5c84bac5725d8); ?>
<?php _88171500e5a96179def5c84bac5725d8($__blaze, $__attrs88171500e5a96179def5c84bac5725d8, $__slots88171500e5a96179def5c84bac5725d8, ['attributes'], isset($this) ? $this : null); ?>
<?php if (isset($__slotsOriginal)) { $__slots88171500e5a96179def5c84bac5725d8 = $__slotsOriginal; unset($__slotsOriginal); } ?>
<?php if (isset($__attrsOriginal)) { $__attrs88171500e5a96179def5c84bac5725d8 = $__attrsOriginal; unset($__attrsOriginal); } ?>
<?php $__blaze->popData(); ?>
        <?php endif; ?>
    <?php $__slots4abc83593bd19e7d2c6299e37a018a30['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushData($__attrs4abc83593bd19e7d2c6299e37a018a30); ?>
<?php $__blaze->pushSlots($__slots4abc83593bd19e7d2c6299e37a018a30); ?>
<?php _4abc83593bd19e7d2c6299e37a018a30($__blaze, $__attrs4abc83593bd19e7d2c6299e37a018a30, $__slots4abc83593bd19e7d2c6299e37a018a30, ['attributes', 'data-flux-sidebar-item'], isset($this) ? $this : null); ?>
<?php if (isset($__slotsOriginal)) { $__slots4abc83593bd19e7d2c6299e37a018a30 = $__slotsOriginal; unset($__slotsOriginal); } ?>
<?php if (isset($__attrsOriginal)) { $__attrs4abc83593bd19e7d2c6299e37a018a30 = $__attrsOriginal; unset($__attrsOriginal); } ?>
<?php $__blaze->popData(); ?>

    <?php $__blaze->ensureRequired('E:\______laravel Project 2026\wa_cabinet_2026_v2\vendor\livewire\flux\src/../stubs/resources/views/flux/tooltip/content.blade.php', $__blaze->compiledPath.'/b2bc475e43d9bb81eea1eaafd83272bb.php'); ?>
<?php if (isset($__slotsb2bc475e43d9bb81eea1eaafd83272bb)) $__slotsOriginal = $__slotsb2bc475e43d9bb81eea1eaafd83272bb; ?>
<?php if (isset($__attrsb2bc475e43d9bb81eea1eaafd83272bb)) $__attrsOriginal = $__attrsb2bc475e43d9bb81eea1eaafd83272bb; ?>
<?php $__attrsb2bc475e43d9bb81eea1eaafd83272bb = ['kbd' => $tooltipKbd,'class' => 'not-in-data-flux-sidebar-collapsed-desktop:hidden in-data-flux-sidebar-group-dropdown:hidden cursor-default']; ?>
<?php $__slotsb2bc475e43d9bb81eea1eaafd83272bb = []; ?>
<?php ob_start(); ?>
        <?php echo e($tooltip); ?>

    <?php $__slotsb2bc475e43d9bb81eea1eaafd83272bb['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushData($__attrsb2bc475e43d9bb81eea1eaafd83272bb); ?>
<?php $__blaze->pushSlots($__slotsb2bc475e43d9bb81eea1eaafd83272bb); ?>
<?php _b2bc475e43d9bb81eea1eaafd83272bb($__blaze, $__attrsb2bc475e43d9bb81eea1eaafd83272bb, $__slotsb2bc475e43d9bb81eea1eaafd83272bb, ['kbd'], isset($this) ? $this : null); ?>
<?php if (isset($__slotsOriginal)) { $__slotsb2bc475e43d9bb81eea1eaafd83272bb = $__slotsOriginal; unset($__slotsOriginal); } ?>
<?php if (isset($__attrsOriginal)) { $__attrsb2bc475e43d9bb81eea1eaafd83272bb = $__attrsOriginal; unset($__attrsOriginal); } ?>
<?php $__blaze->popData(); ?>
<?php $__slots2e45799bd25da90c589b131254b29adb['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushData($__attrs2e45799bd25da90c589b131254b29adb); ?>
<?php $__blaze->pushSlots($__slots2e45799bd25da90c589b131254b29adb); ?>
<?php _2e45799bd25da90c589b131254b29adb($__blaze, $__attrs2e45799bd25da90c589b131254b29adb, $__slots2e45799bd25da90c589b131254b29adb, ['position'], isset($this) ? $this : null); ?>
<?php if (isset($__slotsOriginal)) { $__slots2e45799bd25da90c589b131254b29adb = $__slotsOriginal; unset($__slotsOriginal); } ?>
<?php if (isset($__attrsOriginal)) { $__attrs2e45799bd25da90c589b131254b29adb = $__attrsOriginal; unset($__attrsOriginal); } ?>
<?php $__blaze->popData(); ?><?php
echo ltrim(ob_get_clean());
} endif; ?><?php /**PATH E:\______laravel Project 2026\wa_cabinet_2026_v2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/item.blade.php ENDPATH**/ ?>