<?php
    $currentRoute = request()->route()?->getName() ?? '';
    $isActive = fn(string $prefix) => str_starts_with($currentRoute, $prefix);
?>

<nav class="pcoded-navbar"
     navbar-theme="themelight1"
     active-item-theme="theme1"
     sub-item-theme="theme2"
     active-item-style="style0"
     pcoded-navbar-position="fixed">
    <div class="sidebar_toggle"><a href="#"><i class="icon-close icons"></i></a></div>
    <div class="pcoded-inner-navbar main-menu">

        
        <div class="pcoded-navigatio-lavel">Navigation</div>
        <ul class="pcoded-item pcoded-left-item">

            
            <li class="<?php echo e($currentRoute === 'home' ? 'active' : ''); ?>">
                <a href="<?php echo e(route('home')); ?>">
                    <span class="pcoded-micon"><i class="feather icon-home"></i></span>
                    <span class="pcoded-mtext">Tableau de bord</span>
                </a>
            </li>

            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAny', App\Models\Patient::class)): ?>
            <li class="<?php echo e($isActive('patients') ? 'pcoded-trigger active' : ''); ?>">
                <a href="<?php echo e(route('patients.index')); ?>">
                    <span class="pcoded-micon"><i class="feather icon-users"></i></span>
                    <span class="pcoded-mtext">Patients</span>
                </a>
            </li>
            <?php endif; ?>

            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAny', App\Models\Appointment::class)): ?>
            <li class="pcoded-hasmenu <?php echo e($isActive('appointments') ? 'pcoded-trigger active' : ''); ?>"
                dropdown-icon="style1" subitem-icon="style6">
                <a href="javascript:void(0)">
                    <span class="pcoded-micon"><i class="feather icon-calendar"></i></span>
                    <span class="pcoded-mtext">Rendez-vous</span>
                </a>
                <ul class="pcoded-submenu">
                    <li class="<?php echo e($currentRoute === 'appointments.index' ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('appointments.index')); ?>">
                            <span class="pcoded-mtext">Liste des RDV</span>
                        </a>
                    </li>
                    <li class="<?php echo e($currentRoute === 'appointments.calendar' ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('appointments.calendar')); ?>">
                            <span class="pcoded-mtext">Calendrier</span>
                        </a>
                    </li>
                    <li class="<?php echo e($currentRoute === 'appointments.waiting-room' ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('appointments.waiting-room')); ?>">
                            <span class="pcoded-mtext">Salle d'attente</span>
                        </a>
                    </li>
                </ul>
            </li>
            <?php endif; ?>

            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAny', App\Models\Consultation::class)): ?>
            <li class="<?php echo e($isActive('consultations') ? 'pcoded-trigger active' : ''); ?>">
                <a href="<?php echo e(route('consultations.index')); ?>">
                    <span class="pcoded-micon"><i class="feather icon-activity"></i></span>
                    <span class="pcoded-mtext">Consultations</span>
                </a>
            </li>
            <?php endif; ?>

            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAny', App\Models\Prescription::class)): ?>
            <li class="<?php echo e($isActive('prescriptions') ? 'pcoded-trigger active' : ''); ?>">
                <a href="<?php echo e(route('prescriptions.index')); ?>">
                    <span class="pcoded-micon"><i class="feather icon-file-text"></i></span>
                    <span class="pcoded-mtext">Ordonnances</span>
                </a>
            </li>
            <?php endif; ?>

            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAny', App\Models\LabTest::class)): ?>
            <li class="<?php echo e($isActive('lab-tests') ? 'pcoded-trigger active' : ''); ?>">
                <a href="<?php echo e(route('lab-tests.index')); ?>">
                    <span class="pcoded-micon"><i class="feather icon-thermometer"></i></span>
                    <span class="pcoded-mtext">Analyses</span>
                </a>
            </li>
            <?php endif; ?>

            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAny', App\Models\MedicalImage::class)): ?>
            <li class="<?php echo e($isActive('medical-images') ? 'pcoded-trigger active' : ''); ?>">
                <a href="<?php echo e(route('medical-images.index')); ?>">
                    <span class="pcoded-micon"><i class="feather icon-image"></i></span>
                    <span class="pcoded-mtext">Imagerie</span>
                </a>
            </li>
            <?php endif; ?>

            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAny', App\Models\Document::class)): ?>
            <li class="<?php echo e($isActive('documents') ? 'pcoded-trigger active' : ''); ?>">
                <a href="<?php echo e(route('documents.index')); ?>">
                    <span class="pcoded-micon"><i class="feather icon-folder"></i></span>
                    <span class="pcoded-mtext">Documents</span>
                </a>
            </li>
            <?php endif; ?>

            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAny', App\Models\MedicalReport::class)): ?>
            <li class="<?php echo e($isActive('medical-reports') ? 'pcoded-trigger active' : ''); ?>">
                <a href="<?php echo e(route('medical-reports.index')); ?>">
                    <span class="pcoded-micon"><i class="feather icon-clipboard"></i></span>
                    <span class="pcoded-mtext">Rapports Médicaux</span>
                </a>
            </li>
            <?php endif; ?>

            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage medications')): ?>
            <li class="<?php echo e($isActive('medical-acts') ? 'pcoded-trigger active' : ''); ?>">
                <a href="<?php echo e(route('medical-acts.index')); ?>">
                    <span class="pcoded-micon"><i class="feather icon-list"></i></span>
                    <span class="pcoded-mtext">Actes Médicaux</span>
                </a>
            </li>
            <?php endif; ?>

            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage medications')): ?>
            <li class="<?php echo e($isActive('medications') ? 'pcoded-trigger active' : ''); ?>">
                <a href="<?php echo e(route('medications.index')); ?>">
                    <span class="pcoded-micon"><i class="feather icon-package"></i></span>
                    <span class="pcoded-mtext">Médicaments</span>
                </a>
            </li>
            <?php endif; ?>

        </ul>

        
        <div class="pcoded-navigatio-lavel">Finance</div>
        <ul class="pcoded-item pcoded-left-item">

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAny', App\Models\Payment::class)): ?>
            <li class="<?php echo e($isActive('payments') ? 'pcoded-trigger active' : ''); ?>">
                <a href="<?php echo e(route('payments.index')); ?>">
                    <span class="pcoded-micon"><i class="feather icon-credit-card"></i></span>
                    <span class="pcoded-mtext">Paiements</span>
                </a>
            </li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view reports')): ?>
            <li class="<?php echo e($isActive('reports.financial') ? 'pcoded-trigger active' : ''); ?>">
                <a href="<?php echo e(route('reports.financial')); ?>">
                    <span class="pcoded-micon"><i class="feather icon-trending-up"></i></span>
                    <span class="pcoded-mtext">Rapport Financier</span>
                </a>
            </li>
            <?php endif; ?>

        </ul>

        
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view reports')): ?>
        <div class="pcoded-navigatio-lavel">Statistiques</div>
        <ul class="pcoded-item pcoded-left-item">

            <li class="<?php echo e($isActive('reports.stats') ? 'pcoded-trigger active' : ''); ?>">
                <a href="<?php echo e(route('reports.stats')); ?>">
                    <span class="pcoded-micon"><i class="feather icon-bar-chart-2"></i></span>
                    <span class="pcoded-mtext">Statistiques Cabinet</span>
                </a>
            </li>

        </ul>
        <?php endif; ?>

        
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage users')): ?>
        <div class="pcoded-navigatio-lavel">Administration</div>
        <ul class="pcoded-item pcoded-left-item">

            <li class="pcoded-hasmenu <?php echo e($isActive('admin') ? 'pcoded-trigger active' : ''); ?>"
                dropdown-icon="style1" subitem-icon="style6">
                <a href="javascript:void(0)">
                    <span class="pcoded-micon"><i class="feather icon-shield"></i></span>
                    <span class="pcoded-mtext">Gestion Utilisateurs</span>
                </a>
                <ul class="pcoded-submenu">
                    <li>
                        <a href="<?php echo e(route('admin.users.index')); ?>">
                            <span class="pcoded-mtext">Utilisateurs</span>
                        </a>
                    </li>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage roles')): ?>
                    <li>
                        <a href="<?php echo e(route('admin.roles.index')); ?>">
                            <span class="pcoded-mtext">Rôles & Permissions</span>
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            </li>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view activity-log')): ?>
            <li class="<?php echo e($isActive('admin.activity-log') ? 'pcoded-trigger active' : ''); ?>">
                <a href="<?php echo e(route('admin.activity-log')); ?>">
                    <span class="pcoded-micon"><i class="feather icon-eye"></i></span>
                    <span class="pcoded-mtext">Journal d'Audit</span>
                </a>
            </li>
            <?php endif; ?>

            <li class="<?php echo e($isActive('admin.settings') ? 'pcoded-trigger active' : ''); ?>">
                <a href="<?php echo e(route('admin.settings')); ?>">
                    <span class="pcoded-micon"><i class="feather icon-settings"></i></span>
                    <span class="pcoded-mtext">Paramètres Cabinet</span>
                </a>
            </li>

        </ul>
        <?php endif; ?>

    </div>
</nav>
<?php /**PATH E:\______laravel Project 2026\wa_cabinet_2026_v2\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>