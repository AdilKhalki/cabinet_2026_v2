<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'DejaVu Sans', sans-serif; font-size: 12px; color: #333; padding: 30px 35px 20px 35px; }
        .header { background: #353c4e; color: white; padding: 20px; margin-bottom: 20px; }
        .header-title { font-size: 24px; font-weight: bold; color: #01a9ac; }
        .header-subtitle { font-size: 12px; color: #aaa; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 15px; }
        th { background: #353c4e; color: white; padding: 8px; text-align: left; }
        td { padding: 8px; border-bottom: 1px solid #eee; }
        .total-row { background: #f8f9fa; font-weight: bold; }
        .grand-total { background: #01a9ac; color: white; }
        .badge-paid { background: #28a745; color: white; padding: 3px 8px; border-radius: 3px; }
        .badge-pending { background: #ffc107; color: #333; padding: 3px 8px; border-radius: 3px; }
        .badge-cancelled { background: #dc3545; color: white; padding: 3px 8px; border-radius: 3px; }
        .clearfix::after { content: ''; display: table; clear: both; }
    </style>
</head>
<body>
    <div class="header clearfix">
        <div style="float:left;">
            <div class="header-title">FACTURE</div>
            <div class="header-subtitle"><?php echo e($payment->invoice_number); ?></div>
        </div>
        <div style="float:right; text-align:right; color: #ccc; font-size: 11px;">
            <?php echo e($settings['cabinet_name'] ?? 'Cabinet Médical'); ?><br>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($settings['cabinet_address'])): ?><?php echo e($settings['cabinet_address']); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($settings['cabinet_city'])): ?>, <?php echo e($settings['cabinet_city']); ?><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?><br><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($settings['cabinet_phone'])): ?>Tél : <?php echo e($settings['cabinet_phone']); ?><br><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            Dr. <?php echo e($payment->doctor?->name ?? ($settings['doctor_name'] ?? '')); ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($payment->doctor?->license_number ?? ($settings['doctor_license'] ?? null)): ?>
                — INPE : <?php echo e($payment->doctor?->license_number ?? $settings['doctor_license']); ?>

            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?><br>
            Date : <?php echo e($payment->payment_date?->format('d/m/Y') ?? $payment->created_at->format('d/m/Y')); ?>

        </div>
    </div>

    
    <div style="margin-bottom: 20px;">
        <strong>Patient :</strong> <?php echo e($payment->patient->full_name); ?><br>
        <strong>Dossier :</strong> <?php echo e($payment->patient->dossier_number); ?><br>
        <strong>Téléphone :</strong> <?php echo e($payment->patient->phone); ?><br>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($payment->patient->insurance_name): ?>
            <strong>Mutuelle :</strong> <?php echo e($payment->patient->insurance_name); ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($payment->patient->insurance_number): ?>(<?php echo e($payment->patient->insurance_number); ?>)<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>

    
    <table>
        <thead>
            <tr>
                <th>Description</th>
                <th style="text-align:center;">Qté</th>
                <th style="text-align:right;">Prix Unit.</th>
                <th style="text-align:right;">Total</th>
            </tr>
        </thead>
        <tbody>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $payment->lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                <tr>
                    <td><?php echo e($line->description); ?></td>
                    <td style="text-align:center;"><?php echo e($line->quantity); ?></td>
                    <td style="text-align:right;"><?php echo e(number_format($line->unit_price, 2, ',', ' ')); ?> MAD</td>
                    <td style="text-align:right;"><?php echo e(number_format($line->total_price, 2, ',', ' ')); ?> MAD</td>
                </tr>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </tbody>
        <tfoot>
            <tr class="total-row">
                <td colspan="3">Sous-total</td>
                <td style="text-align:right;"><?php echo e(number_format($payment->subtotal, 2, ',', ' ')); ?> MAD</td>
            </tr>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($payment->discount > 0): ?>
                <tr>
                    <td colspan="3">Remise</td>
                    <td style="text-align:right;">- <?php echo e(number_format($payment->discount, 2, ',', ' ')); ?> MAD</td>
                </tr>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($payment->insurance_coverage > 0): ?>
                <tr>
                    <td colspan="3">Part assurance</td>
                    <td style="text-align:right;">- <?php echo e(number_format($payment->insurance_coverage, 2, ',', ' ')); ?> MAD</td>
                </tr>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <tr class="grand-total">
                <td colspan="3"><strong>TOTAL À PAYER</strong></td>
                <td style="text-align:right;"><strong><?php echo e(number_format($payment->total_amount, 2, ',', ' ')); ?> MAD</strong></td>
            </tr>
            <tr>
                <td colspan="3">Montant payé</td>
                <td style="text-align:right; color: green;"><?php echo e(number_format($payment->amount_paid, 2, ',', ' ')); ?> MAD</td>
            </tr>
            <tr class="<?php echo e($payment->amount_due > 0 ? '' : 'total-row'); ?>">
                <td colspan="3"><strong>Reste à payer</strong></td>
                <td style="text-align:right; color: <?php echo e($payment->amount_due > 0 ? 'red' : 'green'); ?>;">
                    <strong><?php echo e(number_format($payment->amount_due, 2, ',', ' ')); ?> MAD</strong>
                </td>
            </tr>
        </tfoot>
    </table>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($amountInWords)): ?>
        <div style="margin-top: 5px; font-size: 11px;">
            Arrêtée la présente facture à la somme de : <strong><?php echo e($amountInWords); ?></strong>.
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <div style="text-align:right; margin-top: 10px;">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($payment->payment_method): ?>
            <span style="font-size: 11px; color: #666;">Mode : <?php echo e(\App\Models\Payment::METHOD_LABELS[$payment->payment_method] ?? $payment->payment_method); ?></span>&nbsp;
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <span class="<?php echo e($payment->status === 'paid' ? 'badge-paid' : ($payment->isClosed() ? 'badge-cancelled' : 'badge-pending')); ?>">
            <?php echo e(\App\Models\Payment::STATUS_LABELS[$payment->status] ?? $payment->status); ?>

        </span>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($payment->notes): ?>
        <div style="margin-top: 15px; color: #666; font-size: 11px;">
            <strong>Notes :</strong> <?php echo e($payment->notes); ?>

        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <div style="margin-top: 40px; border-top: 1px solid #ddd; padding-top: 15px; font-size: 10px; color: #999; text-align: center;">
        <?php echo e($settings['pdf_footer_text'] ?? ('Merci de votre confiance — '.($settings['cabinet_name'] ?? 'Cabinet Médical'))); ?>

    </div>
</body>
</html>
<?php /**PATH E:\______laravel Project 2026\wa_cabinet_2026_v2\resources\views/pdf/invoice.blade.php ENDPATH**/ ?>