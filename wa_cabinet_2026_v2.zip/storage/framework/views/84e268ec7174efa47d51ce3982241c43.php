<div>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <div class="card">
        <div class="card-header">
            <h5><i class="feather icon-file-text"></i> Rapports Médicaux</h5>
            <div class="card-header-right">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Models\MedicalReport::class)): ?>
                <a href="<?php echo e(route('medical-reports.create')); ?>" class="btn btn-primary btn-sm">
                    <i class="feather icon-plus"></i> Nouveau rapport
                </a>
                <?php endif; ?>
            </div>
        </div>
        <div class="card-block">

            
            <div class="row m-b-20">
                <div class="col-md-5">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="feather icon-search"></i></span>
                        <input type="text" wire:model.live.debounce.300ms="search" class="form-control" placeholder="Rechercher par patient, titre, numéro...">
                    </div>
                </div>
                <div class="col-md-4">
                    <select wire:model.live="typeFilter" class="form-control">
                        <option value="">-- Tous les types --</option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                            <option value="<?php echo e($key); ?>"><?php echo e($label); ?></option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </select>
                </div>
                <div class="col-md-3 text-right">
                    <span class="text-muted"><?php echo e($reports->total()); ?> rapport(s)</span>
                </div>
            </div>

            
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>N° Rapport</th>
                            <th>Patient</th>
                            <th>Type</th>
                            <th>Titre</th>
                            <th>Date</th>
                            <th>Médecin</th>
                            <th style="width: 150px;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                            <?php
                                $typeColors = [
                                    'sick_leave'          => 'bg-warning',
                                    'fitness_certificate' => 'bg-success',
                                    'medical_certificate' => 'bg-info',
                                    'referral'            => 'bg-primary',
                                    'prescription'        => 'bg-default text-dark',
                                    'surgery_report'      => 'bg-danger',
                                    'hospitalization'     => 'bg-danger',
                                    'other'               => 'bg-default text-dark',
                                ];
                                $typeColor = $typeColors[$report->type] ?? 'badge bg-default text-dark';
                                $typeLabel = $types[$report->type] ?? $report->type;
                            ?>
                            <tr>
                                <td><strong><?php echo e($report->report_number ?? ('RPT-' . str_pad($report->id, 5, '0', STR_PAD_LEFT))); ?></strong></td>
                                <td><?php echo e($report->patient->full_name ?? '—'); ?></td>
                                <td><span class="badge <?php echo e($typeColor); ?>"><?php echo e($typeLabel); ?></span></td>
                                <td><?php echo e($report->title); ?></td>
                                <td><?php echo e($report->report_date ? \Carbon\Carbon::parse($report->report_date)->format('d/m/Y') : '—'); ?></td>
                                <td><?php echo e($report->doctor->name ?? '—'); ?></td>
                                <td>
                                    <a href="<?php echo e(route('medical-reports.show', $report)); ?>" class="btn btn-info btn-sm" title="Voir">
                                        <i class="feather icon-eye"></i>
                                    </a>
                                    <a href="<?php echo e(route('medical-reports.pdf', $report)); ?>" target="_blank" class="btn btn-secondary btn-sm" title="Télécharger PDF">
                                        <i class="feather icon-file"></i> PDF
                                    </a>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $report)): ?>
                                    <a href="<?php echo e(route('medical-reports.edit', $report)); ?>" class="btn btn-warning btn-sm" title="Modifier">
                                        <i class="feather icon-edit"></i>
                                    </a>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $report)): ?>
                                    <button type="button"
                                        wire:click="delete(<?php echo e($report->id); ?>)"
                                        wire:confirm="Êtes-vous sûr de vouloir supprimer ce rapport ?"
                                        class="btn btn-danger btn-sm" title="Supprimer">
                                        <i class="feather icon-trash-2"></i>
                                    </button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            <tr>
                                <td colspan="7" class="text-center text-muted p-20">
                                    <i class="feather icon-file-text" style="font-size: 2em;"></i>
                                    <p>Aucun rapport médical trouvé.</p>
                                </td>
                            </tr>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="m-t-20">
                <?php echo e($reports->links('pagination::bootstrap-5')); ?>

            </div>

        </div>
    </div>
</div>
<?php /**PATH E:\______laravel Project 2026\wa_cabinet_2026_v2\resources\views/livewire/medical-report/medical-report-index.blade.php ENDPATH**/ ?>