<div>
    
    <div class="card">
        <div class="card-block">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <h4 class="m-b-5">
                        <i class="feather icon-file-text text-primary"></i>
                        <?php echo e($prescription->prescription_number); ?>

                    </h4>
                    <p class="text-muted m-b-0">
                        Patient : <strong><?php echo e($prescription->patient->full_name); ?></strong>
                        &mdash; <?php echo e($prescription->patient->dossier_number); ?>

                    </p>
                    <p class="text-muted m-b-0">
                        Date : <?php echo e($prescription->prescribed_at
                            ? \Carbon\Carbon::parse($prescription->prescribed_at)->format('d/m/Y')
                            : $prescription->created_at->format('d/m/Y')); ?>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($prescription->is_printed): ?>
                            <span class="label label-success m-l-10">
                                <i class="feather icon-printer"></i> Imprimée
                            </span>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </p>
                </div>
                <div class="col-md-6 text-right">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('print', $prescription)): ?>
                    <a href="<?php echo e(route('prescriptions.pdf', $prescription->id)); ?>"
                       target="_blank" class="btn btn-primary btn-sm m-r-5">
                        <i class="feather icon-printer"></i> Imprimer PDF
                    </a>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $prescription)): ?>
                    <a href="<?php echo e(route('prescriptions.edit', $prescription->id)); ?>" class="btn btn-warning btn-sm m-r-5">
                        <i class="feather icon-edit"></i> Modifier
                    </a>
                    <?php endif; ?>
                    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-default btn-sm">
                        <i class="feather icon-arrow-left"></i> Retour
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        
        <div class="col-md-6">
            <div class="card">
                <div class="card-header"><h5><i class="feather icon-user"></i> Médecin</h5></div>
                <div class="card-block">
                    <table class="table table-condensed m-b-0">
                        <tr>
                            <th style="width:40%">Nom</th>
                            <td>Dr. <?php echo e($prescription->doctor->name); ?></td>
                        </tr>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($prescription->doctor->speciality): ?>
                        <tr>
                            <th>Spécialité</th>
                            <td><?php echo e($prescription->doctor->speciality); ?></td>
                        </tr>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($prescription->doctor->license_number): ?>
                        <tr>
                            <th>N° Inpe</th>
                            <td><?php echo e($prescription->doctor->license_number); ?></td>
                        </tr>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($prescription->doctor->phone): ?>
                        <tr>
                            <th>Téléphone</th>
                            <td><?php echo e($prescription->doctor->phone); ?></td>
                        </tr>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </table>
                </div>
            </div>
        </div>

        
        <div class="col-md-6">
            <div class="card">
                <div class="card-header"><h5><i class="feather icon-users"></i> Patient</h5></div>
                <div class="card-block">
                    <table class="table table-condensed m-b-0">
                        <tr>
                            <th style="width:40%">Nom</th>
                            <td><?php echo e($prescription->patient->full_name); ?></td>
                        </tr>
                        <tr>
                            <th>Date naissance</th>
                            <td><?php echo e($prescription->patient->birth_date
                                ? \Carbon\Carbon::parse($prescription->patient->birth_date)->format('d/m/Y')
                                : '-'); ?>

                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($prescription->patient->age): ?>
                                    (<?php echo e($prescription->patient->age); ?> ans)
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th>Téléphone</th>
                            <td><?php echo e($prescription->patient->phone ?? '-'); ?></td>
                        </tr>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($prescription->patient->known_allergies): ?>
                        <tr>
                            <th>Allergies</th>
                            <td><span class="text-danger"><?php echo e($prescription->patient->known_allergies); ?></span></td>
                        </tr>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </table>
                </div>
            </div>
        </div>
    </div>

    
    <div class="card">
        <div class="card-header">
            <h5>
                <span style="font-size:1.4em;font-weight:700;font-family:serif;margin-right:10px;">&#8478;</span>
                Médicaments prescrits
            </h5>
        </div>
        <div class="card-block">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($prescription->lines->isEmpty()): ?>
                <p class="text-center text-muted p-20">Aucun médicament sur cette ordonnance.</p>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Médicament</th>
                                <th>Forme</th>
                                <th>Dosage</th>
                                <th>Fréquence</th>
                                <th>Durée</th>
                                <th>Voie</th>
                                <th>Instructions</th>
                                <th>Qté</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $prescription->lines->sortBy('sort_order'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                            <tr>
                                <td><?php echo e($i + 1); ?></td>
                                <td>
                                    <strong><?php echo e($line->medication_name); ?></strong>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($line->medication): ?>
                                        <br><small class="text-muted"><?php echo e($line->medication->generic_name); ?></small>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </td>
                                <td><?php echo e($line->medication->dosage_form ?? '-'); ?></td>
                                <td><?php echo e($line->dosage ?? '-'); ?></td>
                                <td><?php echo e($line->frequency ?? '-'); ?></td>
                                <td><?php echo e($line->duration_days ? $line->duration_days.' j' : '-'); ?></td>
                                <td><?php echo e($line->route ?? '-'); ?></td>
                                <td><?php echo e($line->instructions ?? '-'); ?></td>
                                <td><?php echo e($line->quantity ?? '-'); ?></td>
                            </tr>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($prescription->notes): ?>
    <div class="card">
        <div class="card-header"><h5>Notes</h5></div>
        <div class="card-block">
            <p style="white-space:pre-wrap;"><?php echo e($prescription->notes); ?></p>
        </div>
    </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>
<?php /**PATH E:\______laravel Project 2026\wa_cabinet_2026_v2\resources\views/livewire/prescription/prescription-show.blade.php ENDPATH**/ ?>