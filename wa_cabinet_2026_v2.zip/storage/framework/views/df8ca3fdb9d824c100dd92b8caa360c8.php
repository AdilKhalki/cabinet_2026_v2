
<img src="<?php echo e(asset('images/logo.png')); ?>" alt="Logo" >
<?php /**PATH E:\______laravel Project 2026\wa_cabinet_2026_v2\resources\views/components/app-logo-icon.blade.php ENDPATH**/ ?>