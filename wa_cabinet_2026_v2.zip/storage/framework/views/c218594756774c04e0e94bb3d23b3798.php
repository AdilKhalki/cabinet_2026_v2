<div wire:poll.30000ms>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <div class="row">
        <div class="col-md-3">
            <div class="card bg-c-blue">
                <div class="card-block text-white text-center">
                    <h2><?php echo e($this->todayStats['total']); ?></h2>
                    <p><i class="feather icon-calendar"></i> Total RDV du jour</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-c-yellow">
                <div class="card-block text-white text-center">
                    <h2><?php echo e($this->todayStats['waiting']); ?></h2>
                    <p><i class="feather icon-clock"></i> En attente</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-c-green">
                <div class="card-block text-white text-center">
                    <h2><?php echo e($this->todayStats['completed']); ?></h2>
                    <p><i class="feather icon-check-circle"></i> Consultés</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-c-pink">
                <div class="card-block text-white text-center">
                    <h2><?php echo e($this->todayStats['cancelled']); ?></h2>
                    <p><i class="feather icon-x-circle"></i> Annulés / absents</p>
                </div>
            </div>
        </div>
    </div>

    
    <div class="card">
        <div class="card-header">
            <h5>
                <i class="feather icon-users"></i> File d'attente
                <span class="label label-warning m-l-5"><?php echo e($this->waitingPatients->count()); ?> patient(s)</span>
            </h5>
            <div class="card-header-right">
                <small class="text-muted">
                    <i class="feather icon-refresh-cw"></i> Actualisation automatique toutes les 30 sec.
                </small>
            </div>
        </div>
        <div class="card-block">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $this->waitingPatients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $appt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                <div class="card m-b-10" style="border-left: 4px solid <?php echo e($appt->status === 'in_progress' ? '#01a9ac' : '#f4a100'); ?>;">
                    <div class="card-block">
                        <div class="row align-items-center">
                            <div class="col-md-1 text-center">
                                <h2 style="color: <?php echo e($appt->status === 'in_progress' ? '#01a9ac' : '#f4a100'); ?>;">
                                    <?php echo e($index + 1); ?>

                                </h2>
                            </div>
                            <div class="col-md-5">
                                <h5 class="m-0"><?php echo e($appt->patient->full_name); ?></h5>
                                <small class="text-muted"><?php echo e($appt->patient->dossier_number); ?></small>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if (! (auth()->user()->isMedecin())): ?>
                                    <small class="text-muted"> · Dr. <?php echo e($appt->doctor->name); ?></small>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                <br>
                                <span class="label label-<?php echo e($appt->status === 'in_progress' ? 'success' : 'warning'); ?>">
                                    <?php echo e($appt->status === 'in_progress' ? 'En consultation' : 'En attente'); ?>

                                </span>
                            </div>
                            <div class="col-md-3">
                                <p class="m-0"><strong>RDV :</strong> <?php echo e($appt->scheduled_at->format('H:i')); ?></p>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($appt->arrived_at): ?>
                                    <p class="m-0"><strong>Arrivé :</strong> <?php echo e($appt->arrived_at->format('H:i')); ?></p>
                                    <small class="text-muted">Attente : <?php echo e($appt->arrived_at->diffForHumans()); ?></small>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                            <div class="col-md-3 text-right">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $appt)): ?>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($appt->status === 'waiting'): ?>
                                    <button wire:click="callNext(<?php echo e($appt->id); ?>)"
                                            class="btn btn-success btn-sm">
                                        <i class="feather icon-arrow-right"></i> Appeler
                                    </button>
                                    <button wire:click="markNoShow(<?php echo e($appt->id); ?>)"
                                            wire:confirm="Marquer ce patient comme absent ?"
                                            class="btn btn-danger btn-sm m-t-5">
                                        <i class="feather icon-user-x"></i> Absent
                                    </button>
                                <?php else: ?>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($appt->consultation): ?>
                                        <a href="<?php echo e(route('consultations.edit', $appt->consultation->id)); ?>"
                                           class="btn btn-primary btn-sm">
                                            <i class="feather icon-activity"></i> Reprendre
                                        </a>
                                    <?php else: ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Models\Consultation::class)): ?>
                                        <a href="<?php echo e(route('consultations.create', ['appointmentId' => $appt->id])); ?>"
                                           class="btn btn-primary btn-sm">
                                            <i class="feather icon-activity"></i> Consulter
                                        </a>
                                        <?php endif; ?>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    <button wire:click="markCompleted(<?php echo e($appt->id); ?>)"
                                            class="btn btn-info btn-sm m-t-5">
                                        <i class="feather icon-check"></i> Terminé
                                    </button>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <div class="text-center p-30">
                    <i class="feather icon-smile" style="font-size:3em;color:#01a9ac;"></i>
                    <h4 class="m-t-15">Salle d'attente vide</h4>
                    <p class="text-muted">Aucun patient en attente pour le moment.</p>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>

    
    <div class="card">
        <div class="card-header">
            <h5>
                <i class="feather icon-clock"></i> Attendus aujourd'hui
                <span class="label label-primary m-l-5"><?php echo e($this->expectedPatients->count()); ?></span>
            </h5>
        </div>
        <div class="card-block">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($this->expectedPatients->isEmpty()): ?>
                <p class="text-center text-muted m-0">Aucun autre rendez-vous prévu aujourd'hui.</p>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover m-0">
                        <thead>
                            <tr><th>Heure</th><th>Patient</th><th>Médecin</th><th>Statut</th><th class="text-right">Action</th></tr>
                        </thead>
                        <tbody>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $this->expectedPatients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                <tr <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'expected-'.e($appt->id).''; ?>wire:key="expected-<?php echo e($appt->id); ?>">
                                    <td>
                                        <?php echo e($appt->scheduled_at->format('H:i')); ?>

                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($appt->scheduled_at->isPast()): ?>
                                            <span class="label label-danger" style="font-size:9px;">En retard</span>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </td>
                                    <td><?php echo e($appt->patient->full_name); ?> <small class="text-muted"><?php echo e($appt->patient->dossier_number); ?></small></td>
                                    <td>Dr. <?php echo e($appt->doctor->name); ?></td>
                                    <td><span class="label <?php echo e($appt->status_color); ?>"><?php echo e($appt->status_label); ?></span></td>
                                    <td class="text-right">
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $appt)): ?>
                                            <button wire:click="markArrived(<?php echo e($appt->id); ?>)" class="btn btn-warning btn-sm">
                                                <i class="feather icon-user-check"></i> Arrivé
                                            </button>
                                            <button wire:click="markNoShow(<?php echo e($appt->id); ?>)"
                                                    wire:confirm="Marquer ce patient comme absent ?"
                                                    class="btn btn-default btn-sm">
                                                <i class="feather icon-user-x"></i> Absent
                                            </button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH E:\______laravel Project 2026\wa_cabinet_2026_v2\resources\views/livewire/appointment/waiting-room.blade.php ENDPATH**/ ?>