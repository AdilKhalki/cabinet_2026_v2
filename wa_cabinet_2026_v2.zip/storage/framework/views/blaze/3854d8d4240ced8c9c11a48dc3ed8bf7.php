<?php
if (!function_exists('__3854d8d4240ced8c9c11a48dc3ed8bf7')):
function __3854d8d4240ced8c9c11a48dc3ed8bf7($__blaze, $__data = [], $__slots = [], $__bound = [], $__this = null) {
$__env = $__blaze->env;

if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::sanitized($__data, $__bound);
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP); unset($__data, $__bound);
ob_start();
?>


<?php
$__defaults = [
    'name' => null,
];
$name ??= $attributes['name'] ?? $__defaults['name']; unset($attributes['name']);
unset($__defaults);
?>

<?php
// We only want to show the name attribute on the checkbox if it has been set
// manually, but not if it has been set from the wire:model attribute...
$showName = isset($name);

if (! isset($name)) {
    $name = $attributes->whereStartsWith('wire:model')->first();
}

$classes = Flux::classes()
    ->add('flex size-[1.125rem] rounded-[.3rem] mt-px outline-offset-2')
    ;
?>

<?php $__blaze->ensureRequired('E:\______laravel Project 2026\wa_cabinet_2026_v2\vendor\livewire\flux\src/../stubs/resources/views/flux/with-inline-field.blade.php', $__blaze->compiledPath.'/d123d5ee1e8419c63be3f77deeeacd22.php'); ?>
<?php if (isset($__slotsd123d5ee1e8419c63be3f77deeeacd22)) $__slotsOriginal = $__slotsd123d5ee1e8419c63be3f77deeeacd22; ?>
<?php if (isset($__attrsd123d5ee1e8419c63be3f77deeeacd22)) $__attrsOriginal = $__attrsd123d5ee1e8419c63be3f77deeeacd22; ?>
<?php $__attrsd123d5ee1e8419c63be3f77deeeacd22 = ['attributes' => $attributes]; ?>
<?php $__slotsd123d5ee1e8419c63be3f77deeeacd22 = []; ?>
<?php ob_start(); ?>
    <ui-checkbox <?php echo e($attributes->class($classes)); ?> <?php if($showName): ?> name="<?php echo e($name); ?>" <?php endif; ?> data-flux-control data-flux-checkbox>
        <?php $__blaze->ensureRequired('E:\______laravel Project 2026\wa_cabinet_2026_v2\vendor\livewire\flux\src/../stubs/resources/views/flux/checkbox/indicator.blade.php', $__blaze->compiledPath.'/13565759844fe17c68161b34930577d4.php'); ?>
<?php $__blaze->pushData([]); ?>
<?php __13565759844fe17c68161b34930577d4($__blaze, [], [], [], isset($this) ? $this : null); ?>
<?php $__blaze->popData(); ?>
    </ui-checkbox>
<?php $__slotsd123d5ee1e8419c63be3f77deeeacd22['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushData($__attrsd123d5ee1e8419c63be3f77deeeacd22); ?>
<?php $__blaze->pushSlots($__slotsd123d5ee1e8419c63be3f77deeeacd22); ?>
<?php __d123d5ee1e8419c63be3f77deeeacd22($__blaze, $__attrsd123d5ee1e8419c63be3f77deeeacd22, $__slotsd123d5ee1e8419c63be3f77deeeacd22, ['attributes'], isset($this) ? $this : null); ?>
<?php if (isset($__slotsOriginal)) { $__slotsd123d5ee1e8419c63be3f77deeeacd22 = $__slotsOriginal; unset($__slotsOriginal); } ?>
<?php if (isset($__attrsOriginal)) { $__attrsd123d5ee1e8419c63be3f77deeeacd22 = $__attrsOriginal; unset($__attrsOriginal); } ?>
<?php $__blaze->popData(); ?>
<?php
echo $__blaze->processPassthroughContent('ltrim', ltrim(ob_get_clean()));
} endif; ?><?php /**PATH E:\______laravel Project 2026\wa_cabinet_2026_v2\vendor\livewire\flux\src/../stubs/resources/views/flux/checkbox/variants/default.blade.php ENDPATH**/ ?>