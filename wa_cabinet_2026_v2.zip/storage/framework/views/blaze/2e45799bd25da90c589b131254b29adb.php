<?php
if (!function_exists('__2e45799bd25da90c589b131254b29adb')):
function __2e45799bd25da90c589b131254b29adb($__blaze, $__data = [], $__slots = [], $__bound = [], $__this = null) {
$__env = $__blaze->env;
$__slots['slot'] ??= new \Illuminate\View\ComponentSlot('');
if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::sanitized($__data, $__bound);
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP); unset($__data, $__bound);
ob_start();
?>


<?php
$__defaults = [
    'interactive' => null,
    'position' => 'top',
    'align' => 'center',
    'content' => null,
    'kbd' => null,
    'toggleable' => null,
];
$interactive ??= $attributes['interactive'] ?? $__defaults['interactive']; unset($attributes['interactive']);
$position ??= $attributes['position'] ?? $__defaults['position']; unset($attributes['position']);
$align ??= $attributes['align'] ?? $__defaults['align']; unset($attributes['align']);
$content ??= $attributes['content'] ?? $__defaults['content']; unset($attributes['content']);
$kbd ??= $attributes['kbd'] ?? $__defaults['kbd']; unset($attributes['kbd']);
$toggleable ??= $attributes['toggleable'] ?? $__defaults['toggleable']; unset($attributes['toggleable']);
unset($__defaults);
?>

<?php
// Support adding the .self modifier to the wire:model directive...
if (($wireModel = $attributes->wire('model')) && $wireModel->directive && ! $wireModel->hasModifier('self')) {
    unset($attributes[$wireModel->directive]);

    $wireModel->directive .= '.self';

    $attributes = $attributes->merge([$wireModel->directive => $wireModel->value]);
}
?>

<?php if ($toggleable): ?>
    <ui-dropdown position="<?php echo e($position); ?> <?php echo e($align); ?>" <?php echo e($attributes); ?> data-flux-tooltip>
        <?php echo e($slot); ?>


        <?php if ($content !== null): ?>
            <?php $__blaze->ensureRequired('E:\______laravel Project 2026\wa_cabinet_2026_v2\vendor\livewire\flux\src/../stubs/resources/views/flux/tooltip/content.blade.php', $__blaze->compiledPath.'/b2bc475e43d9bb81eea1eaafd83272bb.php'); ?>
<?php if (isset($__slotsb2bc475e43d9bb81eea1eaafd83272bb)) $__slotsOriginal = $__slotsb2bc475e43d9bb81eea1eaafd83272bb; ?>
<?php if (isset($__attrsb2bc475e43d9bb81eea1eaafd83272bb)) $__attrsOriginal = $__attrsb2bc475e43d9bb81eea1eaafd83272bb; ?>
<?php $__attrsb2bc475e43d9bb81eea1eaafd83272bb = ['kbd' => $kbd]; ?>
<?php $__slotsb2bc475e43d9bb81eea1eaafd83272bb = []; ?>
<?php ob_start(); ?><?php echo e($content); ?><?php $__slotsb2bc475e43d9bb81eea1eaafd83272bb['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushData($__attrsb2bc475e43d9bb81eea1eaafd83272bb); ?>
<?php $__blaze->pushSlots($__slotsb2bc475e43d9bb81eea1eaafd83272bb); ?>
<?php __b2bc475e43d9bb81eea1eaafd83272bb($__blaze, $__attrsb2bc475e43d9bb81eea1eaafd83272bb, $__slotsb2bc475e43d9bb81eea1eaafd83272bb, ['kbd'], isset($this) ? $this : null); ?>
<?php if (isset($__slotsOriginal)) { $__slotsb2bc475e43d9bb81eea1eaafd83272bb = $__slotsOriginal; unset($__slotsOriginal); } ?>
<?php if (isset($__attrsOriginal)) { $__attrsb2bc475e43d9bb81eea1eaafd83272bb = $__attrsOriginal; unset($__attrsOriginal); } ?>
<?php $__blaze->popData(); ?>
        <?php endif; ?>
    </ui-dropdown>
<?php else: ?>
    <ui-tooltip position="<?php echo e($position); ?> <?php echo e($align); ?>" <?php echo e($attributes); ?> data-flux-tooltip <?php if($interactive): ?> interactive <?php endif; ?>>
        <?php echo e($slot); ?>


        <?php if ($content !== null): ?>
            <?php $__blaze->ensureRequired('E:\______laravel Project 2026\wa_cabinet_2026_v2\vendor\livewire\flux\src/../stubs/resources/views/flux/tooltip/content.blade.php', $__blaze->compiledPath.'/b2bc475e43d9bb81eea1eaafd83272bb.php'); ?>
<?php if (isset($__slotsb2bc475e43d9bb81eea1eaafd83272bb)) $__slotsOriginal = $__slotsb2bc475e43d9bb81eea1eaafd83272bb; ?>
<?php if (isset($__attrsb2bc475e43d9bb81eea1eaafd83272bb)) $__attrsOriginal = $__attrsb2bc475e43d9bb81eea1eaafd83272bb; ?>
<?php $__attrsb2bc475e43d9bb81eea1eaafd83272bb = ['kbd' => $kbd]; ?>
<?php $__slotsb2bc475e43d9bb81eea1eaafd83272bb = []; ?>
<?php ob_start(); ?><?php echo e($content); ?><?php $__slotsb2bc475e43d9bb81eea1eaafd83272bb['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushData($__attrsb2bc475e43d9bb81eea1eaafd83272bb); ?>
<?php $__blaze->pushSlots($__slotsb2bc475e43d9bb81eea1eaafd83272bb); ?>
<?php __b2bc475e43d9bb81eea1eaafd83272bb($__blaze, $__attrsb2bc475e43d9bb81eea1eaafd83272bb, $__slotsb2bc475e43d9bb81eea1eaafd83272bb, ['kbd'], isset($this) ? $this : null); ?>
<?php if (isset($__slotsOriginal)) { $__slotsb2bc475e43d9bb81eea1eaafd83272bb = $__slotsOriginal; unset($__slotsOriginal); } ?>
<?php if (isset($__attrsOriginal)) { $__attrsb2bc475e43d9bb81eea1eaafd83272bb = $__attrsOriginal; unset($__attrsOriginal); } ?>
<?php $__blaze->popData(); ?>
        <?php endif; ?>
    </ui-tooltip>
<?php endif; ?>
<?php
echo $__blaze->processPassthroughContent('ltrim', ltrim(ob_get_clean()));
} endif; ?><?php /**PATH E:\______laravel Project 2026\wa_cabinet_2026_v2\vendor\livewire\flux\src/../stubs/resources/views/flux/tooltip/index.blade.php ENDPATH**/ ?>