<?php
if (!function_exists('__5955876f004fff77a905f024a6146d2b')):
function __5955876f004fff77a905f024a6146d2b($__blaze, $__data = [], $__slots = [], $__bound = [], $__this = null) {
$__env = $__blaze->env;

if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::sanitized($__data, $__bound);
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP); unset($__data, $__bound);
ob_start();
?>


<?php
$attributes = $attributes->merge([
    'variant' => 'subtle',
    'class' => '-me-1',
    'square' => true,
    'size' => null,
]);
?>

<?php $__blaze->ensureRequired('E:\______laravel Project 2026\wa_cabinet_2026_v2\vendor\livewire\flux\src/../stubs/resources/views/flux/button/index.blade.php', $__blaze->compiledPath.'/daa14749c025d0e26124c26c685b3d79.php'); ?>
<?php if (isset($__slotsdaa14749c025d0e26124c26c685b3d79)) $__slotsOriginal = $__slotsdaa14749c025d0e26124c26c685b3d79; ?>
<?php if (isset($__attrsdaa14749c025d0e26124c26c685b3d79)) $__attrsOriginal = $__attrsdaa14749c025d0e26124c26c685b3d79; ?>
<?php $__attrsdaa14749c025d0e26124c26c685b3d79 = ['attributes' => $attributes,'size' => $size === 'sm' || $size === 'xs' ? 'xs' : 'sm']; ?>
<?php $__slotsdaa14749c025d0e26124c26c685b3d79 = []; ?>
<?php ob_start(); ?>
    <?php $__blaze->ensureRequired('E:\______laravel Project 2026\wa_cabinet_2026_v2\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/chevron-down.blade.php', $__blaze->compiledPath.'/fedebbf2233be73229aca334e38f6883.php'); ?>
<?php $__blaze->pushData(['variant' => 'micro']); ?>
<?php __fedebbf2233be73229aca334e38f6883($__blaze, ['variant' => 'micro'], [], [], isset($this) ? $this : null); ?>
<?php $__blaze->popData(); ?>
<?php $__slotsdaa14749c025d0e26124c26c685b3d79['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushData($__attrsdaa14749c025d0e26124c26c685b3d79); ?>
<?php $__blaze->pushSlots($__slotsdaa14749c025d0e26124c26c685b3d79); ?>
<?php __daa14749c025d0e26124c26c685b3d79($__blaze, $__attrsdaa14749c025d0e26124c26c685b3d79, $__slotsdaa14749c025d0e26124c26c685b3d79, ['attributes', 'size'], isset($this) ? $this : null); ?>
<?php if (isset($__slotsOriginal)) { $__slotsdaa14749c025d0e26124c26c685b3d79 = $__slotsOriginal; unset($__slotsOriginal); } ?>
<?php if (isset($__attrsOriginal)) { $__attrsdaa14749c025d0e26124c26c685b3d79 = $__attrsOriginal; unset($__attrsOriginal); } ?>
<?php $__blaze->popData(); ?>
<?php
echo $__blaze->processPassthroughContent('ltrim', ltrim(ob_get_clean()));
} endif; ?><?php /**PATH E:\______laravel Project 2026\wa_cabinet_2026_v2\vendor\livewire\flux\src/../stubs/resources/views/flux/input/expandable.blade.php ENDPATH**/ ?>