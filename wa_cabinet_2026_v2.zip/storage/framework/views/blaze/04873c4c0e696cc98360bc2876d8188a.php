<?php
if (!function_exists('__04873c4c0e696cc98360bc2876d8188a')):
function __04873c4c0e696cc98360bc2876d8188a($__blaze, $__data = [], $__slots = [], $__bound = [], $__this = null) {
$__env = $__blaze->env;

if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::sanitized($__data, $__bound);
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP); unset($__data, $__bound);
ob_start();
?>


<?php
$attributes = $attributes->merge([
    'variant' => 'subtle',
    'class' => '-me-1',
    'square' => true,
    'size' => null,
]);
?>

<?php $__blaze->ensureRequired('E:\______laravel Project 2026\wa_cabinet_2026_v2\vendor\livewire\flux\src/../stubs/resources/views/flux/button/index.blade.php', $__blaze->compiledPath.'/daa14749c025d0e26124c26c685b3d79.php'); ?>
<?php if (isset($__slotsdaa14749c025d0e26124c26c685b3d79)) $__slotsOriginal = $__slotsdaa14749c025d0e26124c26c685b3d79; ?>
<?php if (isset($__attrsdaa14749c025d0e26124c26c685b3d79)) $__attrsOriginal = $__attrsdaa14749c025d0e26124c26c685b3d79; ?>
<?php $__attrsdaa14749c025d0e26124c26c685b3d79 = ['attributes' => $attributes,'size' => $size === 'sm' || $size === 'xs' ? 'xs' : 'sm','x-data' => 'fluxInputViewable','x-on:click' => 'toggle()','x-bind:data-viewable-open' => 'open','aria-label' => ''.e(__('Toggle password visibility')).'']; ?>
<?php $__slotsdaa14749c025d0e26124c26c685b3d79 = []; ?>
<?php ob_start(); ?>
    <?php $__blaze->ensureRequired('E:\______laravel Project 2026\wa_cabinet_2026_v2\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/eye-slash.blade.php', $__blaze->compiledPath.'/08b01b3f12daa47dd2271fba0955f75d.php'); ?>
<?php $__blaze->pushData(['variant' => 'micro','class' => 'hidden [[data-viewable-open]>&]:block']); ?>
<?php __08b01b3f12daa47dd2271fba0955f75d($__blaze, ['variant' => 'micro','class' => 'hidden [[data-viewable-open]>&]:block'], [], [], isset($this) ? $this : null); ?>
<?php $__blaze->popData(); ?>
    <?php $__blaze->ensureRequired('E:\______laravel Project 2026\wa_cabinet_2026_v2\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/eye.blade.php', $__blaze->compiledPath.'/eea5bfffd5bbff98fb4fb6f7d19689a7.php'); ?>
<?php $__blaze->pushData(['variant' => 'micro','class' => 'block [[data-viewable-open]>&]:hidden']); ?>
<?php __eea5bfffd5bbff98fb4fb6f7d19689a7($__blaze, ['variant' => 'micro','class' => 'block [[data-viewable-open]>&]:hidden'], [], [], isset($this) ? $this : null); ?>
<?php $__blaze->popData(); ?>
<?php $__slotsdaa14749c025d0e26124c26c685b3d79['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushData($__attrsdaa14749c025d0e26124c26c685b3d79); ?>
<?php $__blaze->pushSlots($__slotsdaa14749c025d0e26124c26c685b3d79); ?>
<?php __daa14749c025d0e26124c26c685b3d79($__blaze, $__attrsdaa14749c025d0e26124c26c685b3d79, $__slotsdaa14749c025d0e26124c26c685b3d79, ['attributes', 'size'], isset($this) ? $this : null); ?>
<?php if (isset($__slotsOriginal)) { $__slotsdaa14749c025d0e26124c26c685b3d79 = $__slotsOriginal; unset($__slotsOriginal); } ?>
<?php if (isset($__attrsOriginal)) { $__attrsdaa14749c025d0e26124c26c685b3d79 = $__attrsOriginal; unset($__attrsOriginal); } ?>
<?php $__blaze->popData(); ?>
<?php
echo $__blaze->processPassthroughContent('ltrim', ltrim(ob_get_clean()));
} endif; ?><?php /**PATH E:\______laravel Project 2026\wa_cabinet_2026_v2\vendor\livewire\flux\src/../stubs/resources/views/flux/input/viewable.blade.php ENDPATH**/ ?>