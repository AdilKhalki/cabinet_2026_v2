<?php
if (!function_exists('__c6c81642d1a2cd2c0829fc1b4bd1f4d2')):
function __c6c81642d1a2cd2c0829fc1b4bd1f4d2($__blaze, $__data = [], $__slots = [], $__bound = [], $__this = null) {
$__env = $__blaze->env;
$__slots['slot'] ??= new \Illuminate\View\ComponentSlot('');
if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::sanitized($__data, $__bound);
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP); unset($__data, $__bound);
ob_start();
?>


<?php
$__defaults = [
    'name' => null,
    'variant' => null,
    'size' => null,
];
$name ??= $attributes['name'] ?? $__defaults['name']; unset($attributes['name']);
$variant ??= $attributes['variant'] ?? $__defaults['variant']; unset($attributes['variant']);
$size ??= $attributes['size'] ?? $__defaults['size']; unset($attributes['size']);
unset($__defaults);
?>

<?php
// We only want to show the name attribute on the checkbox if it has been set
// manually, but not if it has been set from the wire:model attribute...
$showName = isset($name);

if (! isset($name)) {
    $name = $attributes->whereStartsWith('wire:model')->first();
}

$classes = Flux::classes()
    ->add('block flex p-1')
    ->add('rounded-lg bg-zinc-800/5 dark:bg-white/10')
    ->add($size === 'sm' ? 'h-8 py-[3px] px-[3px]' : 'h-10 p-1')
    ->add($size === 'sm' ? '-my-px h-[calc(2rem+2px)]' : '')
    ;
?>

<?php $__blaze->ensureRequired('E:\______laravel Project 2026\wa_cabinet_2026_v2\vendor\livewire\flux\src/../stubs/resources/views/flux/with-field.blade.php', $__blaze->compiledPath.'/c4c5c34b9e55f0a2509b260ff43fcb43.php'); ?>
<?php if (isset($__slotsc4c5c34b9e55f0a2509b260ff43fcb43)) $__slotsOriginal = $__slotsc4c5c34b9e55f0a2509b260ff43fcb43; ?>
<?php if (isset($__attrsc4c5c34b9e55f0a2509b260ff43fcb43)) $__attrsOriginal = $__attrsc4c5c34b9e55f0a2509b260ff43fcb43; ?>
<?php $__attrsc4c5c34b9e55f0a2509b260ff43fcb43 = ['attributes' => $attributes]; ?>
<?php $__slotsc4c5c34b9e55f0a2509b260ff43fcb43 = []; ?>
<?php ob_start(); ?>
    <ui-radio-group <?php echo e($attributes->class($classes)); ?> <?php if($showName): ?> name="<?php echo e($name); ?>" <?php endif; ?> data-flux-radio-group-segmented>
        <?php echo e($slot); ?>

    </ui-radio-group>
<?php $__slotsc4c5c34b9e55f0a2509b260ff43fcb43['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushData($__attrsc4c5c34b9e55f0a2509b260ff43fcb43); ?>
<?php $__blaze->pushSlots($__slotsc4c5c34b9e55f0a2509b260ff43fcb43); ?>
<?php __c4c5c34b9e55f0a2509b260ff43fcb43($__blaze, $__attrsc4c5c34b9e55f0a2509b260ff43fcb43, $__slotsc4c5c34b9e55f0a2509b260ff43fcb43, ['attributes'], isset($this) ? $this : null); ?>
<?php if (isset($__slotsOriginal)) { $__slotsc4c5c34b9e55f0a2509b260ff43fcb43 = $__slotsOriginal; unset($__slotsOriginal); } ?>
<?php if (isset($__attrsOriginal)) { $__attrsc4c5c34b9e55f0a2509b260ff43fcb43 = $__attrsOriginal; unset($__attrsOriginal); } ?>
<?php $__blaze->popData(); ?>
<?php
echo $__blaze->processPassthroughContent('ltrim', ltrim(ob_get_clean()));
} endif; ?><?php /**PATH E:\______laravel Project 2026\wa_cabinet_2026_v2\vendor\livewire\flux\src/../stubs/resources/views/flux/radio/group/variants/segmented.blade.php ENDPATH**/ ?>