<?php
if (!function_exists('__91e77adf10721110734b42529e65f611')):
function __91e77adf10721110734b42529e65f611($__blaze, $__data = [], $__slots = [], $__bound = [], $__this = null) {
$__env = $__blaze->env;
$__slots['slot'] ??= new \Illuminate\View\ComponentSlot('');
if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::sanitized($__data, $__bound);
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP); unset($__data, $__bound);
ob_start();
?>


<?php
$__defaults = [
    'length' => null,
    'private' => false,
];
$length ??= $attributes['length'] ?? $__defaults['length']; unset($attributes['length']);
$private ??= $attributes['private'] ?? $__defaults['private']; unset($attributes['private']);
unset($__defaults);
?>

<?php
    $classes = Flux::classes()
        ->add('flex items-center gap-2 isolate w-fit')
        ->add('[&_[data-flux-input-group]]:w-auto')
?>

<?php $__blaze->ensureRequired('E:\______laravel Project 2026\wa_cabinet_2026_v2\vendor\livewire\flux\src/../stubs/resources/views/flux/with-field.blade.php', $__blaze->compiledPath.'/c4c5c34b9e55f0a2509b260ff43fcb43.php'); ?>
<?php if (isset($__slotsc4c5c34b9e55f0a2509b260ff43fcb43)) $__slotsOriginal = $__slotsc4c5c34b9e55f0a2509b260ff43fcb43; ?>
<?php if (isset($__attrsc4c5c34b9e55f0a2509b260ff43fcb43)) $__attrsOriginal = $__attrsc4c5c34b9e55f0a2509b260ff43fcb43; ?>
<?php $__attrsc4c5c34b9e55f0a2509b260ff43fcb43 = ['attributes' => $attributes]; ?>
<?php $__slotsc4c5c34b9e55f0a2509b260ff43fcb43 = []; ?>
<?php ob_start(); ?>
    <ui-otp
        <?php echo e($attributes->class($classes)); ?>

        data-flux-otp
        data-flux-control
        role="group"
        data-flux-input-aria-label="<?php echo e(__('Character {current} of {total}')); ?>"
    >
        <?php if($slot->isEmpty() && $length): ?>
            <?php for($i = 0; $i < $length; $i++): ?>
                <?php $__blaze->ensureRequired('E:\______laravel Project 2026\wa_cabinet_2026_v2\vendor\livewire\flux\src/../stubs/resources/views/flux/otp/input.blade.php', $__blaze->compiledPath.'/93e239afb6743cbad466c2246834662b.php'); ?>
<?php $__blaze->pushData([]); ?>
<?php __93e239afb6743cbad466c2246834662b($__blaze, [], [], [], isset($this) ? $this : null); ?>
<?php $__blaze->popData(); ?>
            <?php endfor; ?>
        <?php else: ?>
            <?php echo e($slot); ?>

        <?php endif; ?>
    </ui-otp>
<?php $__slotsc4c5c34b9e55f0a2509b260ff43fcb43['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushData($__attrsc4c5c34b9e55f0a2509b260ff43fcb43); ?>
<?php $__blaze->pushSlots($__slotsc4c5c34b9e55f0a2509b260ff43fcb43); ?>
<?php __c4c5c34b9e55f0a2509b260ff43fcb43($__blaze, $__attrsc4c5c34b9e55f0a2509b260ff43fcb43, $__slotsc4c5c34b9e55f0a2509b260ff43fcb43, ['attributes'], isset($this) ? $this : null); ?>
<?php if (isset($__slotsOriginal)) { $__slotsc4c5c34b9e55f0a2509b260ff43fcb43 = $__slotsOriginal; unset($__slotsOriginal); } ?>
<?php if (isset($__attrsOriginal)) { $__attrsc4c5c34b9e55f0a2509b260ff43fcb43 = $__attrsOriginal; unset($__attrsOriginal); } ?>
<?php $__blaze->popData(); ?><?php
echo $__blaze->processPassthroughContent('ltrim', ltrim(ob_get_clean()));
} endif; ?><?php /**PATH E:\______laravel Project 2026\wa_cabinet_2026_v2\vendor\livewire\flux\src/../stubs/resources/views/flux/otp/index.blade.php ENDPATH**/ ?>