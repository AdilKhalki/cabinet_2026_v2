<?php
if (!function_exists('__1b8794ac3f4fd02735b0788951aa8089')):
function __1b8794ac3f4fd02735b0788951aa8089($__blaze, $__data = [], $__slots = [], $__bound = [], $__this = null) {
$__env = $__blaze->env;

if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::sanitized($__data, $__bound);
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP); unset($__data, $__bound);
ob_start();
?>


<?php
$attributes = $attributes->merge([
    'variant' => 'subtle',
    'class' => '-me-1 [[data-flux-input]:has(input:placeholder-shown)_&]:hidden [[data-flux-input]:has(input[disabled])_&]:hidden',
    'square' => true,
    'size' => null,
]);
?>

<?php $__blaze->ensureRequired('E:\______laravel Project 2026\wa_cabinet_2026_v2\vendor\livewire\flux\src/../stubs/resources/views/flux/button/index.blade.php', $__blaze->compiledPath.'/daa14749c025d0e26124c26c685b3d79.php'); ?>
<?php if (isset($__slotsdaa14749c025d0e26124c26c685b3d79)) $__slotsOriginal = $__slotsdaa14749c025d0e26124c26c685b3d79; ?>
<?php if (isset($__attrsdaa14749c025d0e26124c26c685b3d79)) $__attrsOriginal = $__attrsdaa14749c025d0e26124c26c685b3d79; ?>
<?php $__attrsdaa14749c025d0e26124c26c685b3d79 = ['attributes' => $attributes,'size' => $size === 'sm' || $size === 'xs' ? 'xs' : 'sm','x-data' => 'fluxInputClearable','x-on:click' => 'clear()','tabindex' => '-1','aria-label' => 'Clear input','data-flux-clear-button' => true]; ?>
<?php $__slotsdaa14749c025d0e26124c26c685b3d79 = []; ?>
<?php ob_start(); ?>
    <?php $__blaze->ensureRequired('E:\______laravel Project 2026\wa_cabinet_2026_v2\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/x-mark.blade.php', $__blaze->compiledPath.'/f1f1e6ecb0e1c8917c77e5b55a98bb84.php'); ?>
<?php $__blaze->pushData(['variant' => 'micro']); ?>
<?php __f1f1e6ecb0e1c8917c77e5b55a98bb84($__blaze, ['variant' => 'micro'], [], [], isset($this) ? $this : null); ?>
<?php $__blaze->popData(); ?>
<?php $__slotsdaa14749c025d0e26124c26c685b3d79['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushData($__attrsdaa14749c025d0e26124c26c685b3d79); ?>
<?php $__blaze->pushSlots($__slotsdaa14749c025d0e26124c26c685b3d79); ?>
<?php __daa14749c025d0e26124c26c685b3d79($__blaze, $__attrsdaa14749c025d0e26124c26c685b3d79, $__slotsdaa14749c025d0e26124c26c685b3d79, ['attributes', 'size', 'data-flux-clear-button'], isset($this) ? $this : null); ?>
<?php if (isset($__slotsOriginal)) { $__slotsdaa14749c025d0e26124c26c685b3d79 = $__slotsOriginal; unset($__slotsOriginal); } ?>
<?php if (isset($__attrsOriginal)) { $__attrsdaa14749c025d0e26124c26c685b3d79 = $__attrsOriginal; unset($__attrsOriginal); } ?>
<?php $__blaze->popData(); ?>
<?php
echo $__blaze->processPassthroughContent('ltrim', ltrim(ob_get_clean()));
} endif; ?><?php /**PATH E:\______laravel Project 2026\wa_cabinet_2026_v2\vendor\livewire\flux\src/../stubs/resources/views/flux/input/clearable.blade.php ENDPATH**/ ?>