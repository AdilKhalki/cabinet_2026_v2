<?php
if (!function_exists('__c4c5c34b9e55f0a2509b260ff43fcb43')):
function __c4c5c34b9e55f0a2509b260ff43fcb43($__blaze, $__data = [], $__slots = [], $__bound = [], $__this = null) {
$__env = $__blaze->env;
$__slots['slot'] ??= new \Illuminate\View\ComponentSlot('');
if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::sanitized($__data, $__bound);
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP); unset($__data, $__bound);
ob_start();
?>


<?php
extract(Flux::forwardedAttributes($attributes, [
    'name',
    'descriptionTrailing',
    'description',
    'label',
    'badge',
]));
?>

<?php $descriptionTrailing = $descriptionTrailing ??= $attributes->pluck('description:trailing'); ?>

<?php
$__defaults = [
    'name' => $attributes->whereStartsWith('wire:model')->first(),
    'descriptionTrailing' => null,
    'description' => null,
    'label' => null,
    'badge' => null,
];
$name ??= $attributes['name'] ?? $__defaults['name']; unset($attributes['name']);
$descriptionTrailing ??= $attributes['description-trailing'] ?? $attributes['descriptionTrailing'] ?? $__defaults['descriptionTrailing']; unset($attributes['descriptionTrailing'], $attributes['description-trailing']);
$description ??= $attributes['description'] ?? $__defaults['description']; unset($attributes['description']);
$label ??= $attributes['label'] ?? $__defaults['label']; unset($attributes['label']);
$badge ??= $attributes['badge'] ?? $__defaults['badge']; unset($attributes['badge']);
unset($__defaults);
?>

<?php if (isset($label) || isset($description)): ?>
    <?php

        $fieldAttributes = Flux::attributesAfter('field:', $attributes, []);
        $labelAttributes = Flux::attributesAfter('label:', $attributes, ['badge' => $badge]);
        $descriptionAttributes = Flux::attributesAfter('description:', $attributes, []);
        $errorAttributes = Flux::attributesAfter('error:', $attributes, ['name' => $name]);
    ?>
    <?php $__blaze->ensureRequired('E:\______laravel Project 2026\wa_cabinet_2026_v2\vendor\livewire\flux\src/../stubs/resources/views/flux/field.blade.php', $__blaze->compiledPath.'/41613d97a6d13d9f1c69ea195b2e7ec7.php'); ?>
<?php if (isset($__slots41613d97a6d13d9f1c69ea195b2e7ec7)) $__slotsOriginal = $__slots41613d97a6d13d9f1c69ea195b2e7ec7; ?>
<?php if (isset($__attrs41613d97a6d13d9f1c69ea195b2e7ec7)) $__attrsOriginal = $__attrs41613d97a6d13d9f1c69ea195b2e7ec7; ?>
<?php $__attrs41613d97a6d13d9f1c69ea195b2e7ec7 = ['attributes' => $fieldAttributes]; ?>
<?php $__slots41613d97a6d13d9f1c69ea195b2e7ec7 = []; ?>
<?php ob_start(); ?>
        <?php if (isset($label)): ?>
            <?php $__blaze->ensureRequired('E:\______laravel Project 2026\wa_cabinet_2026_v2\vendor\livewire\flux\src/../stubs/resources/views/flux/label.blade.php', $__blaze->compiledPath.'/c4af6cf23eb0e7618187b66dc9a64673.php'); ?>
<?php if (isset($__slotsc4af6cf23eb0e7618187b66dc9a64673)) $__slotsOriginal = $__slotsc4af6cf23eb0e7618187b66dc9a64673; ?>
<?php if (isset($__attrsc4af6cf23eb0e7618187b66dc9a64673)) $__attrsOriginal = $__attrsc4af6cf23eb0e7618187b66dc9a64673; ?>
<?php $__attrsc4af6cf23eb0e7618187b66dc9a64673 = ['attributes' => $labelAttributes]; ?>
<?php $__slotsc4af6cf23eb0e7618187b66dc9a64673 = []; ?>
<?php ob_start(); ?><?php echo e($label); ?><?php $__slotsc4af6cf23eb0e7618187b66dc9a64673['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushData($__attrsc4af6cf23eb0e7618187b66dc9a64673); ?>
<?php $__blaze->pushSlots($__slotsc4af6cf23eb0e7618187b66dc9a64673); ?>
<?php __c4af6cf23eb0e7618187b66dc9a64673($__blaze, $__attrsc4af6cf23eb0e7618187b66dc9a64673, $__slotsc4af6cf23eb0e7618187b66dc9a64673, ['attributes'], isset($this) ? $this : null); ?>
<?php if (isset($__slotsOriginal)) { $__slotsc4af6cf23eb0e7618187b66dc9a64673 = $__slotsOriginal; unset($__slotsOriginal); } ?>
<?php if (isset($__attrsOriginal)) { $__attrsc4af6cf23eb0e7618187b66dc9a64673 = $__attrsOriginal; unset($__attrsOriginal); } ?>
<?php $__blaze->popData(); ?>
        <?php endif; ?>

        <?php if (isset($description)): ?>
            <?php $__blaze->ensureRequired('E:\______laravel Project 2026\wa_cabinet_2026_v2\vendor\livewire\flux\src/../stubs/resources/views/flux/description.blade.php', $__blaze->compiledPath.'/088e612ad8f1fe7156b38bd04fa931a4.php'); ?>
<?php if (isset($__slots088e612ad8f1fe7156b38bd04fa931a4)) $__slotsOriginal = $__slots088e612ad8f1fe7156b38bd04fa931a4; ?>
<?php if (isset($__attrs088e612ad8f1fe7156b38bd04fa931a4)) $__attrsOriginal = $__attrs088e612ad8f1fe7156b38bd04fa931a4; ?>
<?php $__attrs088e612ad8f1fe7156b38bd04fa931a4 = ['attributes' => $descriptionAttributes]; ?>
<?php $__slots088e612ad8f1fe7156b38bd04fa931a4 = []; ?>
<?php ob_start(); ?><?php echo e($description); ?><?php $__slots088e612ad8f1fe7156b38bd04fa931a4['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushData($__attrs088e612ad8f1fe7156b38bd04fa931a4); ?>
<?php $__blaze->pushSlots($__slots088e612ad8f1fe7156b38bd04fa931a4); ?>
<?php __088e612ad8f1fe7156b38bd04fa931a4($__blaze, $__attrs088e612ad8f1fe7156b38bd04fa931a4, $__slots088e612ad8f1fe7156b38bd04fa931a4, ['attributes'], isset($this) ? $this : null); ?>
<?php if (isset($__slotsOriginal)) { $__slots088e612ad8f1fe7156b38bd04fa931a4 = $__slotsOriginal; unset($__slotsOriginal); } ?>
<?php if (isset($__attrsOriginal)) { $__attrs088e612ad8f1fe7156b38bd04fa931a4 = $__attrsOriginal; unset($__attrsOriginal); } ?>
<?php $__blaze->popData(); ?>
        <?php endif; ?>

        <?php echo e($slot); ?>


        [STARTCOMPILEDUNBLAZE:OL4nEQeOjM]<?php \Livewire\Blaze\Unblaze::storeScope("OL4nEQeOjM", scope: ['attributes' => $errorAttributes->all()]) ?>[ENDCOMPILEDUNBLAZE:OL4nEQeOjM]

        <?php if (isset($descriptionTrailing)): ?>
            <?php $__blaze->ensureRequired('E:\______laravel Project 2026\wa_cabinet_2026_v2\vendor\livewire\flux\src/../stubs/resources/views/flux/description.blade.php', $__blaze->compiledPath.'/088e612ad8f1fe7156b38bd04fa931a4.php'); ?>
<?php if (isset($__slots088e612ad8f1fe7156b38bd04fa931a4)) $__slotsOriginal = $__slots088e612ad8f1fe7156b38bd04fa931a4; ?>
<?php if (isset($__attrs088e612ad8f1fe7156b38bd04fa931a4)) $__attrsOriginal = $__attrs088e612ad8f1fe7156b38bd04fa931a4; ?>
<?php $__attrs088e612ad8f1fe7156b38bd04fa931a4 = ['attributes' => $descriptionAttributes]; ?>
<?php $__slots088e612ad8f1fe7156b38bd04fa931a4 = []; ?>
<?php ob_start(); ?><?php echo e($descriptionTrailing); ?><?php $__slots088e612ad8f1fe7156b38bd04fa931a4['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushData($__attrs088e612ad8f1fe7156b38bd04fa931a4); ?>
<?php $__blaze->pushSlots($__slots088e612ad8f1fe7156b38bd04fa931a4); ?>
<?php __088e612ad8f1fe7156b38bd04fa931a4($__blaze, $__attrs088e612ad8f1fe7156b38bd04fa931a4, $__slots088e612ad8f1fe7156b38bd04fa931a4, ['attributes'], isset($this) ? $this : null); ?>
<?php if (isset($__slotsOriginal)) { $__slots088e612ad8f1fe7156b38bd04fa931a4 = $__slotsOriginal; unset($__slotsOriginal); } ?>
<?php if (isset($__attrsOriginal)) { $__attrs088e612ad8f1fe7156b38bd04fa931a4 = $__attrsOriginal; unset($__attrsOriginal); } ?>
<?php $__blaze->popData(); ?>
        <?php endif; ?>
    <?php $__slots41613d97a6d13d9f1c69ea195b2e7ec7['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushData($__attrs41613d97a6d13d9f1c69ea195b2e7ec7); ?>
<?php $__blaze->pushSlots($__slots41613d97a6d13d9f1c69ea195b2e7ec7); ?>
<?php __41613d97a6d13d9f1c69ea195b2e7ec7($__blaze, $__attrs41613d97a6d13d9f1c69ea195b2e7ec7, $__slots41613d97a6d13d9f1c69ea195b2e7ec7, ['attributes'], isset($this) ? $this : null); ?>
<?php if (isset($__slotsOriginal)) { $__slots41613d97a6d13d9f1c69ea195b2e7ec7 = $__slotsOriginal; unset($__slotsOriginal); } ?>
<?php if (isset($__attrsOriginal)) { $__attrs41613d97a6d13d9f1c69ea195b2e7ec7 = $__attrsOriginal; unset($__attrsOriginal); } ?>
<?php $__blaze->popData(); ?>
<?php else: ?>
    <?php echo e($slot); ?>

<?php endif; ?>
<?php
echo $__blaze->processPassthroughContent('ltrim', ltrim(ob_get_clean()));
} endif; ?><?php /**PATH E:\______laravel Project 2026\wa_cabinet_2026_v2\vendor\livewire\flux\src/../stubs/resources/views/flux/with-field.blade.php ENDPATH**/ ?>