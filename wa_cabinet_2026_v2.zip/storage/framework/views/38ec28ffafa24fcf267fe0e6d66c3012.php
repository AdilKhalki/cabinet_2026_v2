<div>
    <div class="row">
        
        <div class="col-md-4">
            <div class="card">
                <div class="card-block">
                    <h6 class="text-muted m-b-5">Numéro</h6>
                    <p class="f-w-700"><?php echo e($report->report_number); ?></p>

                    <h6 class="text-muted m-b-5">Type</h6>
                    <p>
                        <span class="label label-primary">
                            <?php echo e($typeLabels[$report->type] ?? $report->type); ?>

                        </span>
                    </p>

                    <h6 class="text-muted m-b-5">Patient</h6>
                    <p>
                        <a href="<?php echo e(route('patients.show', $report->patient)); ?>">
                            <?php echo e($report->patient->full_name); ?>

                        </a>
                        <span class="text-muted small d-block"><?php echo e($report->patient->dossier_number); ?></span>
                    </p>

                    <h6 class="text-muted m-b-5">Médecin</h6>
                    <p>Dr. <?php echo e($report->doctor->name ?? '—'); ?></p>

                    <h6 class="text-muted m-b-5">Date du rapport</h6>
                    <p><?php echo e($report->report_date?->format('d/m/Y') ?? '—'); ?></p>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($report->type === 'sick_leave'): ?>
                        <h6 class="text-muted m-b-5">Arrêt de travail</h6>
                        <p>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($report->sick_leave_days): ?>
                                <?php echo e($report->sick_leave_days); ?> jour(s)
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($report->valid_from): ?>
                                <span class="text-muted small d-block">
                                    Du <?php echo e($report->valid_from->format('d/m/Y')); ?>

                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($report->valid_until): ?>
                                        au <?php echo e($report->valid_until->format('d/m/Y')); ?>

                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </span>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </p>
                    <?php elseif($report->valid_until): ?>
                        <h6 class="text-muted m-b-5">Validité</h6>
                        <p>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($report->valid_from): ?>Du <?php echo e($report->valid_from->format('d/m/Y')); ?> au <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            <?php echo e($report->valid_until->format('d/m/Y')); ?>

                        </p>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($report->consultation): ?>
                        <h6 class="text-muted m-b-5">Consultation liée</h6>
                        <p>
                            <a href="<?php echo e(route('consultations.show', $report->consultation)); ?>">
                                #<?php echo e($report->consultation->id); ?> —
                                <?php echo e($report->consultation->consultation_date?->format('d/m/Y')); ?>

                            </a>
                        </p>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($report->is_printed): ?>
                        <span class="label label-success"><i class="feather icon-printer"></i> Imprimé</span>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                <div class="card-footer">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('print', $report)): ?>
                    <a href="<?php echo e(route('medical-reports.pdf', $report)); ?>"
                       target="_blank" class="btn btn-info btn-block m-b-10">
                        <i class="feather icon-download"></i> Télécharger PDF
                    </a>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $report)): ?>
                    <a href="<?php echo e(route('medical-reports.edit', $report)); ?>"
                       class="btn btn-warning btn-block m-b-10">
                        <i class="feather icon-edit"></i> Modifier
                    </a>
                    <?php endif; ?>
                    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-default btn-block">
                        <i class="feather icon-arrow-left"></i> Retour
                    </a>
                </div>
            </div>
        </div>

        
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h5><i class="feather icon-file-text"></i> <?php echo e($report->title); ?></h5>
                </div>
                <div class="card-block">
                    <div style="white-space: pre-wrap; font-family: inherit; line-height: 1.8; padding: 10px;"><?php echo e($report->content); ?></div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\______laravel Project 2026\wa_cabinet_2026_v2\resources\views/livewire/medical-report/medical-report-show.blade.php ENDPATH**/ ?>