<?php # [BlazeFolded]:{flux::navlist}:{E:\______laravel Project 2026\wa_cabinet_2026_v2\vendor\livewire\flux\src/../stubs/resources/views/flux/navlist/index.blade.php}:{1772508755} ?>
<?php # [BlazeFolded]:{flux::separator}:{E:\______laravel Project 2026\wa_cabinet_2026_v2\vendor\livewire\flux\src/../stubs/resources/views/flux/separator.blade.php}:{1772508755} ?>
<?php # [BlazeFolded]:{flux::heading}:{E:\______laravel Project 2026\wa_cabinet_2026_v2\vendor\livewire\flux\src/../stubs/resources/views/flux/heading.blade.php}:{1772508755} ?>
<?php # [BlazeFolded]:{flux::subheading}:{E:\______laravel Project 2026\wa_cabinet_2026_v2\vendor\livewire\flux\src/../stubs/resources/views/flux/subheading.blade.php}:{1772508755} ?>
<div class="flex items-start max-md:flex-col">
    <div class="me-10 w-full pb-4 md:w-[220px]">
        <?php ob_start(); ?><?php $__blaze->pushData(['ariaLabel' => e(__('Settings'))]); $__env->pushConsumableComponentData(['ariaLabel' => e(__('Settings'))]); ?><nav class="flex flex-col overflow-visible min-h-auto" aria-label="<?php echo e(__('Settings')); ?>" data-flux-navlist>
    <?php ob_start(); ?>
            <?php $__blaze->ensureRequired('E:\______laravel Project 2026\wa_cabinet_2026_v2\vendor\livewire\flux\src/../stubs/resources/views/flux/navlist/item.blade.php', $__blaze->compiledPath.'/20599abc15651907c0869fd0ccc7f215.php'); ?>
<?php if (isset($__slots20599abc15651907c0869fd0ccc7f215)) $__slotsOriginal = $__slots20599abc15651907c0869fd0ccc7f215; ?>
<?php if (isset($__attrs20599abc15651907c0869fd0ccc7f215)) $__attrsOriginal = $__attrs20599abc15651907c0869fd0ccc7f215; ?>
<?php $__attrs20599abc15651907c0869fd0ccc7f215 = ['href' => route('profile.edit'),'wire:navigate' => true]; ?>
<?php $__slots20599abc15651907c0869fd0ccc7f215 = []; ?>
<?php ob_start(); ?><?php echo e(__('Profile')); ?><?php $__slots20599abc15651907c0869fd0ccc7f215['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushData($__attrs20599abc15651907c0869fd0ccc7f215); ?>
<?php $__blaze->pushSlots($__slots20599abc15651907c0869fd0ccc7f215); ?>
<?php _20599abc15651907c0869fd0ccc7f215($__blaze, $__attrs20599abc15651907c0869fd0ccc7f215, $__slots20599abc15651907c0869fd0ccc7f215, ['href', 'wire:navigate'], isset($this) ? $this : null); ?>
<?php if (isset($__slotsOriginal)) { $__slots20599abc15651907c0869fd0ccc7f215 = $__slotsOriginal; unset($__slotsOriginal); } ?>
<?php if (isset($__attrsOriginal)) { $__attrs20599abc15651907c0869fd0ccc7f215 = $__attrsOriginal; unset($__attrsOriginal); } ?>
<?php $__blaze->popData(); ?>
            <?php $__blaze->ensureRequired('E:\______laravel Project 2026\wa_cabinet_2026_v2\vendor\livewire\flux\src/../stubs/resources/views/flux/navlist/item.blade.php', $__blaze->compiledPath.'/20599abc15651907c0869fd0ccc7f215.php'); ?>
<?php if (isset($__slots20599abc15651907c0869fd0ccc7f215)) $__slotsOriginal = $__slots20599abc15651907c0869fd0ccc7f215; ?>
<?php if (isset($__attrs20599abc15651907c0869fd0ccc7f215)) $__attrsOriginal = $__attrs20599abc15651907c0869fd0ccc7f215; ?>
<?php $__attrs20599abc15651907c0869fd0ccc7f215 = ['href' => route('security.edit'),'wire:navigate' => true]; ?>
<?php $__slots20599abc15651907c0869fd0ccc7f215 = []; ?>
<?php ob_start(); ?><?php echo e(__('Security')); ?><?php $__slots20599abc15651907c0869fd0ccc7f215['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushData($__attrs20599abc15651907c0869fd0ccc7f215); ?>
<?php $__blaze->pushSlots($__slots20599abc15651907c0869fd0ccc7f215); ?>
<?php _20599abc15651907c0869fd0ccc7f215($__blaze, $__attrs20599abc15651907c0869fd0ccc7f215, $__slots20599abc15651907c0869fd0ccc7f215, ['href', 'wire:navigate'], isset($this) ? $this : null); ?>
<?php if (isset($__slotsOriginal)) { $__slots20599abc15651907c0869fd0ccc7f215 = $__slotsOriginal; unset($__slotsOriginal); } ?>
<?php if (isset($__attrsOriginal)) { $__attrs20599abc15651907c0869fd0ccc7f215 = $__attrsOriginal; unset($__attrsOriginal); } ?>
<?php $__blaze->popData(); ?>
            <?php $__blaze->ensureRequired('E:\______laravel Project 2026\wa_cabinet_2026_v2\vendor\livewire\flux\src/../stubs/resources/views/flux/navlist/item.blade.php', $__blaze->compiledPath.'/20599abc15651907c0869fd0ccc7f215.php'); ?>
<?php if (isset($__slots20599abc15651907c0869fd0ccc7f215)) $__slotsOriginal = $__slots20599abc15651907c0869fd0ccc7f215; ?>
<?php if (isset($__attrs20599abc15651907c0869fd0ccc7f215)) $__attrsOriginal = $__attrs20599abc15651907c0869fd0ccc7f215; ?>
<?php $__attrs20599abc15651907c0869fd0ccc7f215 = ['href' => route('appearance.edit'),'wire:navigate' => true]; ?>
<?php $__slots20599abc15651907c0869fd0ccc7f215 = []; ?>
<?php ob_start(); ?><?php echo e(__('Appearance')); ?><?php $__slots20599abc15651907c0869fd0ccc7f215['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushData($__attrs20599abc15651907c0869fd0ccc7f215); ?>
<?php $__blaze->pushSlots($__slots20599abc15651907c0869fd0ccc7f215); ?>
<?php _20599abc15651907c0869fd0ccc7f215($__blaze, $__attrs20599abc15651907c0869fd0ccc7f215, $__slots20599abc15651907c0869fd0ccc7f215, ['href', 'wire:navigate'], isset($this) ? $this : null); ?>
<?php if (isset($__slotsOriginal)) { $__slots20599abc15651907c0869fd0ccc7f215 = $__slotsOriginal; unset($__slotsOriginal); } ?>
<?php if (isset($__attrsOriginal)) { $__attrs20599abc15651907c0869fd0ccc7f215 = $__attrsOriginal; unset($__attrsOriginal); } ?>
<?php $__blaze->popData(); ?>
        <?php echo trim(ob_get_clean()); ?>

</nav>
<?php $__blaze->popData(); $__env->popConsumableComponentData(); ?><?php echo ltrim(ob_get_clean()); ?>
    </div>

    <?php ob_start(); ?><div data-orientation="horizontal" role="none" class="border-0 [print-color-adjust:exact] bg-zinc-800/15 dark:bg-white/20 h-px w-full md:hidden" data-flux-separator></div>
<?php echo ltrim(ob_get_clean()); ?>

    <div class="flex-1 self-stretch max-md:pt-6">
        <?php ob_start(); ?><div class="font-medium [:where(&amp;)]:text-zinc-800 [:where(&amp;)]:dark:text-white text-sm [&amp;:has(+[data-flux-subheading])]:mb-2 [[data-flux-subheading]+&amp;]:mt-2" data-flux-heading><?php ob_start(); ?><?php echo e($heading ?? ''); ?><?php echo trim(ob_get_clean()); ?></div>
<?php echo ltrim(ob_get_clean()); ?>
        <?php ob_start(); ?><div class="text-sm [:where(&amp;)]:text-zinc-500 [:where(&amp;)]:dark:text-white/70" data-flux-subheading>
    <?php ob_start(); ?><?php echo e($subheading ?? ''); ?><?php echo trim(ob_get_clean()); ?>

</div>
<?php echo ltrim(ob_get_clean()); ?>

        <div class="mt-5 w-full max-w-lg">
            <?php echo e($slot); ?>

        </div>
    </div>
</div>
<?php /**PATH E:\______laravel Project 2026\wa_cabinet_2026_v2\resources\views/pages/settings/layout.blade.php ENDPATH**/ ?>