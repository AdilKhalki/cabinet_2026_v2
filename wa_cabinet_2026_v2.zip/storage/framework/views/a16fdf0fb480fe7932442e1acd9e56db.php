<div>
    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade in" role="alert">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <i class="feather icon-check-circle"></i> <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <div class="card">
        <div class="card-header">
            <h5><i class="feather icon-users"></i> Liste des Patients</h5>
            <div class="card-header-right">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Models\Patient::class)): ?>
                    <a href="<?php echo e(route('patients.create')); ?>" class="btn btn-primary btn-sm">
                        <i class="feather icon-user-plus"></i> Nouveau Patient
                    </a>
                <?php endif; ?>
            </div>
        </div>
        <div class="card-block">

            
            <div class="row m-b-20">
                <div class="col-md-6">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="feather icon-search"></i></span>
                        <input type="text" wire:model.live.debounce.300ms="search"
                               class="form-control"
                               placeholder="Rechercher par nom, téléphone, dossier, CIN...">
                    </div>
                </div>
                <div class="col-md-<?php echo e(auth()->user()->can('delete patients') ? 2 : 3); ?>">
                    <select wire:model.live="genderFilter" class="form-control">
                        <option value="">Tous les sexes</option>
                        <option value="male">Homme</option>
                        <option value="female">Femme</option>
                    </select>
                </div>
                <div class="col-md-<?php echo e(auth()->user()->can('delete patients') ? 2 : 3); ?>">
                    <select wire:model.live="perPage" class="form-control">
                        <option value="15">15 par page</option>
                        <option value="25">25 par page</option>
                        <option value="50">50 par page</option>
                    </select>
                </div>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete patients')): ?>
                    <div class="col-md-2">
                        <div class="checkbox m-t-5">
                            <label>
                                <input type="checkbox" wire:model.live="showArchived"> Dossiers archivés
                            </label>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>
                                <a wire:click="sort('dossier_number')" href="#" class="text-dark">
                                    Dossier
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($sortBy === 'dossier_number'): ?>
                                        <i class="feather icon-chevron-<?php echo e($sortDir === 'asc' ? 'up' : 'down'); ?>"></i>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </a>
                            </th>
                            <th>
                                <a wire:click="sort('last_name')" href="#" class="text-dark">
                                    Patient
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($sortBy === 'last_name'): ?>
                                        <i class="feather icon-chevron-<?php echo e($sortDir === 'asc' ? 'up' : 'down'); ?>"></i>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </a>
                            </th>
                            <th>Sexe</th>
                            <th>Âge</th>
                            <th>Téléphone</th>
                            <th>Groupe sanguin</th>
                            <th>Statut</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $this->patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                            <tr>
                                <td>
                                    <span class="label label-primary"><?php echo e($patient->dossier_number); ?></span>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($patient->photo_path): ?>
                                            <img src="<?php echo e($patient->photo_url); ?>"
                                                 class="img-radius m-r-10"
                                                 style="width:35px;height:35px;object-fit:cover;"
                                                 alt="<?php echo e($patient->full_name); ?>">
                                        <?php else: ?>
                                            <div class="img-radius m-r-10"
                                                 style="width:35px;height:35px;background:<?php echo e($patient->gender === 'male' ? '#01a9ac' : '#ff5370'); ?>;display:inline-flex;align-items:center;justify-content:center;border-radius:50%;color:#fff;font-weight:600;font-size:14px;">
                                                <?php echo e(mb_substr($patient->first_name, 0, 1)); ?>

                                            </div>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        <div>
                                            <strong><?php echo e($patient->full_name); ?></strong>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($patient->cin): ?>
                                                <small class="text-muted d-block">CIN: <?php echo e($patient->cin); ?></small>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($patient->gender === 'male'): ?>
                                        <span class="label label-info">Homme</span>
                                    <?php else: ?>
                                        <span class="label label-warning">Femme</span>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </td>
                                <td><?php echo e($patient->age); ?> ans</td>
                                <td>
                                    <a href="tel:<?php echo e($patient->phone); ?>"><?php echo e($patient->phone); ?></a>
                                </td>
                                <td>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($patient->blood_group): ?>
                                        <span class="label label-danger"><?php echo e($patient->blood_group); ?></span>
                                    <?php else: ?>
                                        <span class="text-muted">—</span>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </td>
                                <td>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($patient->is_active): ?>
                                        <span class="label label-success">Actif</span>
                                    <?php else: ?>
                                        <span class="label label-default">Inactif</span>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </td>
                                <td>
                                    <div class="btn-group">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($patient->trashed()): ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('restore', $patient)): ?>
                                                <button wire:click="restore(<?php echo e($patient->id); ?>)"
                                                        wire:confirm="Restaurer ce dossier patient ?"
                                                        class="btn btn-success btn-sm" title="Restaurer">
                                                    <i class="feather icon-rotate-ccw"></i>
                                                </button>
                                            <?php endif; ?>
                                        <?php else: ?>
                                        <a href="<?php echo e(route('patients.show', $patient)); ?>"
                                           class="btn btn-info btn-sm" title="Voir dossier">
                                            <i class="feather icon-eye"></i>
                                        </a>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $patient)): ?>
                                            <a href="<?php echo e(route('patients.edit', $patient)); ?>"
                                               class="btn btn-primary btn-sm" title="Modifier">
                                                <i class="feather icon-edit"></i>
                                            </a>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $patient)): ?>
                                            <button wire:click="confirmDelete(<?php echo e($patient->id); ?>)"
                                                    class="btn btn-danger btn-sm" title="Supprimer">
                                                <i class="feather icon-trash-2"></i>
                                            </button>
                                        <?php endif; ?>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            <tr>
                                <td colspan="8" class="text-center text-muted p-20">
                                    <i class="feather icon-users" style="font-size:2em;"></i>
                                    <p>Aucun patient trouvé.</p>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Models\Patient::class)): ?>
                                        <a href="<?php echo e(route('patients.create')); ?>" class="btn btn-primary btn-sm">
                                            Ajouter le premier patient
                                        </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                </table>
            </div>

            
            <div class="d-flex justify-content-between align-items-center m-t-15">
                <p class="text-muted">
                    <?php echo e($this->patients->total()); ?> patient(s) au total
                </p>
                <div class="d-flex justify-content-center">

                    <?php echo e($this->patients->links('pagination::bootstrap-5')); ?>

                </div>
            </div>

        </div>
    </div>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($showDeleteModal): ?>
        <div class="modal fade in" style="display:block; background:rgba(0,0,0,0.5);" tabindex="-1">
            <div class="modal-dialog modal-sm">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">Confirmer l'archivage</h4>
                    </div>
                    <div class="modal-body">
                        <p>Êtes-vous sûr de vouloir archiver ce dossier patient ? Il pourra être restauré depuis le filtre « Dossiers archivés ».</p>
                    </div>
                    <div class="modal-footer">
                        <button wire:click="cancelDelete" class="btn btn-default btn-sm">
                            <i class="feather icon-x"></i> Annuler
                        </button>
                        <button wire:click="delete" class="btn btn-danger btn-sm">
                            <i class="feather icon-trash-2"></i> Archiver
                        </button>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <div wire:loading.flex class="alert alert-info" style="position:fixed;bottom:20px;right:20px;z-index:9999;">
        <i class="feather icon-loader" style="animation:spin 1s linear infinite;"></i>
        &nbsp; Chargement...
    </div>
</div>
<?php /**PATH E:\______laravel Project 2026\wa_cabinet_2026_v2\resources\views/livewire/patient/patient-index.blade.php ENDPATH**/ ?>