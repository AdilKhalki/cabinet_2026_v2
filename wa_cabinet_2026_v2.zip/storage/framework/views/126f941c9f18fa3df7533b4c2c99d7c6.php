<div>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <div class="card">
        <div class="card-header">
            <h5><i class="feather icon-thermometer"></i> Analyses & Résultats de Laboratoire</h5>
            <div class="card-header-right">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Models\LabTest::class)): ?>
                <a href="<?php echo e(route('lab-tests.create')); ?>" class="btn btn-primary btn-sm">
                    <i class="feather icon-plus"></i> Nouvelle demande
                </a>
                <?php endif; ?>
            </div>
        </div>
        <div class="card-block">
            <div class="row m-b-20">
                <div class="col-md-5">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="feather icon-search"></i></span>
                        <input type="text" wire:model.live.debounce.300ms="search" class="form-control" placeholder="Rechercher un patient...">
                    </div>
                </div>
                <div class="col-md-3">
                    <select wire:model.live="statusFilter" class="form-control">
                        <option value="">Tous les statuts</option>
                        <option value="requested">Demandé</option>
                        <option value="pending">En attente</option>
                        <option value="completed">Complété</option>
                        <option value="cancelled">Annulé</option>
                    </select>
                </div>
            </div>

            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>N° Demande</th><th>Patient</th><th>Médecin</th>
                            <th>Date demande</th><th>Résultats</th><th>Statut</th><th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $this->labTests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                            <?php
                                $abnormal = $test->results->where('flag', '!=', 'normal')->count();
                                $critical = $test->results->where('flag', 'critical')->count();
                            ?>
                            <tr>
                                <td><span class="label label-primary"><?php echo e($test->request_number); ?></span></td>
                                <td>
                                    <a href="<?php echo e(route('patients.show', $test->patient)); ?>">
                                        <strong><?php echo e($test->patient->full_name); ?></strong>
                                    </a>
                                </td>
                                <td><?php echo e($test->doctor->name); ?></td>
                                <td><?php echo e($test->requested_at->format('d/m/Y')); ?></td>
                                <td>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($test->results->count() > 0): ?>
                                        <span class="label label-info" style="color: #000000;"><?php echo e($test->results->count()); ?> param.</span>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($critical > 0): ?>
                                            <span class="label label-danger"><?php echo e($critical); ?> critique(s)</span>
                                        <?php elseif($abnormal > 0): ?>
                                            <span class="label label-warning"><?php echo e($abnormal); ?> anormal(aux)</span>
                                        <?php else: ?>
                                            <span class="label label-success">Normaux</span>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    <?php else: ?>
                                        <span class="text-muted">—</span>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </td>
                                <td>
                                    <?php $colors = ['requested'=>'primary','pending'=>'warning','completed'=>'success','cancelled'=>'danger']; ?>
                                    <span class="label label-<?php echo e($colors[$test->status] ?? 'default'); ?>">
                                        <?php echo e(['requested'=>'Demandé','pending'=>'En attente','completed'=>'Complété','cancelled'=>'Annulé'][$test->status] ?? $test->status); ?>

                                    </span>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('lab-tests.show', $test)); ?>" class="btn btn-info btn-sm" title="Voir">
                                        <i class="feather icon-eye"></i>
                                    </a>
                                    <a href="<?php echo e(route('lab-tests.pdf', $test)); ?>" class="btn btn-warning btn-sm" title="Imprimer demande" target="_blank">
                                        <i class="feather icon-printer"></i>
                                    </a>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $test)): ?>
                                    <a href="<?php echo e(route('lab-tests.edit', $test->id)); ?>" class="btn btn-warning btn-sm" title="Modifier">
                                        <i class="feather icon-edit"></i>
                                    </a>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($test->status === 'requested'): ?>
                                        <button wire:click="updateStatus(<?php echo e($test->id); ?>, 'completed')"
                                                class="btn btn-success btn-sm" title="Marquer complété">
                                            <i class="feather icon-check"></i>
                                        </button>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            <tr><td colspan="7" class="text-center text-muted p-20">Aucune analyse trouvée.</td></tr>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="m-t-15"><?php echo e($this->labTests->links('pagination::bootstrap-5')); ?></div>
        </div>
    </div>
</div>
<?php /**PATH E:\______laravel Project 2026\wa_cabinet_2026_v2\resources\views/livewire/lab-test/lab-test-index.blade.php ENDPATH**/ ?>