<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title><?php echo e($report->report_number); ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'DejaVu Sans', sans-serif;
            font-size: 12px;
            color: #333;
            padding: 30px 35px 20px 35px;
        }

        .header { border-bottom: 2px solid #01a9ac; padding-bottom: 15px; margin-bottom: 20px; }
        .header-left { float: left; width: 60%; }
        .header-right { float: right; width: 38%; text-align: right; }
        .clearfix::after { content: ''; display: table; clear: both; }

        .doctor-name { font-size: 18px; font-weight: bold; color: #01a9ac; }
        .cabinet-info { font-size: 11px; color: #666; margin-top: 3px; line-height: 1.6; }

        .report-title {
            text-align: center;
            margin: 25px 0;
            padding: 12px;
            border: 2px solid #01a9ac;
            background: #f8fffe;
        }
        .report-title h2 {
            font-size: 16px;
            font-weight: bold;
            letter-spacing: 2px;
            text-transform: uppercase;
            color: #01a9ac;
            margin: 0;
        }
        .report-title h3 {
            font-size: 13px;
            color: #555;
            margin-top: 5px;
            font-weight: normal;
        }

        .patient-box {
            background: #f8f9fa;
            border-left: 3px solid #01a9ac;
            padding: 12px 15px;
            margin-bottom: 20px;
        }
        .patient-box table { width: 100%; border-collapse: collapse; }
        .patient-box td { padding: 3px 8px; font-size: 11px; }
        .patient-box td.label-cell { font-weight: bold; color: #555; width: 22%; }

        .validity-box {
            border: 2px solid #e74c3c;
            padding: 10px 15px;
            margin: 15px 0;
            background: #fff5f5;
            font-size: 12px;
        }
        .validity-box strong { color: #e74c3c; }

        .content-section {
            margin: 20px 0;
            min-height: 200px;
            line-height: 1.9;
            text-align: justify;
            font-size: 12px;
        }

        .footer { margin-top: 40px; border-top: 1px solid #ddd; padding-top: 15px; }
        .date-city { font-size: 11px; color: #666; }

        .signature-block {
            float: right;
            width: 45%;
            text-align: center;
        }
        .signature-label { font-size: 11px; color: #666; margin-bottom: 5px; }
        .signature-name { font-weight: bold; font-size: 12px; margin-top: 5px; }
        .signature-spec { font-size: 10px; color: #666; }

        .pdf-footer {
            position: fixed;
            bottom: 10px;
            left: 35px;
            right: 35px;
            text-align: center;
            font-size: 9px;
            color: #aaa;
            border-top: 1px solid #eee;
            padding-top: 5px;
        }
    </style>
</head>
<body>

    <?php
        // Le médecin signataire du rapport prime sur les paramètres du cabinet (cabinet multi-médecins)
        $doc            = $report->doctor;
        $doctorName     = preg_replace('/^Dr\.?\s+/i', '', $doc?->name ?: ($settings['doctor_name'] ?? ''));
        $doctorSpec     = $doc?->speciality ?: ($settings['doctor_speciality'] ?? null);
        $doctorLicense  = $doc?->license_number ?: ($settings['doctor_license'] ?? null);
        $signaturePath  = $doc?->signature_path ? storage_path('app/public/' . $doc->signature_path) : null;
        $stampPath      = $doc?->stamp_path ? storage_path('app/public/' . $doc->stamp_path) : null;
        $signaturePath  = $signaturePath && is_file($signaturePath) ? $signaturePath : null;
        $stampPath      = $stampPath && is_file($stampPath) ? $stampPath : null;
    ?>

    
    <div class="header clearfix">
        <div class="header-left">
            <div class="doctor-name">Dr. <?php echo e($doctorName); ?></div>
            <div class="cabinet-info">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($doctorSpec): ?>
                    <?php echo e($doctorSpec); ?><br>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($doctorLicense): ?>
                    INPE : <?php echo e($doctorLicense); ?><br>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php echo e($settings['cabinet_name'] ?? 'Cabinet Médical'); ?><br>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($settings['cabinet_address'])): ?>
                    <?php echo e($settings['cabinet_address']); ?><br>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($settings['cabinet_city'])): ?>
                    <?php echo e($settings['cabinet_city']); ?><br>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($settings['cabinet_phone'])): ?>
                    Tél : <?php echo e($settings['cabinet_phone']); ?>

                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>
        <div class="header-right">
            <div style="font-size: 11px; color: #666;">
                Réf : <strong><?php echo e($report->report_number); ?></strong><br>
                Date : <?php echo e($report->report_date ? $report->report_date->format('d/m/Y') : now()->format('d/m/Y')); ?>

            </div>
        </div>
    </div>

    
    <?php
        $typeLabels = \App\Models\MedicalReport::TYPE_LABELS;
    ?>
    <div class="report-title">
        <h2><?php echo e($typeLabels[$report->type] ?? 'DOCUMENT MÉDICAL'); ?></h2>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($report->title): ?>
            <h3><?php echo e($report->title); ?></h3>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>

    
    <div class="patient-box">
        <table>
            <tr>
                <td class="label-cell">Patient :</td>
                <td><strong><?php echo e($patient->full_name); ?></strong></td>
                <td class="label-cell">N° Dossier :</td>
                <td><?php echo e($patient->dossier_number); ?></td>
            </tr>
            <tr>
                <td class="label-cell">Né(e) le :</td>
                <td>
                    <?php echo e($patient->birth_date ? $patient->birth_date->format('d/m/Y') : '—'); ?>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($patient->age): ?> (<?php echo e($patient->age); ?> ans) <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </td>
                <td class="label-cell">CIN :</td>
                <td><?php echo e($patient->cin ?? '—'); ?></td>
            </tr>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($patient->address || $patient->city): ?>
            <tr>
                <td class="label-cell">Adresse :</td>
                <td colspan="3"><?php echo e(trim(($patient->address ?? '') . ' ' . ($patient->city ?? ''))); ?></td>
            </tr>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </table>
    </div>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($report->type === 'sick_leave' && ($report->valid_from || $report->valid_until)): ?>
        <div class="validity-box">
            <strong>Période d'arrêt de travail :</strong>
            Du <?php echo e($report->valid_from ? $report->valid_from->format('d/m/Y') : '...'); ?>

            au <?php echo e($report->valid_until ? $report->valid_until->format('d/m/Y') : '...'); ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($report->valid_from && $report->valid_until): ?>
                — soit <?php echo e($report->valid_from->diffInDays($report->valid_until) + 1); ?> jour(s)
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <div class="content-section">
        <?php echo nl2br(e($report->content)); ?>

    </div>

    
    <div class="footer clearfix">
        <div class="date-city">
            Fait à <?php echo e($settings['cabinet_city'] ?? '____________'); ?>, le <?php echo e($report->report_date ? $report->report_date->format('d/m/Y') : now()->format('d/m/Y')); ?>

        </div>
        <div class="signature-block">
            <div class="signature-label">Signature et cachet du médecin</div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($signaturePath): ?>
                <img src="<?php echo e($signaturePath); ?>" style="max-height: 60px;" alt="Signature">
            <?php else: ?>
                <div style="height: 60px; border-bottom: 1px solid #333; width: 150px; margin: 10px auto 5px;"></div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($stampPath): ?>
                <img src="<?php echo e($stampPath); ?>" style="max-height: 80px;" alt="Cachet">
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <div class="signature-name">Dr. <?php echo e($doctorName); ?></div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($doctorSpec): ?>
                <div class="signature-spec"><?php echo e($doctorSpec); ?></div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($settings['pdf_footer_text'])): ?>
        <div class="pdf-footer">
            <?php echo e($settings['pdf_footer_text']); ?>

        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

</body>
</html>
<?php /**PATH E:\______laravel Project 2026\wa_cabinet_2026_v2\resources\views/pdf/medical-report.blade.php ENDPATH**/ ?>