<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'DejaVu Sans', sans-serif;
            font-size: 12px;
            color: #333;
            padding: 30px 35px 20px 35px;
        }

        .header {
            border-bottom: 2px solid #01a9ac;
            padding-bottom: 15px;
            margin-bottom: 20px;
        }

        .header-left {
            float: left;
        }

        .header-right {
            float: right;
            text-align: right;
        }

        .clearfix::after {
            content: '';
            display: table;
            clear: both;
        }

        .doctor-name {
            font-size: 18px;
            font-weight: bold;
            color: #01a9ac;
        }

        .cabinet-info {
            font-size: 11px;
            color: #666;
            margin-top: 5px;
        }

        .patient-box {
            background: #f8f9fa;
            border-left: 3px solid #01a9ac;
            padding: 10px;
            margin-bottom: 15px;
        }

        .title {
            font-size: 14px;
            font-weight: bold;
            color: #01a9ac;
            text-align: center;
            margin-bottom: 15px;
            padding: 8px;
            border: 1px solid #01a9ac;
        }

        .info-line {
            font-size: 11px;
            color: #555;
            margin-bottom: 3px;
        }

        table.params {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        table.params th {
            background: #01a9ac;
            color: #fff;
            padding: 6px 8px;
            font-size: 8px;
            text-align: left;
            border: 1px solid #019a9c;
        }

        table.params td {
            padding: 6px 8px;
            border: 1px solid #ddd;
            font-size: 8px;
        }

        table.params tr:nth-child(even) {
            background: #f8f9fa;
        }

        .clinical-box {
            margin-top: 15px;
            padding: 10px;
            background: #fffbea;
            border-left: 3px solid #f4a100;
        }

        .footer {
            margin-top: 40px;
            border-top: 1px solid #ddd;
            padding-top: 15px;
        }

        .date-city {
            font-size: 11px;
            color: #666;
        }
    </style>
</head>

<body style="padding-top:140px;">
    
    

    
    <table style="width:100%;">
        <tr>
            <td style="width:50%; vertical-align:top;">
                <div class="patient-box">
                    <strong>Patient(e) :</strong> <?php echo e($labTest->patient->full_name); ?><br>
                    <span style="font-size:9px;">
                        Âge: <?php echo e($labTest->patient->age); ?> ans
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($labTest->patient->blood_group): ?>
                            — Groupe sanguin: <?php echo e($labTest->patient->blood_group); ?>

                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <br>
                        Dossier: <?php echo e($labTest->patient->dossier_number); ?>

                    </span>
                </div>
            </td>
            <td style="width:50%; vertical-align:top;">
                <div class="patient-box">
                    <div style="font-size: 11px; color: #666;">
                        Demande N°: <strong><?php echo e($labTest->request_number); ?></strong><br>
                        Date: <?php echo e($labTest->requested_at->format('d/m/Y')); ?>

                        <br>
                        .
                    </div>
                </div>
            </td>
        </tr>
    </table>


    
    <div class="title">DEMANDE D'ANALYSES BIOLOGIQUES</div>
    

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($labTest->laboratory_name): ?>
        <div class="info-line"><strong>Laboratoire :</strong> <?php echo e($labTest->laboratory_name); ?></div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($labTest->results->count()): ?>
        <table class="params">
            <thead>
                <tr>
                    <th style="width: 5%;">N°</th>
                    <th style="width: 45%;">Paramètre demandé</th>
                    <th style="width: 25%;">Valeurs normales</th>
                    <th style="width: 25%;">Résultat</th>
                </tr>
            </thead>
            <tbody>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $labTest->results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                    <tr>
                        <td style="text-align: center;"><?php echo e($loop->iteration); ?></td>
                        <td>
                            <strong><?php echo e($result->parameter_name); ?></strong>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($result->notes): ?>
                                <br><em style="color: #888; font-size: 10px;"><?php echo e($result->notes); ?></em>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </td>
                        <td style="font-size: 8px; color: #666;">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($result->normal_min !== null && $result->normal_max !== null): ?>
                                <?php echo e($result->normal_min); ?> - <?php echo e($result->normal_max); ?>

                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($result->unit): ?>
                                    <?php echo e($result->unit); ?>

                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            <?php elseif($result->unit): ?>
                                <?php echo e($result->unit); ?>

                            <?php else: ?>
                                —
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </td>
                        <td style="border: 1px dashed #aaa;">
                            
                        </td>
                    </tr>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p style="text-align: center; color: #999; margin-top: 20px;">Aucun paramètre spécifié.</p>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($labTest->clinical_info): ?>
        <div class="clinical-box">
            <strong>Renseignements cliniques :</strong><br>
            <?php echo e($labTest->clinical_info); ?>

        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    
</body>

</html>
<?php /**PATH E:\______laravel Project 2026\wa_cabinet_2026_v2\resources\views/pdf/lab-test.blade.php ENDPATH**/ ?>