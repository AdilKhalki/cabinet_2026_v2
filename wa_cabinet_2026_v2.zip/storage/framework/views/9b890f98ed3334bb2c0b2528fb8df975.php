<?php
    // Requêtes limitées (évite de charger toutes les notifications non lues à chaque page)
    $navUnreadCount = auth()->user()?->unreadNotifications()->count() ?? 0;
    $navUnreadLatest = auth()->user()?->unreadNotifications()->latest()->take(5)->get() ?? collect();

    // Accès rapides : patients en salle d'attente (un médecin ne voit que les siens)
    $navUser = auth()->user();
    $navWaitingCount = $navUser?->can('view appointments')
        ? \App\Models\Appointment::waitingRoom()
            ->when($navUser->isMedecin() && ! $navUser->isAdmin(), fn ($q) => $q->where('doctor_id', $navUser->id))
            ->count()
        : 0;

    // [permission, route, icône, libellé, classe de couleur]
    $quickActions = [
        ['create patients',      'patients.create',          'icon-user-plus',  'Patient',      'qa-teal'],
        ['create appointments',  'appointments.create',      'icon-calendar',   'RDV',          'qa-blue'],
        ['view appointments',    'appointments.waiting-room','icon-users',      'Salle d\'attente', 'qa-orange'],
        ['create consultations', 'consultations.create',     'icon-activity',   'Consultation', 'qa-green'],
        ['create prescriptions', 'prescriptions.create',     'icon-file-text',  'Ordonnance',   'qa-purple'],
        ['create payments',      'payments.index',           'icon-credit-card','Encaisser',    'qa-coral'],
    ];
?>
<nav class="navbar header-navbar pcoded-header">
    <div class="navbar-wrapper">

        <div class="navbar-logo">
            <a class="mobile-menu" id="mobile-collapse" href="#!">
                <i class="feather icon-menu"></i>
            </a>
            <a href="<?php echo e(route('home')); ?>">
                <img class="img-fluid" src="<?php echo e(asset('adminty/images/logo.png')); ?>" alt="Cabinet Médical"
                    style="max-height:40px;">
                <span class="f-w-600" style="color:#fff; font-size:16px; margin-left:8px;"><?php echo e(config('app.name', 'MISAHATI')); ?></span>
            </a>
            <a class="mobile-options">
                <i class="feather icon-more-horizontal"></i>
            </a>
        </div>

        <div class="navbar-container container-fluid">
            <ul class="nav-left">
                <li class="header-search">
                    <div class="main-search morphsearch-search">
                        <div class="input-group">
                            <span class="input-group-addon search-close"><i class="feather icon-x"></i></span>
                            <input type="text" class="form-control" placeholder="Rechercher...">
                            <span class="input-group-addon search-btn"><i class="feather icon-search"></i></span>
                        </div>
                    </div>
                </li>
                <li>
                    <a href="#!" onclick="javascript:toggleFullScreen()">
                        <i class="feather icon-maximize full-screen"></i>
                    </a>
                </li>

                
                <li class="quick-actions">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $quickActions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$permission, $routeName, $icon, $label, $color]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check($permission)): ?>
                            <?php
                                $href = $routeName === 'payments.index'
                                    ? route('payments.index', ['nouveau' => 1])
                                    : route($routeName);
                                $isWaiting = $routeName === 'appointments.waiting-room';
                            ?>
                            <a href="<?php echo e($href); ?>"
                               class="qa-btn <?php echo e($color); ?> <?php echo e(request()->routeIs($routeName) ? 'active' : ''); ?>"
                               title="<?php echo e($isWaiting ? 'Salle d\'attente' : 'Nouveau : '.$label); ?>">
                                <i class="feather <?php echo e($icon); ?>"></i>
                                <span class="qa-label"><?php echo e($isWaiting ? '' : '+ '); ?><?php echo e($label); ?></span>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isWaiting && $navWaitingCount > 0): ?>
                                    <span class="qa-badge"><?php echo e($navWaitingCount); ?></span>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </a>
                        <?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </li>
            </ul>

            <ul class="nav-right">
                
                <li class="header-notification">
                    <div class="dropdown-primary dropdown">
                        <div class="dropdown-toggle" data-toggle="dropdown">
                            <i class="feather icon-bell"></i>
                            <span class="badge bg-c-pink"><?php echo e($navUnreadCount); ?></span>
                        </div>
                        <ul class="show-notification notification-view dropdown-menu" data-dropdown-in="fadeIn"
                            data-dropdown-out="fadeOut">
                            <li>
                                <h6>Notifications</h6>
                                <label class="label label-danger">Nouveau</label>
                            </li>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $navUnreadLatest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                <li>
                                    <div class="media">
                                        <div class="media-body">
                                            <h5 class="notification-user"><?php echo e($notif->data['title'] ?? 'Notification'); ?></h5>
                                            <p class="notification-msg"><?php echo e($notif->data['message'] ?? ''); ?></p>
                                            <span class="notification-time"><?php echo e($notif->created_at->diffForHumans()); ?></span>
                                        </div>
                                    </div>
                                </li>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                <li><p class="text-center p-20">Aucune nouvelle notification</p></li>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            <li>
                                <a href="<?php echo e(route('notifications.index')); ?>" class="text-center">Voir tout</a>
                            </li>
                        </ul>
                    </div>
                </li>

                
                <li class="header-notification">
                    <div class="dropdown-primary dropdown">
                        <div class="dropdown-toggle" data-toggle="dropdown">
                            <i class="feather icon-calendar"></i>
                        </div>
                        <ul class="show-notification dropdown-menu" data-dropdown-in="fadeIn" data-dropdown-out="fadeOut"
                            style="min-width:280px;">
                            <li>
                                <h6>RDV du <?php echo e(now()->format('d/m/Y')); ?></h6>
                            </li>
                            <li>
                                <a href="<?php echo e(route('appointments.index')); ?>">
                                    <i class="feather icon-calendar"></i> Gérer les rendez-vous
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>

                
                <li class="user-profile header-notification">
                    <div class="dropdown-primary dropdown">
                        <div class="dropdown-toggle" data-toggle="dropdown">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()?->profile_photo_path): ?>
                                <img src="<?php echo e(Storage::url(auth()->user()->profile_photo_path)); ?>"
                                    class="img-radius" alt="Profil">
                            <?php else: ?>
                                <div class="img-radius"
                                    style="width:35px;height:35px;background:#01a9ac;display:inline-flex;align-items:center;justify-content:center;border-radius:50%;color:#fff;font-weight:600;font-size:14px;">
                                    <?php echo e(auth()->user()?->initials() ?? 'U'); ?>

                                </div>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            <span><?php echo e(auth()->user()?->name ?? 'Utilisateur'); ?></span>
                            <i class="feather icon-chevron-down"></i>
                        </div>
                        <ul class="show-notification profile-notification dropdown-menu" data-dropdown-in="fadeIn"
                            data-dropdown-out="fadeOut">
                            <li>
                                <a href="<?php echo e(route('profile.edit')); ?>">
                                    <i class="feather icon-user"></i> Mon Profil
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('security.edit')); ?>">
                                    <i class="feather icon-settings"></i> Paramètres
                                </a>
                            </li>
                            <li>
                                <form method="POST" action="<?php echo e(route('logout')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <a href="<?php echo e(route('logout')); ?>"
                                        onclick="event.preventDefault(); this.closest('form').submit();">
                                        <i class="feather icon-log-out"></i> Déconnexion
                                    </a>
                                </form>
                            </li>
                        </ul>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH E:\______laravel Project 2026\wa_cabinet_2026_v2\resources\views/partials/navbar.blade.php ENDPATH**/ ?>