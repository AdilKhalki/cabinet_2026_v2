<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'DejaVu Sans', sans-serif;
            font-size: 12px;
            color: #333;
            padding: 30px 35px 20px 35px;
        }

        .header {
            border-bottom: 2px solid #01a9ac;
            padding-bottom: 15px;
            margin-bottom: 20px;
        }

        .header-left {
            float: left;
        }

        .header-right {
            float: right;
            text-align: right;
        }

        .clearfix::after {
            content: '';
            display: table;
            clear: both;
        }

        .doctor-name {
            font-size: 18px;
            font-weight: bold;
            color: #01a9ac;
        }

        .cabinet-info {
            font-size: 11px;
            color: #666;
            margin-top: 5px;
        }

        .stamp {
            width: 80px;
            height: 80px;
            border: 2px solid #01a9ac;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            font-size: 9px;
            color: #01a9ac;
            padding: 5px;
        }

        .patient-box {
            background: #f8f9fa;
            border-left: 3px solid #01a9ac;
            padding: 10px;
            margin-bottom: 15px;
        }

        .rx-symbol {
            font-size: 40px;
            color: #01a9ac;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .medication-line {
            border-bottom: 1px dashed #ddd;
            padding: 4px 0;
            margin-bottom: 5px;
        }

        .medication-name {
            font-weight: bold;
            font-size: 9px;
        }

        .medication-detail {
            color: #555;
            font-size: 8px;
            margin-top: 3px;
        }

        .footer {
            margin-top: 40px;
            border-top: 1px solid #ddd;
            padding-top: 15px;
        }

        .signature-area {
            margin-top: 20px;
        }

        .date-city {
            font-size: 11px;
            color: #666;
        }

        .title {
            font-size: 14px;
            font-weight: bold;
            color: #01a9ac;
            text-align: center;
            margin-bottom: 15px;
            padding: 8px;
            border: 1px solid #01a9ac;
        }
    </style>
</head>

<body style="padding-top:140px;">
    
    

    
    <table style="width:100%;">
        <tr>
            <td style="width:50%; vertical-align:top;">
                <div class="patient-box">
                    <strong>Patient(e) :</strong> <?php echo e($prescription->patient->full_name); ?><br>
                    <span style="font-size:11px;">
                        Âge: <?php echo e($prescription->patient->age); ?> ans
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($prescription->patient->blood_group): ?>
                            — Groupe sanguin: <?php echo e($prescription->patient->blood_group); ?>

                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        Dossier: <?php echo e($prescription->patient->dossier_number); ?>

                    </span>
                </div>

            </td>
            <td style="width:50%; vertical-align:top;">
                <div class="patient-box">
                    <div style="font-size: 11px; color: #666;">
                        Ordonnance N°: <strong><?php echo e($prescription->prescription_number); ?></strong><br>
                        Le: <?php echo e($prescription->prescribed_at->format('d/m/Y')); ?><br>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($prescription->valid_until): ?>
                            Valable jusqu'au: <?php echo e($prescription->valid_until->format('d/m/Y')); ?>

                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </div>

            </td>
        </tr>
    </table>


    
    
    
    <div class="title">ORDONNANCE</div>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $prescription->lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
        <div class="medication-line">
            <div class="medication-name"><?php echo e($loop->iteration); ?>. <?php echo e($line->medication_name); ?></div>
            <div class="medication-detail">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($line->dosage): ?>
                    <strong>Posologie :</strong> <?php echo e($line->dosage); ?><br>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($line->frequency): ?>
                    <strong>Fréquence :</strong> <?php echo e($line->frequency); ?><br>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($line->duration_days): ?>
                    <strong>Durée :</strong> <?php echo e($line->duration_days); ?> jours<br>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($line->route): ?>
                    <strong>Voie :</strong> <?php echo e($line->route); ?><br>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($line->quantity): ?>
                    <strong>Quantité :</strong> <?php echo e($line->quantity); ?><br>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($line->instructions): ?>
                    <em><?php echo e($line->instructions); ?></em>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($prescription->notes): ?>
        <div style="margin-top: 15px; padding: 10px; background: #fffbea; border-left: 3px solid #f4a100;">
            <strong>Instructions :</strong> <?php echo e($prescription->notes); ?>

        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    
</body>

</html>
<?php /**PATH E:\______laravel Project 2026\wa_cabinet_2026_v2\resources\views/pdf/prescription.blade.php ENDPATH**/ ?>