<div>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->any()): ?>
        <div class="alert alert-danger alert-dismissible">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <ul class="m-b-0">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?><li><?php echo e($error); ?></li><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </ul>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <div class="card">
        <div class="card-block">
            <div class="row">
                <div class="col-md-4">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="feather icon-search"></i></span>
                        <input type="text" class="form-control" placeholder="Rechercher patient, facture..."
                               wire:model.live.debounce.300ms="search">
                    </div>
                </div>
                <div class="col-md-2">
                    <select wire:model.live="statusFilter" class="form-control">
                        <option value="">Tous les statuts</option>
                        <option value="paid">Payé</option>
                        <option value="partial">Partiel</option>
                        <option value="pending">Impayé</option>
                        <option value="cancelled">Annulé</option>
                        <option value="refunded">Remboursé</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <input type="date" class="form-control" wire:model.live="periodFrom" placeholder="Du">
                </div>
                <div class="col-md-2">
                    <input type="date" class="form-control" wire:model.live="periodTo" placeholder="Au">
                </div>
                <div class="col-md-2 text-right">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Models\Payment::class)): ?>
                    <button wire:click="openForm" class="btn btn-primary btn-sm">
                        <i class="feather icon-plus"></i> Nouveau Paiement
                    </button>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($showForm): ?>
    <div class="card">
        <div class="card-header">
            <h5><i class="feather icon-credit-card"></i> <?php echo e($editingId ? 'Modifier Paiement' : 'Nouveau Paiement'); ?></h5>
            <div class="card-header-right">
                <button wire:click="closeForm" class="btn btn-default btn-sm"><i class="feather icon-x"></i></button>
            </div>
        </div>
        <div class="card-block">
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Patient <span class="text-danger">*</span></label>
                        <?php if (isset($component)) { $__componentOriginaldf91e01cb43a2e4f863b01ea3afdf26c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldf91e01cb43a2e4f863b01ea3afdf26c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.patient-search-select','data' => ['patients' => $patients]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('patient-search-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['patients' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($patients)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldf91e01cb43a2e4f863b01ea3afdf26c)): ?>
<?php $attributes = $__attributesOriginaldf91e01cb43a2e4f863b01ea3afdf26c; ?>
<?php unset($__attributesOriginaldf91e01cb43a2e4f863b01ea3afdf26c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldf91e01cb43a2e4f863b01ea3afdf26c)): ?>
<?php $component = $__componentOriginaldf91e01cb43a2e4f863b01ea3afdf26c; ?>
<?php unset($__componentOriginaldf91e01cb43a2e4f863b01ea3afdf26c); ?>
<?php endif; ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['patient_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger small"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Médecin <span class="text-danger">*</span></label>
                        <select class="form-control" wire:model="doctor_id" <?php if(\App\Models\Payment::restrictedToOwn(auth()->user())): ?> disabled <?php endif; ?>>
                            <option value="">-- Sélectionner --</option>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                <option value="<?php echo e($doc->id); ?>">Dr. <?php echo e($doc->name); ?></option>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </select>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['doctor_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger small"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Date <span class="text-danger">*</span></label>
                        <input type="date" class="form-control" wire:model="payment_date">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['payment_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger small"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </div>
            </div>

            
            <h6 class="m-t-20 m-b-10"><strong>Lignes de facturation</strong></h6>
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Description</th>
                            <th style="width:100px">Qté</th>
                            <th style="width:130px">Prix unitaire</th>
                            <th style="width:130px">Total</th>
                            <th style="width:50px"></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                        <tr <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'line-'.e($i).''; ?>wire:key="line-<?php echo e($i); ?>">
                            <td>
                                <select class="form-control form-control-sm m-b-5" wire:model.live="lines.<?php echo e($i); ?>.medical_act_id">
                                    <option value="">-- Acte médical (optionnel) --</option>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $this->medicalActs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                        <option value="<?php echo e($act->id); ?>"><?php echo e($act->code ? $act->code.' — ' : ''); ?><?php echo e($act->name); ?> (<?php echo e(number_format($act->price, 2, ',', ' ')); ?> MAD)</option>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                </select>
                                <input type="text" class="form-control form-control-sm"
                                       wire:model="lines.<?php echo e($i); ?>.description"
                                       placeholder="Description de l'acte">
                            </td>
                            <td>
                                <input type="number" class="form-control form-control-sm"
                                       wire:model.live="lines.<?php echo e($i); ?>.quantity"
                                       min="1" step="1">
                            </td>
                            <td>
                                <input type="number" class="form-control form-control-sm"
                                       wire:model.live="lines.<?php echo e($i); ?>.unit_price"
                                       min="0" step="0.01">
                            </td>
                            <td>
                                <span class="form-control form-control-sm bg-light">
                                    <?php echo e(number_format((float) ($line['total_price'] ?? 0), 2, ',', ' ')); ?>

                                </span>
                            </td>
                            <td class="text-center">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(count($lines) > 1): ?>
                                <button wire:click="removeLine(<?php echo e($i); ?>)" class="btn btn-danger btn-sm">
                                    <i class="feather icon-trash-2"></i>
                                </button>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </td>
                        </tr>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </tbody>
                </table>
            </div>
            <button wire:click="addLine" class="btn btn-default btn-sm m-b-20">
                <i class="feather icon-plus"></i> Ajouter une ligne
            </button>

            
            <div class="row">
                <div class="col-md-6">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Mode de paiement <span class="text-danger">*</span></label>
                                <select class="form-control" wire:model="payment_method">
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = \App\Models\Payment::METHOD_LABELS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                        <option value="<?php echo e($value); ?>"><?php echo e($label); ?></option>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                </select>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['payment_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger small"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Notes</label>
                                <textarea class="form-control" wire:model="notes" rows="2"></textarea>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <table class="table table-condensed">
                        <tr>
                            <th>Sous-total</th>
                            <td class="text-right"><?php echo e(number_format($this->subtotal, 2, ',', ' ')); ?> MAD</td>
                        </tr>
                        <tr>
                            <th>
                                Remise
                                <input type="number" class="form-control form-control-sm d-inline" style="width:80px"
                                       wire:model.live.debounce.400ms="discount" min="0" step="0.01">
                                MAD
                            </th>
                            <td class="text-right text-danger">- <?php echo e(number_format((float) $discount, 2, ',', ' ')); ?> MAD</td>
                        </tr>
                        <tr>
                            <th>
                                Couverture assurance
                                <input type="number" class="form-control form-control-sm d-inline" style="width:80px"
                                       wire:model.live.debounce.400ms="insurance_coverage" min="0" step="0.01">
                                MAD
                            </th>
                            <td class="text-right text-info">- <?php echo e(number_format((float) $insurance_coverage, 2, ',', ' ')); ?> MAD</td>
                        </tr>
                        <tr class="bg-primary text-white">
                            <th>TOTAL</th>
                            <td class="text-right"><strong><?php echo e(number_format($this->total, 2, ',', ' ')); ?> MAD</strong></td>
                        </tr>
                        <tr>
                            <th>
                                Montant payé
                                <input type="number" class="form-control form-control-sm d-inline" style="width:100px"
                                       wire:model.live.debounce.400ms="amount_paid" min="0" step="0.01">
                            </th>
                            <td class="text-right text-success"><?php echo e(number_format((float) $amount_paid, 2, ',', ' ')); ?> MAD</td>
                        </tr>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = ['discount', 'insurance_coverage', 'amount_paid']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = [$field];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <tr><td colspan="2" class="text-danger small"><?php echo e($message); ?></td></tr>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        <tr>
                            <th>Reste à payer</th>
                            <td class="text-right <?php echo e($this->amountDue > 0 ? 'text-danger' : 'text-success'); ?>">
                                <strong><?php echo e(number_format($this->amountDue, 2, ',', ' ')); ?> MAD</strong>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>

            <div class="m-t-10">
                <button wire:click="save" class="btn btn-primary">
                    <i class="feather icon-save"></i> Enregistrer
                </button>
                <button wire:click="closeForm" class="btn btn-default m-l-10">Annuler</button>
            </div>
        </div>
    </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <div class="card">
        <div class="card-header">
            <h5>Historique des paiements</h5>
        </div>
        <div class="card-block">
            <div class="table-responsive">
                <table class="table table-hover table-bordered">
                    <thead>
                        <tr>
                            <th>N° Facture</th>
                            <th>Patient</th>
                            <th>Date</th>
                            <th>Total</th>
                            <th>Payé</th>
                            <th>Reste</th>
                            <th>Mode</th>
                            <th>Statut</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $this->payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                        <?php
                            $statusColors = ['paid'=>'bg-success','partial'=>'bg-warning','pending'=>'bg-danger','cancelled'=>'bg-dark','refunded'=>'bg-info'];
                            $statusLabels = ['paid'=>'Payé','partial'=>'Partiel','pending'=>'Impayé','cancelled'=>'Annulé','refunded'=>'Remboursé'];
                            $methodLabels = \App\Models\Payment::METHOD_LABELS;
                        ?>
                        <tr <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'payment-'.e($payment->id).''; ?>wire:key="payment-<?php echo e($payment->id); ?>">
                            <td><strong><?php echo e($payment->invoice_number); ?></strong></td>
                            <td>
                                <a href="<?php echo e(route('patients.show', $payment->patient_id)); ?>">
                                    <?php echo e($payment->patient?->full_name ?? '—'); ?>

                                </a>
                            </td>
                            <td><?php echo e(($payment->payment_date ?? $payment->created_at)->format('d/m/Y')); ?></td>
                            <td><?php echo e(number_format($payment->total_amount, 2, ',', ' ')); ?> MAD</td>
                            <td class="text-success"><?php echo e(number_format($payment->amount_paid, 2, ',', ' ')); ?> MAD</td>
                            <td class="<?php echo e($payment->amount_due > 0 ? 'text-danger' : ''); ?>">
                                <?php echo e(number_format($payment->amount_due, 2, ',', ' ')); ?> MAD
                            </td>
                            <td><?php echo e($methodLabels[$payment->payment_method] ?? $payment->payment_method); ?></td>
                            <td>
                                <span class="badge <?php echo e($statusColors[$payment->status] ?? 'label-default'); ?>">
                                    <?php echo e($statusLabels[$payment->status] ?? $payment->status); ?>

                                </span>
                            </td>
                            <td>
                                <a href="<?php echo e(route('payments.pdf', $payment->id)); ?>"
                                   target="_blank" class="btn btn-primary btn-sm" title="PDF">
                                    <i class="feather icon-printer"></i>
                                </a>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $payment)): ?>
                                <button wire:click="openEdit(<?php echo e($payment->id); ?>)"
                                        class="btn btn-warning btn-sm" title="Modifier">
                                    <i class="feather icon-edit"></i>
                                </button>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('cancel', $payment)): ?>
                                <button wire:click="cancel(<?php echo e($payment->id); ?>)"
                                        wire:confirm="Annuler la facture <?php echo e($payment->invoice_number); ?> ? Elle sera exclue du chiffre d'affaires."
                                        class="btn btn-inverse btn-sm" title="Annuler la facture">
                                    <i class="feather icon-slash"></i>
                                </button>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $payment)): ?>
                                <button wire:click="confirmDelete(<?php echo e($payment->id); ?>)"
                                        class="btn btn-danger btn-sm" title="Supprimer">
                                    <i class="feather icon-trash-2"></i>
                                </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        <tr>
                            <td colspan="9" class="text-center text-muted p-20">
                                <i class="feather icon-credit-card" style="font-size:2em;"></i><br>
                                Aucun paiement trouvé.
                            </td>
                        </tr>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="m-t-10">
                <?php echo e($this->payments->links('pagination::bootstrap-5')); ?>

            </div>
        </div>
    </div>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($confirmingDeleteId ?? false): ?>
    <div class="modal fade in" style="display:block;background:rgba(0,0,0,0.5);">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header"><h4 class="modal-title">Confirmer la suppression</h4></div>
                <div class="modal-body"><p>Supprimer ce paiement définitivement ?</p></div>
                <div class="modal-footer">
                    <button wire:click="cancelDelete" class="btn btn-default">Annuler</button>
                    <button wire:click="delete" class="btn btn-danger"><i class="feather icon-trash-2"></i> Supprimer</button>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>
<?php /**PATH E:\______laravel Project 2026\wa_cabinet_2026_v2\resources\views/livewire/payment/payment-index.blade.php ENDPATH**/ ?>