<?php
    $showMedical = auth()->user()->isMedecin() || auth()->user()->can('view consultations');
?>
<div>
    
    <div class="row">
        <div class="col-md-3 col-sm-6">
            <div class="card bg-c-blue">
                <div class="card-block">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h4 class="text-white"><?php echo e($this->todayAppointments); ?></h4>
                            <h6 class="text-white m-b-0">RDV aujourd'hui</h6>
                        </div>
                        <div class="col-4 text-right">
                            <i class="feather icon-calendar" style="font-size:2.5em;color:rgba(255,255,255,0.5);"></i>
                        </div>
                    </div>
                </div>
                <div class="card-footer" style="background:rgba(0,0,0,0.1);">
                    <a href="<?php echo e(route('appointments.index')); ?>" class="text-white">
                        Voir tous les RDV <i class="feather icon-arrow-right"></i>
                    </a>
                </div>
            </div>
        </div>

        <div class="col-md-3 col-sm-6">
            <div class="card bg-c-yellow">
                <div class="card-block">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h4 class="text-white"><?php echo e($this->todayWaiting); ?></h4>
                            <h6 class="text-white m-b-0">En salle d'attente</h6>
                        </div>
                        <div class="col-4 text-right">
                            <i class="feather icon-users" style="font-size:2.5em;color:rgba(255,255,255,0.5);"></i>
                        </div>
                    </div>
                </div>
                <div class="card-footer" style="background:rgba(0,0,0,0.1);">
                    <a href="<?php echo e(route('appointments.waiting-room')); ?>" class="text-white">
                        Salle d'attente <i class="feather icon-arrow-right"></i>
                    </a>
                </div>
            </div>
        </div>

        <div class="col-md-3 col-sm-6">
            <div class="card bg-c-green">
                <div class="card-block">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h4 class="text-white"><?php echo e($this->totalPatients); ?></h4>
                            <h6 class="text-white m-b-0">Total patients</h6>
                        </div>
                        <div class="col-4 text-right">
                            <i class="feather icon-user" style="font-size:2.5em;color:rgba(255,255,255,0.5);"></i>
                        </div>
                    </div>
                </div>
                <div class="card-footer" style="background:rgba(0,0,0,0.1);">
                    <a href="<?php echo e(route('patients.index')); ?>" class="text-white">
                        +<?php echo e($this->newPatientsThisMonth); ?> ce mois <i class="feather icon-arrow-right"></i>
                    </a>
                </div>
            </div>
        </div>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view payments')): ?>
        <div class="col-md-3 col-sm-6">
            <div class="card bg-c-pink">
                <div class="card-block">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h4 class="text-white"><?php echo e(number_format($this->monthlyRevenue, 0, ',', ' ')); ?></h4>
                            <h6 class="text-white m-b-0">Encaissé ce mois (MAD)</h6>
                        </div>
                        <div class="col-4 text-right">
                            <i class="feather icon-trending-up" style="font-size:2.5em;color:rgba(255,255,255,0.5);"></i>
                        </div>
                    </div>
                </div>
                <div class="card-footer" style="background:rgba(0,0,0,0.1);">
                    <a href="<?php echo e(auth()->user()->can('view reports') ? route('reports.financial') : route('payments.index')); ?>" class="text-white">
                        Impayés : <?php echo e(number_format($this->pendingPayments, 0, ',', ' ')); ?> MAD <i class="feather icon-arrow-right"></i>
                    </a>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <div class="row">
        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($showMedical): ?>
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h5><i class="feather icon-bar-chart-2"></i> Consultations — 30 derniers jours</h5>
                </div>
                <div class="card-block">
                    <canvas id="consultationsChart" height="100"></canvas>
                </div>
            </div>
        </div>

        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        
        <div class="<?php echo e($showMedical ? 'col-md-4' : 'col-md-12'); ?>">
            <div class="card">
                <div class="card-header">
                    <h5><i class="feather icon-clock"></i> Prochains RDV</h5>
                </div>
                <div class="card-block p-0">
                    <ul class="list-group list-group-flush">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $this->upcomingAppointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                            <li class="list-group-item" style="border-left: 3px solid <?php echo e($appt->color ?? '#01a9ac'); ?>;">
                                <div class="row">
                                    <div class="col-7">
                                        <strong><?php echo e($appt->patient->full_name); ?></strong>
                                        <small class="text-muted d-block"><?php echo e($appt->patient->dossier_number); ?> · Dr. <?php echo e($appt->doctor->name); ?></small>
                                    </div>
                                    <div class="col-5 text-right">
                                        <small class="text-primary"><?php echo e($appt->scheduled_at->format('d/m H:i')); ?></small>
                                        <br>
                                        <small class="text-muted"><?php echo e($appt->scheduled_at->diffForHumans()); ?></small>
                                    </div>
                                </div>
                            </li>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            <li class="list-group-item text-center text-muted">Aucun RDV à venir</li>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </ul>
                </div>
                <div class="card-footer text-center">
                    <a href="<?php echo e(route('appointments.index')); ?>">Voir tous les RDV</a>
                </div>
            </div>
        </div>
    </div>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($showMedical): ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h5><i class="feather icon-activity"></i> Consultations récentes</h5>
                    <div class="card-header-right">
                        <a href="<?php echo e(route('consultations.index')); ?>" class="btn btn-primary btn-sm">Voir tout</a>
                    </div>
                </div>
                <div class="card-block">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr><th>Patient</th><th>Médecin</th><th>Date</th><th>Motif</th><th>Statut</th></tr>
                            </thead>
                            <tbody>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $this->recentConsultations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consult): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                    <tr>
                                        <td>
                                            <a href="<?php echo e(route('patients.show', $consult->patient)); ?>">
                                                <strong><?php echo e($consult->patient->full_name); ?></strong>
                                            </a>
                                        </td>
                                        <td><?php echo e($consult->doctor->name); ?></td>
                                        <td><a href="<?php echo e(route('consultations.show', $consult)); ?>"><?php echo e($consult->consultation_date->format('d/m/Y H:i')); ?></a></td>
                                        <td><?php echo e($consult->reason ? Str::limit($consult->reason, 50) : '—'); ?></td>
                                        <td>
                                            <span class="label label-<?php echo e($consult->status === 'completed' ? 'success' : 'warning'); ?>">
                                                <?php echo e($consult->status_label); ?>

                                            </span>
                                        </td>
                                    </tr>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                    <tr><td colspan="5" class="text-center text-muted">Aucune consultation récente</td></tr>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

</div>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const ctx = document.getElementById('consultationsChart');
    if (!ctx) return;

    new Chart(ctx, {
        type: 'line',
        data: {
            labels: <?php echo json_encode($this->monthlyConsultationsChart['labels'], 15, 512) ?>,
            datasets: [{
                label: 'Consultations',
                data: <?php echo json_encode($this->monthlyConsultationsChart['values'], 15, 512) ?>,
                borderColor: '#01a9ac',
                backgroundColor: 'rgba(1, 169, 172, 0.1)',
                borderWidth: 2,
                fill: true,
                tension: 0.4,
            }]
        },
        options: {
            responsive: true,
            plugins: { legend: { display: false } },
            scales: {
                y: { beginAtZero: true, ticks: { stepSize: 1 } }
            }
        }
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH E:\______laravel Project 2026\wa_cabinet_2026_v2\resources\views/livewire/dashboard/dashboard-stats.blade.php ENDPATH**/ ?>