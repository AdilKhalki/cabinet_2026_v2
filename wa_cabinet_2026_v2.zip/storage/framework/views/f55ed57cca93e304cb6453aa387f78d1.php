<div>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <div class="card">
        <div class="card-header">
            <h5><i class="feather icon-image"></i> Imagerie Médicale</h5>
            <div class="card-header-right">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Models\MedicalImage::class)): ?>
                <a href="<?php echo e(route('medical-images.create')); ?>" class="btn btn-primary btn-sm">
                    <i class="feather icon-plus"></i> Nouvelle image
                </a>
                <?php endif; ?>
            </div>
        </div>
        <div class="card-block">

            
            <div class="row m-b-20">
                <div class="col-md-6">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="feather icon-search"></i></span>
                        <input type="text" wire:model.live.debounce.300ms="search" class="form-control" placeholder="Rechercher par patient, titre...">
                    </div>
                </div>
                <div class="col-md-4">
                    <select wire:model.live="categoryFilter" class="form-control">
                        <option value="">-- Toutes les catégories --</option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                            <option value="<?php echo e($key); ?>"><?php echo e($label); ?></option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </select>
                </div>
                <div class="col-md-2 text-right">
                    <span class="text-muted"><?php echo e($medicalImages->total()); ?> résultat(s)</span>
                </div>
            </div>

            
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($medicalImages->count()): ?>
                <div class="row">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $medicalImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                        <div class="col-md-4 col-sm-6 m-b-20">
                            <div class="card" style="border: 1px solid #ddd; border-radius: 6px; overflow: hidden;">
                                
                                <div style="height: 180px; background: #f0f0f0; display: flex; align-items: center; justify-content: center; overflow: hidden;">
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($image->file_path && ! $image->is_image): ?>
                                        <div class="text-center text-muted p-20">
                                            <i class="feather icon-file" style="font-size: 4em; color: #e74c3c;"></i>
                                            <br><small>Document <?php echo e(strtoupper($image->file_type)); ?></small>
                                        </div>
                                    <?php elseif($image->file_path): ?>
                                        <img src="<?php echo e($image->file_url); ?>"
                                             alt="<?php echo e($image->title); ?>"
                                             loading="lazy"
                                             style="width: 100%; height: 180px; object-fit: cover;"
                                             onerror="this.parentElement.innerHTML='<div class=\'text-center text-muted p-20\'><i class=\'feather icon-image\' style=\'font-size:3em\'></i><br><small>Image non disponible</small></div>'">
                                    <?php else: ?>
                                        <div class="text-center text-muted p-20">
                                            <i class="feather icon-image" style="font-size: 3em;"></i>
                                            <br><small>Pas d'aperçu</small>
                                        </div>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>

                                
                                <div class="card-block" style="padding: 12px;">
                                    <h6 class="m-b-5" style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="<?php echo e($image->title); ?>">
                                        <?php echo e($image->title); ?>

                                    </h6>
                                    <p class="text-muted m-b-5" style="font-size: 12px;">
                                        <i class="feather icon-user"></i>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($image->patient): ?>
                                            <a href="<?php echo e(route('patients.show', $image->patient)); ?>" wire:navigate><?php echo e($image->patient->full_name); ?></a>
                                        <?php else: ?>
                                            —
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </p>
                                    <p class="m-b-5">
                                        <?php
                                            $catColors = ['chest_xray'=>'label-info','abdominal_xray'=>'label-info','limb_xray'=>'label-info','ct_scan'=>'label-warning','mri'=>'label-primary','ultrasound'=>'label-success','other'=>'label-default'];
                                            $catColor = $catColors[$image->category] ?? 'label-default';
                                        ?>
                                        <span class="label <?php echo e($catColor); ?>"><?php echo e($categories[$image->category] ?? $image->category); ?></span>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($image->body_part): ?>
                                            <span class="label label-default"><?php echo e($image->body_part); ?></span>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </p>
                                    <p class="text-muted m-b-10" style="font-size: 12px;">
                                        <i class="feather icon-calendar"></i>
                                        <?php echo e($image->image_date?->format('d/m/Y') ?? '—'); ?>

                                    </p>
                                    <div class="btn-group btn-group-sm" style="width: 100%;">
                                        <a href="<?php echo e(route('medical-images.show', $image)); ?>" class="btn btn-info btn-sm" title="Voir">
                                            <i class="feather icon-eye"></i>
                                        </a>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $image)): ?>
                                        <a href="<?php echo e(route('medical-images.edit', $image)); ?>" class="btn btn-warning btn-sm" title="Modifier">
                                            <i class="feather icon-edit"></i>
                                        </a>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $image)): ?>
                                        <button type="button"
                                            wire:click="delete(<?php echo e($image->id); ?>)"
                                            wire:confirm="Êtes-vous sûr de vouloir supprimer cette image ?"
                                            class="btn btn-danger btn-sm" title="Supprimer">
                                            <i class="feather icon-trash-2"></i>
                                        </button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </div>

                <div class="m-t-20">
                    <?php echo e($medicalImages->links('pagination::bootstrap-5')); ?>

                </div>
            <?php else: ?>
                <div class="text-center p-30 text-muted">
                    <i class="feather icon-image" style="font-size: 3em;"></i>
                    <p class="m-t-10">Aucune image médicale trouvée.</p>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        </div>
    </div>
</div>
<?php /**PATH E:\______laravel Project 2026\wa_cabinet_2026_v2\resources\views/livewire/medical-image/medical-image-index.blade.php ENDPATH**/ ?>