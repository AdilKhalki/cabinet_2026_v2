<div>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($showForm): ?>
    <div class="card" style="border-left: 4px solid #4099ff;">
        <div class="card-header">
            <h5>
                <i class="feather icon-calendar"></i>
                <?php echo e($editingId ? 'Modifier le rendez-vous' : 'Nouveau rendez-vous'); ?>

            </h5>
            <div class="card-header-right">
                <button type="button" wire:click="closeForm" class="btn btn-default btn-sm">
                    <i class="feather icon-x"></i> Fermer
                </button>
            </div>
        </div>
        <div class="card-block">
            <form wire:submit="save">
                <div class="row">
                    <div class="col-md-3">
                        <div class="form-group">
                            <label>Patient <span class="text-danger">*</span></label>
                            <?php if (isset($component)) { $__componentOriginaldf91e01cb43a2e4f863b01ea3afdf26c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldf91e01cb43a2e4f863b01ea3afdf26c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.patient-search-select','data' => ['patients' => $patients]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('patient-search-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['patients' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($patients)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldf91e01cb43a2e4f863b01ea3afdf26c)): ?>
<?php $attributes = $__attributesOriginaldf91e01cb43a2e4f863b01ea3afdf26c; ?>
<?php unset($__attributesOriginaldf91e01cb43a2e4f863b01ea3afdf26c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldf91e01cb43a2e4f863b01ea3afdf26c)): ?>
<?php $component = $__componentOriginaldf91e01cb43a2e4f863b01ea3afdf26c; ?>
<?php unset($__componentOriginaldf91e01cb43a2e4f863b01ea3afdf26c); ?>
<?php endif; ?>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['patient_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger small"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label>Médecin <span class="text-danger">*</span></label>
                            <select class="form-control" wire:model="doctor_id" <?php if(auth()->user()->isMedecin() && ! auth()->user()->isAdmin()): echo 'disabled'; endif; ?>>
                                <option value="">-- Sélectionner --</option>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                    <option value="<?php echo e($doctor->id); ?>">Dr. <?php echo e($doctor->name); ?></option>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            </select>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['doctor_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger small"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label>Date et heure <span class="text-danger">*</span></label>
                            <input type="datetime-local" class="form-control" wire:model="scheduled_at">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['scheduled_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger small"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label>Type <span class="text-danger">*</span></label>
                            <select class="form-control" wire:model="consultation_type">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = \App\Models\Appointment::TYPE_LABELS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                    <option value="<?php echo e($key); ?>"><?php echo e($label); ?></option>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-2">
                        <div class="form-group">
                            <label>Durée (min)</label>
                            <select class="form-control" wire:model="duration_minutes">
                                <option value="15">15 min</option>
                                <option value="20">20 min</option>
                                <option value="30">30 min</option>
                                <option value="45">45 min</option>
                                <option value="60">1h</option>
                                <option value="90">1h30</option>
                                <option value="120">2h</option>
                            </select>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['duration_minutes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger small"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label>Couleur</label>
                            <input type="color" class="form-control" wire:model="color" style="height:38px;padding:2px 4px;">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger small"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="form-group">
                            <label>Notes</label>
                            <input type="text" class="form-control" wire:model="notes" placeholder="Motif, instructions...">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger small"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 text-right">
                        <button type="button" wire:click="closeForm" class="btn btn-default m-r-10">
                            <i class="feather icon-x"></i> Annuler
                        </button>
                        <button type="submit" class="btn btn-primary">
                            <span wire:loading wire:target="save"><i class="fa fa-spinner fa-spin"></i></span>
                            <i class="feather icon-save"></i>
                            <?php echo e($editingId ? 'Mettre à jour' : 'Créer le rendez-vous'); ?>

                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <div class="card">
        <div class="card-header">
            <h5><i class="feather icon-calendar"></i> Rendez-vous</h5>
            <div class="card-header-right">
                <a href="<?php echo e(route('appointments.calendar')); ?>" class="btn btn-default btn-sm m-r-5">
                    <i class="feather icon-grid"></i> Calendrier
                </a>
                <a href="<?php echo e(route('appointments.waiting-room')); ?>" class="btn btn-warning btn-sm m-r-5">
                    <i class="feather icon-users"></i> Salle d'attente
                </a>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Models\Appointment::class)): ?>
                <button type="button" wire:click="openForm()" class="btn btn-primary btn-sm">
                    <i class="feather icon-plus"></i> Nouveau RDV
                </button>
                <?php endif; ?>
            </div>
        </div>
        <div class="card-block">

            
            <div class="row m-b-20">
                <div class="col-md-4">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="feather icon-search"></i></span>
                        <input type="text" wire:model.live.debounce.300ms="search"
                               class="form-control" placeholder="Rechercher un patient...">
                    </div>
                </div>
                <div class="col-md-2">
                    <select wire:model.live="statusFilter" class="form-control">
                        <option value="">Tous les statuts</option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = \App\Models\Appointment::STATUS_LABELS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                            <option value="<?php echo e($key); ?>"><?php echo e($label); ?></option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <select wire:model.live="doctorFilter" class="form-control">
                        <option value="">Tous les médecins</option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                            <option value="<?php echo e($doctor->id); ?>">Dr. <?php echo e($doctor->name); ?></option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <input type="date" wire:model.live="dateFilter" class="form-control" title="Filtrer par date">
                </div>
                <div class="col-md-2 text-right">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($search || $statusFilter || $doctorFilter || $dateFilter): ?>
                        <button wire:click="$set('search',''); $set('statusFilter',''); $set('doctorFilter',''); $set('dateFilter','')"
                                class="btn btn-default btn-sm">
                            <i class="feather icon-x"></i> Réinitialiser
                        </button>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <span class="text-muted small"><?php echo e($appointments->total()); ?> RDV</span>
                </div>
            </div>

            
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($appointments->count()): ?>
            <div class="table-responsive">
                <table class="table table-hover table-striped">
                    <thead>
                        <tr>
                            <th style="width:140px">Date & Heure</th>
                            <th>Patient</th>
                            <th>Médecin</th>
                            <th>Type</th>
                            <th style="width:80px">Durée</th>
                            <th style="width:120px">Statut</th>
                            <th style="width:160px" class="text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                        <tr class="<?php echo e(in_array($appt->status, ['cancelled','no_show']) ? 'text-muted' : ''); ?>">

                            
                            <td>
                                <div style="font-weight:600; font-size:13px;">
                                    <?php echo e($appt->scheduled_at->format('d/m/Y')); ?>

                                </div>
                                <div class="text-muted" style="font-size:12px;">
                                    <i class="feather icon-clock" style="font-size:11px;"></i>
                                    <?php echo e($appt->scheduled_at->format('H:i')); ?>

                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($appt->scheduled_at->isToday()): ?>
                                        <span class="label label-success" style="font-size:9px;">Aujourd'hui</span>
                                    <?php elseif($appt->scheduled_at->isTomorrow()): ?>
                                        <span class="label label-info" style="font-size:9px;">Demain</span>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>
                            </td>

                            
                            <td>
                                <a href="<?php echo e(route('patients.show', $appt->patient)); ?>"
                                   class="text-dark" style="font-weight:600;">
                                    <?php echo e($appt->patient->full_name); ?>

                                </a>
                                <div class="text-muted" style="font-size:11px;">
                                    <?php echo e($appt->patient->dossier_number); ?>

                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($appt->patient->phone): ?>
                                        · <?php echo e($appt->patient->phone); ?>

                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>
                            </td>

                            
                            <td>
                                <span style="font-size:13px;">Dr. <?php echo e($appt->doctor->name); ?></span>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($appt->doctor->speciality): ?>
                                    <div class="text-muted" style="font-size:11px;"><?php echo e($appt->doctor->speciality); ?></div>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </td>

                            
                            <td>
                                <?php
                                    $typeColors = ['general'=>'bg-dark','specialized'=>'bg-primary','followup'=>'bg-info','emergency'=>'bg-danger','control'=>'bg-warning','teleconsultation'=>'bg-c-blue'];
                                ?>
                                <span class="badge <?php echo e($typeColors[$appt->consultation_type] ?? 'bg-default'); ?>" style="font-size:11px;">
                                    <?php echo e(\App\Models\Appointment::TYPE_LABELS[$appt->consultation_type] ?? $appt->consultation_type); ?>

                                </span>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($appt->notes): ?>
                                    <div class="text-muted" style="font-size:11px; margin-top:3px;" title="<?php echo e($appt->notes); ?>">
                                        <i class="feather icon-message-square" style="font-size:10px;"></i>
                                        <?php echo e(Str::limit($appt->notes, 30)); ?>

                                    </div>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </td>

                            
                            <td class="text-muted" style="font-size:12px;">
                                <?php echo e($appt->duration_minutes); ?> min
                            </td>

                            
                            <td class="text-center">


                                
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $appt)): ?>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($appt->status === 'planned' || $appt->status === 'confirmed'): ?>
                                    <div class="m-t-5">
                                        <button wire:click="updateStatus(<?php echo e($appt->id); ?>, 'confirmed')"
                                                class="btn btn-sm btn-info m-b-2" title="Confirmer" style="font-size:10px; <?php echo e($appt->status === 'confirmed' ? 'opacity:0.5' : ''); ?>">
                                            <i class="feather icon-check"></i>
                                        </button>
                                        <button wire:click="updateStatus(<?php echo e($appt->id); ?>, 'waiting')"
                                                class="btn btn-sm btn-warning m-b-2" title="Arrivé en salle d'attente" style="font-size:10px;">
                                            <i class="feather icon-user-check"></i>
                                        </button>
                                        <button wire:click="confirmCancel(<?php echo e($appt->id); ?>)"
                                                class="btn btn-sm btn-danger m-b-2" title="Annuler" style="font-size:10px;">
                                            <i class="feather icon-x"></i>
                                        </button>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($appt->scheduled_at->isPast()): ?>
                                        <button wire:click="updateStatus(<?php echo e($appt->id); ?>, 'no_show')"
                                                wire:confirm="Marquer ce patient comme absent ?"
                                                class="btn btn-sm btn-default m-b-2" title="Absent" style="font-size:10px;">
                                            <i class="feather icon-user-x"></i>
                                        </button>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </div>
                                <?php elseif($appt->status === 'waiting'): ?>
                                    <div class="m-t-5">
                                        <button wire:click="updateStatus(<?php echo e($appt->id); ?>, 'in_progress')"
                                                class="btn btn-sm btn-primary" title="Démarrer la consultation" style="font-size:10px;">
                                            <i class="feather icon-play"></i> Démarrer
                                        </button>
                                    </div>
                                <?php elseif($appt->status === 'in_progress'): ?>
                                    <div class="m-t-5">
                                        <button wire:click="updateStatus(<?php echo e($appt->id); ?>, 'completed')"
                                                class="btn btn-sm btn-success" title="Terminer" style="font-size:10px;">
                                            <i class="feather icon-check-circle"></i> Terminer
                                        </button>
                                    </div>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                <?php endif; ?>
                                <span class="label <?php echo e(\App\Models\Appointment::STATUS_COLORS[$appt->status] ?? 'label-default'); ?>">
                                    <?php echo e(\App\Models\Appointment::STATUS_LABELS[$appt->status] ?? $appt->status); ?>

                                </span>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($appt->status === 'cancelled' && $appt->cancellation_reason): ?>
                                    <div class="text-muted" style="font-size:11px;" title="<?php echo e($appt->cancellation_reason); ?>">
                                        <?php echo e(Str::limit($appt->cancellation_reason, 40)); ?>

                                    </div>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </td>

                            
                            <td class="text-center">
                                
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Models\Consultation::class)): ?>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(in_array($appt->status, ['planned','confirmed','waiting','in_progress']) && !$appt->consultation && auth()->user()->can('update', $appt)): ?>
                                    <a href="<?php echo e(route('consultations.create', ['appointmentId' => $appt->id])); ?>"
                                       class="btn btn-sm btn-success m-b-2" title="Créer consultation">
                                        <i class="feather icon-activity"></i>
                                    </a>
                                <?php elseif($appt->consultation): ?>
                                    <a href="<?php echo e(route('consultations.show', $appt->consultation)); ?>"
                                       class="btn btn-sm btn-info m-b-2" title="Voir consultation">
                                        <i class="feather icon-eye"></i>
                                    </a>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                <?php endif; ?>

                                
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $appt)): ?>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!in_array($appt->status, ['completed','cancelled','no_show'])): ?>
                                    <button wire:click="openForm(<?php echo e($appt->id); ?>)"
                                            class="btn btn-sm btn-warning m-b-2" title="Modifier">
                                        <i class="feather icon-edit"></i>
                                    </button>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                <?php endif; ?>

                                
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $appt)): ?>
                                <button wire:click="confirmDelete(<?php echo e($appt->id); ?>)"
                                        class="btn btn-sm btn-danger m-b-2" title="Supprimer">
                                    <i class="feather icon-trash-2"></i>
                                </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="m-t-15">
                <?php echo e($appointments->links('pagination::bootstrap-5')); ?>

            </div>

            <?php else: ?>
            <div class="text-center p-40 text-muted">
                <i class="feather icon-calendar" style="font-size:3em;"></i>
                <p class="m-t-10">Aucun rendez-vous trouvé.</p>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Models\Appointment::class)): ?>
                <button wire:click="openForm()" class="btn btn-primary btn-sm">
                    <i class="feather icon-plus"></i> Créer un rendez-vous
                </button>
                <?php endif; ?>
            </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        </div>
    </div>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($showDeleteModal): ?>
    <div class="modal fade show" style="display:block; background:rgba(0,0,0,0.5);" tabindex="-1">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="feather icon-alert-triangle text-danger"></i> Confirmer la suppression</h5>
                </div>
                <div class="modal-body">
                    <p>Êtes-vous sûr de vouloir supprimer ce rendez-vous ? Cette action est irréversible.</p>
                </div>
                <div class="modal-footer">
                    <button wire:click="$set('showDeleteModal', false)" class="btn btn-default">
                        <i class="feather icon-x"></i> Annuler
                    </button>
                    <button wire:click="delete" class="btn btn-danger">
                        <span wire:loading wire:target="delete"><i class="fa fa-spinner fa-spin"></i></span>
                        <i class="feather icon-trash-2"></i> Supprimer
                    </button>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($showCancelModal): ?>
    <div class="modal fade show" style="display:block; background:rgba(0,0,0,0.5);" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form wire:submit="cancel">
                    <div class="modal-header">
                        <h5 class="modal-title"><i class="feather icon-x-circle text-danger"></i> Annuler le rendez-vous</h5>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Motif d'annulation <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" wire:model="cancellation_reason" maxlength="255"
                                   placeholder="Ex : annulé par le patient, médecin indisponible...">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['cancellation_reason'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger small"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" wire:click="$set('showCancelModal', false)" class="btn btn-default">
                            <i class="feather icon-arrow-left"></i> Retour
                        </button>
                        <button type="submit" class="btn btn-danger">
                            <span wire:loading wire:target="cancel"><i class="fa fa-spinner fa-spin"></i></span>
                            <i class="feather icon-x"></i> Confirmer l'annulation
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

</div>
<?php /**PATH E:\______laravel Project 2026\wa_cabinet_2026_v2\resources\views/livewire/appointment/appointment-index.blade.php ENDPATH**/ ?>